package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

/** Lightweight native Markdown renderer for Gemini responses. No raw Markdown syntax is shown. */
@Composable
fun MarkdownRenderer(
    markdown: String,
    modifier: Modifier = Modifier,
    isStreaming: Boolean = false,
    textColor: Color = TextPrimary
) {
    val blocks = remember(markdown) { parseBlocks(markdown) }
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        blocks.forEachIndexed { index, block ->
            when (block) {
                is MdBlock.Heading -> Text(
                    text = inline(block.text),
                    color = textColor,
                    fontSize = when (block.level) { 1 -> 21.sp; 2 -> 18.sp; 3 -> 16.sp; else -> 14.sp },
                    fontWeight = if (block.level <= 2) FontWeight.Bold else FontWeight.SemiBold,
                    lineHeight = when (block.level) { 1 -> 27.sp; 2 -> 24.sp; else -> 21.sp },
                    modifier = Modifier.padding(top = if (index == 0) 0.dp else 5.dp)
                )
                is MdBlock.Paragraph -> Text(
                    text = inline(block.text), color = textColor, fontSize = 14.sp, lineHeight = 21.sp
                )
                is MdBlock.Bullet -> Row(modifier = Modifier.fillMaxWidth()) {
                    Text("•", color = ElectricCyanPrimary, fontSize = 15.sp, modifier = Modifier.width(18.dp))
                    Text(inline(block.text), color = textColor, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.weight(1f))
                }
                is MdBlock.Numbered -> Row(modifier = Modifier.fillMaxWidth()) {
                    Text("${block.number}.", color = ElectricCyanPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(25.dp))
                    Text(inline(block.text), color = textColor, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.weight(1f))
                }
                is MdBlock.Quote -> Row(modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.width(3.dp).background(ElectricCyanPrimary, RoundedCornerShape(2.dp)))
                    Text(inline(block.text), color = TextSecondary, fontSize = 13.sp, lineHeight = 20.sp, modifier = Modifier.padding(start = 10.dp).weight(1f))
                }
                is MdBlock.Code -> CodeBlock(block.language, block.code)
                is MdBlock.Table -> MarkdownTable(block.headers, block.rows)
                MdBlock.Rule -> Box(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(DarkSlateBorder).padding(vertical = 0.5.dp))
            }
        }
        if (isStreaming) {
            Text("▌", color = ElectricCyanPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CodeBlock(language: String?, code: String) {
    val clipboard = LocalClipboardManager.current
    Column(
        modifier = Modifier.fillMaxWidth().background(DarkSlateBackground, RoundedCornerShape(10.dp))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().background(DarkSlateCard, RoundedCornerShape(topStart = 10.dp, topEnd = 10.dp)).padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(language?.uppercase(Locale.US) ?: "CODE", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { clipboard.setText(AnnotatedString(code)) }) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Copy code", tint = TextSecondary)
            }
        }
        Text(
            text = code,
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            lineHeight = 18.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)
        )
    }
}

@Composable
private fun MarkdownTable(headers: List<String>, rows: List<List<String>>) {
    Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
        Column(modifier = Modifier.background(DarkSlateCard, RoundedCornerShape(8.dp))) {
            TableRow(headers, header = true)
            rows.forEach { TableRow(it, header = false) }
        }
    }
}

@Composable
private fun TableRow(cells: List<String>, header: Boolean) {
    Row(modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        cells.forEach { cell ->
            Text(
                text = inline(cell),
                color = if (header) ElectricCyanPrimary else TextPrimary,
                fontSize = if (header) 11.sp else 12.sp,
                fontWeight = if (header) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.width(120.dp)
            )
        }
    }
}

private sealed interface MdBlock {
    data class Heading(val level: Int, val text: String) : MdBlock
    data class Paragraph(val text: String) : MdBlock
    data class Bullet(val text: String, val depth: Int) : MdBlock
    data class Numbered(val number: String, val text: String) : MdBlock
    data class Quote(val text: String) : MdBlock
    data class Code(val language: String?, val code: String) : MdBlock
    data class Table(val headers: List<String>, val rows: List<List<String>>) : MdBlock
    data object Rule : MdBlock
}

private fun parseBlocks(source: String): List<MdBlock> {
    val lines = source.replace("\r\n", "\n").split('\n')
    val out = mutableListOf<MdBlock>()
    var i = 0
    val paragraph = StringBuilder()

    fun flushParagraph() {
        if (paragraph.isNotBlank()) {
            out += MdBlock.Paragraph(paragraph.toString().trim())
            paragraph.clear()
        }
    }

    while (i < lines.size) {
        val raw = lines[i]
        val line = raw.trimEnd()
        if (line.trim().startsWith("```") || line.trim().startsWith("~~~")) {
            flushParagraph()
            val fence = if (line.trim().startsWith("~~~")) "~~~" else "```"
            val language = line.trim().removePrefix(fence).trim().ifBlank { null }
            val code = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trim().startsWith(fence)) {
                code.append(lines[i]).append('\n')
                i++
            }
            if (i < lines.size) i++
            out += MdBlock.Code(language, code.toString().trimEnd())
            continue
        }
        val heading = Regex("^\\s*(#{1,6})\\s+(.+?)\\s*#*\\s*$").find(line)
        if (heading != null) {
            flushParagraph(); out += MdBlock.Heading(heading.groupValues[1].length, heading.groupValues[2]); i++; continue
        }
        if (line.trim().matches(Regex("^([-*_])(?:\\s*\\1){2,}\\s*$"))) {
            flushParagraph(); out += MdBlock.Rule; i++; continue
        }
        if (line.trimStart().startsWith(">")) {
            flushParagraph(); out += MdBlock.Quote(line.trimStart().removePrefix("> ").removePrefix(">")); i++; continue
        }
        val bullet = Regex("^(\\s*)[-*+]\\s+(.+)$").find(line)
        if (bullet != null) {
            flushParagraph(); out += MdBlock.Bullet(bullet.groupValues[2], bullet.groupValues[1].length / 2); i++; continue
        }
        val numbered = Regex("^\\s*(\\d+)[.)]\\s+(.+)$").find(line)
        if (numbered != null) {
            flushParagraph(); out += MdBlock.Numbered(numbered.groupValues[1], numbered.groupValues[2]); i++; continue
        }
        if (isTableSeparator(line) && i > 0 && out.lastOrNull() is MdBlock.Paragraph) {
            val header = (out.removeLast() as MdBlock.Paragraph).text.split('|').map { it.trim() }.filter { it.isNotEmpty() }
            val rows = mutableListOf<List<String>>()
            i++
            while (i < lines.size && lines[i].contains('|') && lines[i].isNotBlank()) {
                rows += lines[i].trim().trim('|').split('|').map { it.trim() }
                i++
            }
            out += MdBlock.Table(header, rows)
            continue
        }
        if (line.isBlank()) { flushParagraph(); i++; continue }
        if (paragraph.isNotEmpty()) paragraph.append('\n')
        paragraph.append(line.trim())
        i++
    }
    flushParagraph()
    return out
}

private fun isTableSeparator(line: String): Boolean =
    line.trim().trim('|').split('|').size >= 2 && line.trim().trim('|').split('|').all { it.trim().matches(Regex(":?-{3,}:?")) }

private fun inline(source: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (i < source.length) {
        if (source.startsWith("***", i) || source.startsWith("___", i)) {
            val token = source.substring(i, i + 3); val end = source.indexOf(token, i + 3)
            if (end > i + 3) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)) { append(source.substring(i + 3, end)) }
                i = end + 3; continue
            }
        }
        if (source.startsWith("**", i) || source.startsWith("__", i)) {
            val token = source.substring(i, i + 2); val end = source.indexOf(token, i + 2)
            if (end > i + 2) { withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(source.substring(i + 2, end)) }; i = end + 2; continue }
        }
        if (source.startsWith("*", i) || source.startsWith("_", i)) {
            val token = source.substring(i, i + 1); val end = source.indexOf(token, i + 1)
            if (end > i + 1) { withStyle(SpanStyle(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)) { append(source.substring(i + 1, end)) }; i = end + 1; continue }
        }
        if (source.startsWith("`", i)) {
            val end = source.indexOf('`', i + 1)
            if (end > i + 1) { withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = DarkSlateCard)) { append(source.substring(i + 1, end)) }; i = end + 1; continue }
        }
        if (source.startsWith("~~", i)) {
            val end = source.indexOf("~~", i + 2)
            if (end > i + 2) { withStyle(SpanStyle(textDecoration = TextDecoration.LineThrough, color = TextSecondary)) { append(source.substring(i + 2, end)) }; i = end + 2; continue }
        }
        if (source[i] == '[') {
            val close = source.indexOf(']', i + 1); val openUrl = if (close >= 0) source.indexOf('(', close) else -1; val closeUrl = if (openUrl >= 0) source.indexOf(')', openUrl) else -1
            if (close > i && openUrl == close + 1 && closeUrl > openUrl) {
                val label = source.substring(i + 1, close); val url = source.substring(openUrl + 1, closeUrl)
                pushStringAnnotation("URL", url); withStyle(SpanStyle(color = ElectricCyanPrimary, textDecoration = TextDecoration.Underline)) { append(label) }; pop(); i = closeUrl + 1; continue
            }
        }
        val math = source[i] == '$'
        if (math) {
            val end = source.indexOf('$', i + 1)
            if (end > i + 1) { withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = ElectricCyanPrimary)) { append(mathToUnicode(source.substring(i + 1, end))) }; i = end + 1; continue }
        }
        if (source[i] == '\\' && i + 1 < source.length && source[i + 1] == '(') {
            val end = source.indexOf("\\)", i + 2)
            if (end > i) { withStyle(SpanStyle(fontFamily = FontFamily.Monospace, color = ElectricCyanPrimary)) { append(mathToUnicode(source.substring(i + 2, end))) }; i = end + 2; continue }
        }
        append(source[i]); i++
    }
}

private fun mathToUnicode(s: String): String {
    var value = s
    val fraction = Regex("""\\frac\{([^{}]+)\}\{([^{}]+)\}""")
    value = fraction.replace(value) { "(${it.groupValues[1]}/${it.groupValues[2]})" }
    return value
        .replace("\\sqrt", "√")
        .replace("\\times", "×")
        .replace("\\cdot", "·")
        .replace("\\pm", "±")
        .replace("\\theta", "θ")
        .replace("\\alpha", "α")
        .replace("\\beta", "β")
        .replace("\\omega", "ω")
        .replace("\\pi", "π")
        .replace("\\int", "∫")
        .replace("\\sum", "Σ")
        .replace("\\infty", "∞")
        .replace("^2", "²")
        .replace("^3", "³")
        .replace("^", "")
        .replace("_", "")
        .replace("{", "")
        .replace("}", "")
}
