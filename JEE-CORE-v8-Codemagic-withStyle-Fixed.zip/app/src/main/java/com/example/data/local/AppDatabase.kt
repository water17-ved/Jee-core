package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ChatEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionEntity
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.WorkLogEntity

@Database(
    entities = [
        MissionEntity::class,
        FocusSessionEntity::class,
        ChatEntity::class,
        ChatMessageEntity::class,
        SyllabusTopicEntity::class,
        TestRecordEntity::class,
        WorkLogEntity::class
    ],
    version = 2,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun missionDao(): MissionDao
    abstract fun focusSessionDao(): FocusSessionDao
    abstract fun chatDao(): ChatDao
    abstract fun syllabusDao(): SyllabusDao
    abstract fun testRecordDao(): TestRecordDao
    abstract fun workLogDao(): WorkLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN aiMode TEXT NOT NULL DEFAULT 'AUTO'")
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN attachmentUri TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN attachmentName TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN attachmentType TEXT DEFAULT NULL")
                db.execSQL("ALTER TABLE chat_messages ADD COLUMN isError INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "jee_core_database"
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
