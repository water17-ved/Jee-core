package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * JEE CORE visual language: dark glass surfaces, soft neon edges and generous radius.
 * The goal is to feel like the supplied Command Center showcase rather than a stack
 * of generic Material cards.
 */
@Composable
fun JeeSurface(
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(26.dp),
    color: Color = DarkSlateCard,
    contentColor: Color = TextPrimary,
    border: androidx.compose.foundation.BorderStroke? = null,
    tonalElevation: Dp = 0.dp,
    shadowElevation: Dp = 8.dp,
    content: @Composable () -> Unit
) {
    val fusedShape = RoundedCornerShape(26.dp)
    val glow = ElectricCyanPrimary
    Surface(
        modifier = modifier.shadow(
            elevation = shadowElevation,
            shape = fusedShape,
            ambientColor = Color.Black.copy(alpha = .38f),
            spotColor = glow.copy(alpha = .18f)
        ),
        shape = fusedShape,
        color = Color.Transparent,
        contentColor = contentColor,
        tonalElevation = tonalElevation,
        border = null
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            color.copy(alpha = 1f),
                            color.copy(alpha = .82f),
                            DarkSlateSurface.copy(alpha = .96f)
                        )
                    ),
                    fusedShape
                )
                .then(
                    if (border != null) Modifier.border(border, fusedShape)
                    else Modifier.border(1.dp, Color.White.copy(alpha = .035f), fusedShape)
                )
        ) {
            content()
        }
    }
}

@Composable
fun FusionPill(
    text: String,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    accent: Color = ElectricCyanPrimary
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = if (active) accent.copy(alpha = .16f) else Color.White.copy(alpha = .035f),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (active) accent.copy(alpha = .42f) else Color.White.copy(alpha = .06f)
        )
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp),
            color = if (active) accent else TextSecondary,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
fun FusionMetric(
    value: String,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(value, color = accent, style = MaterialTheme.typography.titleLarge)
        Text(label, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun FusionProgressBar(
    progress: Float,
    accent: Color = ElectricCyanPrimary,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(8.dp)
            .background(Color.White.copy(alpha = .055f), RoundedCornerShape(999.dp))
            .border(1.dp, Color.White.copy(alpha = .045f), RoundedCornerShape(999.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .background(
                    Brush.horizontalGradient(
                        listOf(accent.copy(alpha = .45f), accent, TrackerOrange.copy(alpha = .8f))
                    ),
                    RoundedCornerShape(999.dp)
                )
        )
    }
}

@Composable
fun NeonSectionLabel(
    eyebrow: String,
    title: String,
    modifier: Modifier = Modifier,
    accent: Color = TrackerGold
) {
    Column(modifier = modifier) {
        Text(
            eyebrow,
            color = accent,
            fontSize = 10.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Black,
            letterSpacing = 1.8.sp
        )
        Spacer(Modifier.height(3.dp))
        Text(
            title,
            color = TextPrimary,
            fontSize = 21.sp,
            fontWeight = androidx.compose.ui.text.font.FontWeight.Black
        )
    }
}
