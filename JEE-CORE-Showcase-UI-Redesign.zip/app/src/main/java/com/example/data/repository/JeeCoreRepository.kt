package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.model.BackupData
import com.example.data.model.BackupPreview
import com.example.data.model.ChatEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ExamType
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionCreator
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.PriorityLevel
import com.example.data.model.Subject
import com.example.data.model.ScheduleSlot
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.TopicState
import com.example.data.model.WorkLogEntity
import com.example.data.preference.UserPreferencesManager
import com.squareup.moshi.Moshi
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class JeeCoreRepository(
    private val database: AppDatabase,
    val preferencesManager: UserPreferencesManager
) {
    private val missionDao = database.missionDao()
    private val focusSessionDao = database.focusSessionDao()
    private val chatDao = database.chatDao()
    private val syllabusDao = database.syllabusDao()
    private val testRecordDao = database.testRecordDao()
    private val workLogDao = database.workLogDao()

    private val moshi = Moshi.Builder().build()
    private val backupAdapter = moshi.adapter(BackupData::class.java)

    // Missions
    val allMissions: Flow<List<MissionEntity>> = missionDao.getAllMissions()

    suspend fun insertMission(mission: MissionEntity): Long = withContext(Dispatchers.IO) {
        missionDao.insertMission(mission)
    }

    suspend fun updateMission(mission: MissionEntity) = withContext(Dispatchers.IO) {
        missionDao.updateMission(mission.copy(updatedAtEpochMs = System.currentTimeMillis()))
    }

    suspend fun deleteMission(mission: MissionEntity) = withContext(Dispatchers.IO) {
        missionDao.deleteMission(mission)
    }

    // Focus sessions
    val allFocusSessions: Flow<List<FocusSessionEntity>> = focusSessionDao.getAllFocusSessions()

    suspend fun recordFocusSession(session: FocusSessionEntity): Long = withContext(Dispatchers.IO) {
        focusSessionDao.insertSession(session)
    }

    // Work Logs
    val allWorkLogs: Flow<List<WorkLogEntity>> = workLogDao.getAllWorkLogs()

    suspend fun logWork(log: WorkLogEntity): Long = withContext(Dispatchers.IO) {
        val id = workLogDao.insertWorkLog(log)
        // If linked to mission, update mission progress
        log.linkedMissionId?.let { missionId ->
            val mission = missionDao.getMissionById(missionId)
            if (mission != null) {
                val newCompleted = mission.completedQuantity + log.questionsAttempted
                val newStatus = if (newCompleted >= mission.targetQuantity) {
                    MissionStatus.COMPLETED
                } else {
                    MissionStatus.IN_PROGRESS
                }
                missionDao.updateMission(
                    mission.copy(
                        completedQuantity = newCompleted,
                        timeSpentMinutes = mission.timeSpentMinutes + log.durationMinutes,
                        status = newStatus,
                        completedAtEpochMs = if (newStatus == MissionStatus.COMPLETED) System.currentTimeMillis() else null
                    )
                )
            }
        }
        id
    }

    // Chat
    val allChats: Flow<List<ChatEntity>> = chatDao.getAllChats()

    fun getMessagesForChat(chatId: Long): Flow<List<ChatMessageEntity>> =
        chatDao.getMessagesForChat(chatId)

    suspend fun createChat(title: String): Long = withContext(Dispatchers.IO) {
        chatDao.insertChat(ChatEntity(title = title))
    }

    suspend fun renameChat(chatId: Long, newTitle: String) = withContext(Dispatchers.IO) {
        val chat = chatDao.getChatById(chatId)
        if (chat != null) {
            chatDao.updateChat(chat.copy(title = newTitle, updatedAtEpochMs = System.currentTimeMillis()))
        }
    }

    suspend fun deleteChat(chatId: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesForChat(chatId)
        chatDao.deleteChatById(chatId)
    }

    suspend fun insertChatMessage(message: ChatMessageEntity): Long = withContext(Dispatchers.IO) {
        val id = chatDao.insertMessage(message)
        val chat = chatDao.getChatById(message.chatId)
        if (chat != null) {
            chatDao.updateChat(
                chat.copy(
                    updatedAtEpochMs = System.currentTimeMillis(),
                    messageCount = chat.messageCount + 1
                )
            )
        }
        id
    }

    suspend fun updateChatMessage(message: ChatMessageEntity) = withContext(Dispatchers.IO) {
        chatDao.updateMessage(message)
    }

    suspend fun deleteChatMessage(messageId: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessageById(messageId)
    }

    // Syllabus
    val allSyllabusTopics: Flow<List<SyllabusTopicEntity>> = syllabusDao.getAllTopics()
    val weakAndRevisionTopics: Flow<List<SyllabusTopicEntity>> = syllabusDao.getWeakAndRevisionTopics()

    suspend fun updateTopic(topic: SyllabusTopicEntity) = withContext(Dispatchers.IO) {
        syllabusDao.updateTopic(topic)
    }

    // Tests
    val allTests: Flow<List<TestRecordEntity>> = testRecordDao.getAllTests()

    suspend fun recordTest(test: TestRecordEntity): Long = withContext(Dispatchers.IO) {
        testRecordDao.insertTest(test)
    }

    suspend fun deleteTest(test: TestRecordEntity) = withContext(Dispatchers.IO) {
        testRecordDao.deleteTest(test)
    }

    // Seed static standard syllabus if empty (all student metrics start empty at 0)
    suspend fun initializeSyllabusIfNeeded() = withContext(Dispatchers.IO) {
        if (syllabusDao.getTopicCount() == 0) {
            val defaultTopics = listOf(
                // Physics
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Electrostatics", topicName = "Coulomb's Law & Electric Field"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Electrostatics", topicName = "Capacitance & Dielectrics"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Mechanics", topicName = "Rotational Dynamics & Torque"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Mechanics", topicName = "Work, Energy & Power"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Current Electricity", topicName = "Kirchhoff's Laws & Potentiometer"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Optics", topicName = "Wave Optics & Interference"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Modern Physics", topicName = "Photoelectric Effect & Atomic Models"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Thermodynamics", topicName = "First Law & Heat Engines"),

                // Chemistry
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Chemical Bonding", topicName = "Molecular Orbital Theory & VSEPR"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Thermodynamics", topicName = "Enthalpy, Entropy & Gibbs Free Energy"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Equilibrium", topicName = "Ionic Equilibrium & Buffer Solutions"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Organic Chemistry", topicName = "Reaction Mechanisms (Sn1/Sn2/E1/E2)"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Coordination Chemistry", topicName = "Crystal Field Theory & Isomerism"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Electrochemistry", topicName = "Nernst Equation & Cell Potential"),

                // Mathematics
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Calculus", topicName = "Definite Integration & Properties"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Calculus", topicName = "Application of Derivatives (Maxima/Minima)"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Algebra", topicName = "Complex Numbers Geometry"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Vectors & 3D", topicName = "Shortest Distance & Planes"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Coordinate Geometry", topicName = "Conic Sections (Parabola & Ellipse)"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Probability", topicName = "Conditional Probability & Bayes' Theorem")
            )
            syllabusDao.insertTopics(defaultTopics)
        }
    }

    // Export complete backup as JSON (never including raw API secrets)
    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val profile = preferencesManager.userProfile.value
        val memory = preferencesManager.jeeMemory.value
        val behaviour = preferencesManager.aiBehaviour.value
        val notificationSettings = preferencesManager.notificationSettings.value

        val missions = missionDao.getAllMissionsList()
        val focusSessions = focusSessionDao.getAllFocusSessionsList()
        val chats = chatDao.getAllChatsList()
        val chatMessages = chatDao.getAllMessagesList()
        val syllabusTopics = syllabusDao.getAllTopicsList()
        val testRecords = testRecordDao.getAllTestsList()
        val workLogs = workLogDao.getAllWorkLogsList()

        val backup = BackupData(
            schemaVersion = 2,
            exportedAt = System.currentTimeMillis(),
            appVersion = "1.0.0",
            userProfile = profile,
            jeeMemory = memory,
            aiBehaviour = behaviour,
            notificationSettings = notificationSettings,
            missions = missions,
            focusSessions = focusSessions,
            chats = chats,
            chatMessages = chatMessages,
            syllabusTopics = syllabusTopics,
            testRecords = testRecords,
            workLogs = workLogs
        )
        backupAdapter.indent("  ").toJson(backup)
    }

    // Validate native JEE CORE JSON, Tracker JSON, or an arbitrary JSON document.
    // Unknown schemas are accepted as a data snapshot instead of being rejected.
    suspend fun validateAndPreviewBackup(jsonString: String): Result<BackupPreview> = withContext(Dispatchers.IO) {
        try {
            val root = parseAnyJsonObject(jsonString)
            val tracker = isTrackerJson(root)
            val backup = try { backupAdapter.fromJson(jsonString) } catch (_: Exception) { null }

            if (backup != null) {
                return@withContext Result.success(
                    BackupPreview(
                        schemaVersion = backup.schemaVersion,
                        exportedAt = backup.exportedAt,
                        appVersion = backup.appVersion,
                        targetExam = backup.userProfile.targetExam.displayName,
                        targetYear = backup.userProfile.targetYear,
                        missionCount = backup.missions.size,
                        focusSessionCount = backup.focusSessions.size,
                        chatCount = backup.chats.size,
                        messageCount = backup.chatMessages.size,
                        syllabusCount = backup.syllabusTopics.size,
                        testCount = backup.testRecords.size,
                        workLogCount = backup.workLogs.size
                    )
                )
            }

            val trackerTests = arrayCount(root, "majorTests") + arrayCount(root, "customTests") +
                    arrayCount(root, "advMajorTests") + arrayCount(root, "advChapterTests") + arrayCount(root, "chapterTests")
            val trackerQuestions = arrayCount(root, "dailyQuestions")
            val trackerLogs = arrayCount(root, "coachingLog") + arrayCount(root, "studyHours")
            val targetYear = root.optString("examDate", "").take(4).toIntOrNull() ?: 0

            Result.success(
                BackupPreview(
                    schemaVersion = if (tracker) 4 else 0,
                    exportedAt = root.optString("exportedAt", "").let { raw ->
                        runCatching { java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssX", java.util.Locale.US).parse(raw)?.time ?: System.currentTimeMillis() }
                            .getOrDefault(System.currentTimeMillis())
                    },
                    appVersion = if (tracker) "Tracker JSON" else "Generic JSON",
                    targetExam = if (tracker) root.optString("examType", "both") else "Imported data",
                    targetYear = targetYear,
                    missionCount = arrayCount(root, "dailyTargets") + arrayCount(root, "dailySchedule"),
                    focusSessionCount = 0,
                    chatCount = 0,
                    messageCount = 0,
                    syllabusCount = objectKeyCount(root.optJSONObject("progressData")) + objectKeyCount(root.optJSONObject("advProgressData")),
                    testCount = trackerTests,
                    workLogCount = trackerQuestions + trackerLogs
                )
            )
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("This file is not valid JSON: ${e.message}", e))
        }
    }

    private fun parseAnyJsonObject(raw: String): JSONObject {
        val trimmed = raw.trim()
        return if (trimmed.startsWith("[")) {
            JSONObject().put("__rootArray", JSONArray(trimmed))
        } else {
            JSONObject(trimmed)
        }
    }

    private fun arrayCount(root: JSONObject, key: String): Int =
        root.optJSONArray(key)?.length() ?: 0

    private fun objectKeyCount(obj: JSONObject?): Int =
        obj?.keys()?.asSequence()?.count() ?: 0

    private fun isTrackerJson(root: JSONObject): Boolean {
        val trackerKeys = setOf(
            "progressData", "advProgressData", "dailyQuestions", "studyHours",
            "majorTests", "customTests", "dailySchedule", "dailyTargets",
            "targetProgress", "coachingLog", "revisionCounts", "streakData",
            "presentData", "selfWeakSubjects", "pdfAnalysisHistory"
        )
        return trackerKeys.count { root.has(it) } >= 2 || root.optString("app").contains("JEE Battle Royale", true)
    }

    // Import native CORE, Tracker v4 JSON, or arbitrary JSON without requiring a rigid schema.
    suspend fun importBackupJson(jsonString: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val root = parseAnyJsonObject(jsonString)
            val backup = try { backupAdapter.fromJson(jsonString) } catch (_: Exception) { null }

            if (backup != null) {
                database.withTransaction {
                    missionDao.clearAll()
                    focusSessionDao.clearAll()
                    chatDao.clearAllChats()
                    chatDao.clearAllMessages()
                    syllabusDao.clearAll()
                    testRecordDao.clearAll()
                    workLogDao.clearAll()

                    val missionIdMap = mutableMapOf<Long, Long>()
                    backup.missions.forEach { oldMission ->
                        val newId = missionDao.insertMission(oldMission.copy(id = 0))
                        missionIdMap[oldMission.id] = newId
                    }
                    backup.focusSessions.forEach { oldSession ->
                        focusSessionDao.insertSession(oldSession.copy(id = 0, missionId = oldSession.missionId?.let { missionIdMap[it] ?: it }))
                    }
                    backup.workLogs.forEach { oldLog ->
                        workLogDao.insertWorkLog(oldLog.copy(id = 0, linkedMissionId = oldLog.linkedMissionId?.let { missionIdMap[it] ?: it }))
                    }

                    val chatIdMap = mutableMapOf<Long, Long>()
                    backup.chats.forEach { oldChat ->
                        val newId = chatDao.insertChat(oldChat.copy(id = 0))
                        chatIdMap[oldChat.id] = newId
                    }
                    backup.chatMessages.forEach { oldMsg ->
                        chatDao.insertMessage(oldMsg.copy(id = 0, chatId = chatIdMap[oldMsg.chatId] ?: oldMsg.chatId))
                    }
                    if (backup.syllabusTopics.isNotEmpty()) syllabusDao.insertTopics(backup.syllabusTopics.map { it.copy(id = 0) })
                    if (backup.testRecords.isNotEmpty()) testRecordDao.insertTests(backup.testRecords.map { it.copy(id = 0) })
                }
                preferencesManager.saveUserProfile(backup.userProfile)
                preferencesManager.saveJeeMemory(backup.jeeMemory)
                preferencesManager.saveAIBehaviour(backup.aiBehaviour)
                preferencesManager.saveNotificationSettings(backup.notificationSettings)
                return@withContext Result.success(true)
            }

            val tracker = isTrackerJson(root)
            database.withTransaction {
                if (tracker) {
                    importTrackerTests(root)
                    importTrackerQuestionLogs(root)
                    importTrackerProgress(root)
                    importTrackerTargets(root)
                }
            }
            if (tracker) importTrackerSchedule(root)

            // Always preserve a compact representation of arbitrary JSON so it can be
            // surfaced to the AI coach instead of being discarded.
            val summary = buildJsonContextSummary(root, tracker)
            val oldMemory = preferencesManager.jeeMemory.value
            preferencesManager.saveJeeMemory(
                oldMemory.copy(
                    importedDataContext = summary,
                    weaknesses = if (tracker) {
                        val weak = jsonStringArray(root.optJSONArray("selfWeakSubjects"))
                        (oldMemory.weaknesses + if (weak.isNotBlank()) "\nTracker weak subjects: $weak" else "").trim()
                    } else oldMemory.weaknesses
                )
            )

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("Could not import JSON: ${e.localizedMessage}", e))
        }
    }

    private fun importTrackerTests(root: JSONObject) {
        val all = mutableListOf<JSONObject>()
        listOf("majorTests", "customTests", "advMajorTests", "advChapterTests", "chapterTests").forEach { key ->
            root.optJSONArray(key)?.let { arr -> for (i in 0 until arr.length()) arr.optJSONObject(i)?.let(all::add) }
        }
        all.forEach { t ->
            val name = t.optString("name", t.optString("testName", "Imported Tracker Test"))
            val scored = t.optDouble("scored", t.optDouble("myscore", t.optDouble("userScore", 0.0))).toInt()
            val maxMarks = t.optDouble("maxmarks", t.optDouble("totalMarks", 300.0)).toInt()
            val questions = t.optInt("questions", t.optInt("attempted", 0))
            val date = t.optString("date", "")
            val epoch = runCatching { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(date.take(10))?.time ?: System.currentTimeMillis() }.getOrElse { System.currentTimeMillis() }
            testRecordDao.insertTest(
                TestRecordEntity(
                    testName = name,
                    testDateEpochMs = epoch,
                    examType = ExamType.BOTH,
                    totalMarks = maxMarks.coerceAtLeast(1),
                    userScore = scored,
                    attempted = questions,
                    correct = t.optInt("correct", 0),
                    incorrect = t.optInt("incorrect", 0),
                    skipped = t.optInt("skipped", 0),
                    timeSpentMinutes = t.optInt("timeMin", 180)
                )
            )
        }
    }

    private fun importTrackerQuestionLogs(root: JSONObject) {
        root.optJSONArray("dailyQuestions")?.let { arr ->
            for (i in 0 until arr.length()) {
                val q = arr.optJSONObject(i) ?: continue
                val subject = parseSubject(q.optString("subject"))
                workLogDao.insertWorkLog(
                    WorkLogEntity(
                        subject = subject,
                        chapter = "",
                        topic = q.optString("level", ""),
                        whatDidYouDo = "Tracker daily question log",
                        durationMinutes = q.optInt("timeMin", 0),
                        questionsAttempted = q.optInt("count", q.optInt("questions", 0)),
                        questionsCorrect = 0,
                        notes = q.optString("note", ""),
                        timestampEpochMs = parseDate(q.optString("date"))
                    )
                )
            }
        }
        root.optJSONArray("coachingLog")?.let { arr ->
            for (i in 0 until arr.length()) {
                val q = arr.optJSONObject(i) ?: continue
                workLogDao.insertWorkLog(
                    WorkLogEntity(
                        subject = parseSubject(q.optString("subject")),
                        chapter = "",
                        topic = q.optString("topics", ""),
                        whatDidYouDo = "Tracker coaching log",
                        durationMinutes = 0,
                        notes = q.optString("homework", "") +
                                if (q.optBoolean("homeworkDone", false)) " • Homework done" else "",
                        timestampEpochMs = parseDate(q.optString("date"))
                    )
                )
            }
        }
        root.optJSONArray("studyHours")?.let { arr ->
            for (i in 0 until arr.length()) {
                val q = arr.optJSONObject(i) ?: continue
                val date = parseDate(q.optString("date"))
                listOf(
                    Subject.PHYSICS to q.optDouble("physicsHours", 0.0),
                    Subject.CHEMISTRY to q.optDouble("chemistryHours", 0.0),
                    Subject.MATHEMATICS to q.optDouble("mathsHours", 0.0)
                ).forEach { (subject, hours) ->
                    if (hours > 0) workLogDao.insertWorkLog(
                        WorkLogEntity(
                            subject = subject,
                            chapter = "",
                            topic = "Self-study hours",
                            whatDidYouDo = "Tracker study-hours log",
                            durationMinutes = (hours * 60).toInt(),
                            timestampEpochMs = date
                        )
                    )
                }
            }
        }
    }

    private fun importTrackerProgress(root: JSONObject) {
        listOf("progressData" to root.optJSONObject("progressData"), "advProgressData" to root.optJSONObject("advProgressData"))
            .forEach { (prefix, obj) ->
                obj?.keys()?.forEach { key ->
                    val value = obj.opt(key)
                    val pct = when (value) {
                        is JSONArray -> if (value.length() == 0) 0 else (0 until value.length()).count { value.optBoolean(it, false) } * 100 / value.length()
                        is JSONObject -> value.optInt("percent", value.optInt("progress", 0))
                        else -> 0
                    }.coerceIn(0, 100)
                    syllabusDao.insertTopic(
                        SyllabusTopicEntity(
                            subject = when {
                                key.contains("phy", true) -> Subject.PHYSICS
                                key.contains("chem", true) -> Subject.CHEMISTRY
                                else -> Subject.MATHEMATICS
                            },
                            chapter = "$prefix:$key",
                            topicName = "Imported Tracker progress",
                            state = when {
                                pct >= 90 -> TopicState.STRONG
                                pct >= 40 -> TopicState.LEARNING
                                else -> TopicState.NOT_STARTED
                            },
                            confidenceScore = pct,
                            notes = "Imported from JEE Battle Royale Tracker JSON"
                        )
                    )
                }
            }
    }

    private fun importTrackerSchedule(root: JSONObject) {
        val slots = mutableListOf<ScheduleSlot>()
        root.optJSONArray("dailySchedule")?.let { arr ->
            for (i in 0 until arr.length()) {
                val b = arr.optJSONObject(i) ?: continue
                val label = b.optString("label", b.optString("title", "Imported block"))
                val subject = parseSubject(b.optString("subject"))
                val duration = b.optString("duration", "").filter { it.isDigit() }.toIntOrNull() ?: 60
                slots += ScheduleSlot(
                    title = label,
                    timeRange = b.optString("time", ""),
                    subject = subject,
                    chapterOrTask = b.optString("note", ""),
                    targetMinutes = duration
                )
            }
        }
        if (slots.isNotEmpty()) preferencesManager.saveScheduleSlots(slots)
    }

    private fun importTrackerTargets(root: JSONObject) {
        root.optJSONArray("dailyTargets")?.let { arr ->
            for (i in 0 until arr.length()) {
                val t = arr.optJSONObject(i) ?: continue
                val label = t.optString("label", "Imported Tracker Target")
                val target = t.optInt("targetValue", 1).coerceAtLeast(1)
                missionDao.insertMission(
                    MissionEntity(
                        title = label,
                        subject = parseSubject(label),
                        chapter = "Tracker target",
                        topic = t.optString("unit", ""),
                        plannedDurationMinutes = 30,
                        targetQuantity = target,
                        priority = PriorityLevel.HIGH,
                        createdBy = MissionCreator.USER,
                        notes = "Imported from JEE Battle Royale Tracker JSON"
                    )
                )
            }
        }
    }

    private fun parseSubject(raw: String): Subject = when {
        raw.contains("phys", true) -> Subject.PHYSICS
        raw.contains("chem", true) -> Subject.CHEMISTRY
        else -> Subject.MATHEMATICS
    }

    private fun parseDate(raw: String): Long =
        runCatching { java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).parse(raw.take(10))?.time ?: System.currentTimeMillis() }
            .getOrElse { System.currentTimeMillis() }

    private fun jsonStringArray(arr: JSONArray?): String =
        if (arr == null) "" else (0 until arr.length()).joinToString(", ") { arr.optString(it) }

    private fun buildJsonContextSummary(root: JSONObject, tracker: Boolean): String {
        val keys = root.keys().asSequence().toList()
        val counts = keys.mapNotNull { k ->
            root.optJSONArray(k)?.let { "$k=${it.length()}" } ?: root.optJSONObject(k)?.let { "$k=${it.length()} keys" }
        }
        return buildString {
            append(if (tracker) "Tracker JSON imported. " else "Generic JSON imported. ")
            append("Top-level keys: ")
            append(keys.joinToString(", ").take(3000))
            if (counts.isNotEmpty()) {
                append(". Structured counts: ")
                append(counts.joinToString(", ").take(3000))
            }
        }.take(7000)
    }

    suspend fun clearAllData() = withContext(Dispatchers.IO) {
        database.withTransaction {
            missionDao.clearAll()
            focusSessionDao.clearAll()
            chatDao.clearAllChats()
            chatDao.clearAllMessages()
            syllabusDao.clearAll()
            testRecordDao.clearAll()
            workLogDao.clearAll()
        }
        preferencesManager.clearAllPreferences()
    }
}
