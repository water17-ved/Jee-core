# JEE CORE UI Showcase Redesign

This revision intentionally moves the native UI closer to the supplied JEE CORE showcase image.

## Visual changes
- Command Center home now has a compact JEE CORE identity header with logo and online status.
- Hero area now behaves like a player/mission HUD: Today's Mission, level, progress and real metrics.
- Dark glass surfaces use soft gradients, large radii and subtle neon edge depth instead of flat square cards.
- Subject zones retain Physics/Chemistry/Maths identity and use real stored question counts.
- Quick actions are compact HUD tiles rather than generic Material buttons.
- Bottom navigation is now a custom floating HUD rail with selected-state gradient.
- AI Chat header uses the JEE CORE logo and online state.
- AI welcome state has an AI Coach identity panel and prompt chips.
- Chat composer is a rounded Gemini-style pill with borderless text input.
- AI responses have a compact JEE CORE avatar/identity row.

## Product behavior preserved
This is a visual redesign only; existing data, Gemini, reports, JSON import, multimedia attachments, missions and history architecture are retained.

## Verification
Static source/resource checks were run. Full Gradle compilation could not be completed in this environment because the Gradle 9.3.1 distribution could not be downloaded (network/DNS unavailable).
