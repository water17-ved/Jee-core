package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ChatAttachment
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.PriorityLevel
import com.example.report.model.ReportFormat
import com.example.report.model.ReportType
import com.example.report.ui.ReportProgressDialog
import com.example.ui.dialogs.CreateMissionDialog
import com.example.ui.dialogs.LogWorkDialog
import com.example.ui.dialogs.TestRecordDialog
import com.example.ui.navigation.Screen
import com.example.ui.screens.AnalysisProgressScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.CoachScreen
import com.example.ui.screens.FocusTimerScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.MissionScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrackerOrange
import com.example.ui.theme.TrackerGold
import com.example.ui.viewmodel.JeeCoreViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: JeeCoreViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: JeeCoreViewModel) {
    val context = LocalContext.current

    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val aiBehaviour by viewModel.aiBehaviour.collectAsStateWithLifecycle()
    val jeeMemory by viewModel.jeeMemory.collectAsStateWithLifecycle()
    val analysisProgressState by viewModel.analysisProgressState.collectAsStateWithLifecycle()

    var currentScreen by remember { mutableStateOf<Screen>(Screen.Coach) }

    // Modals / Overlays
    var focusTargetMission by remember { mutableStateOf<MissionEntity?>(null) }
    var showFocusScreen by remember { mutableStateOf(false) }
    var showLogWorkDialog by remember { mutableStateOf(false) }
    var showCreateMissionDialog by remember { mutableStateOf(false) }
    var showTestRecordDialog by remember { mutableStateOf(false) }

    if (!userProfile.isOnboardingComplete) {
        OnboardingScreen(
            currentProfile = userProfile,
            currentAIBehaviour = aiBehaviour,
            currentMemory = jeeMemory,
            onComplete = { newProfile, newAI, newMem, newKey ->
                viewModel.saveUserProfile(newProfile)
                viewModel.saveAIBehaviour(newAI)
                viewModel.saveJeeMemory(newMem)
                if (newKey.isNotBlank()) {
                    viewModel.saveCustomApiKey(newKey)
                }
            }
        )
    } else if (analysisProgressState != null && !analysisProgressState!!.isMinimized) {
        AnalysisProgressScreen(
            state = analysisProgressState!!,
            onCancel = { viewModel.cancelHeavyAnalysis() },
            onMinimize = { viewModel.minimizeHeavyAnalysis() },
            onRetry = { viewModel.retryHeavyAnalysis() },
            onOpenReport = { file -> viewModel.openReport(file) },
            onShareReport = { file -> viewModel.shareReport(file) },
            onDismiss = { viewModel.dismissHeavyAnalysis() }
        )
    } else if (showFocusScreen) {
        FocusTimerScreen(
            mission = focusTargetMission,
            onNavigateBack = {
                showFocusScreen = false
                focusTargetMission = null
            },
            onSessionCompleted = { session ->
                viewModel.recordFocusSession(session)
            }
        )
    } else {
        Scaffold(
            bottomBar = {
                Column {
                    if (analysisProgressState != null && analysisProgressState!!.isMinimized) {
                        Surface(
                            color = Color(0xFF0F2332),
                            shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp),
                            border = BorderStroke(1.dp, ElectricCyanPrimary.copy(alpha = 0.6f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.restoreHeavyAnalysis() }
                                .testTag("floating_minimized_analysis_bar")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    progress = { analysisProgressState!!.overallProgress },
                                    modifier = Modifier.size(16.dp),
                                    color = ElectricCyanPrimary,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Analyzing: ${analysisProgressState!!.sourceFileName}",
                                        color = TextPrimary,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${(analysisProgressState!!.overallProgress * 100).toInt()}% • ${analysisProgressState!!.currentSubtaskHeadline}",
                                        color = ElectricCyanPrimary,
                                        fontSize = 10.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Text(
                                    text = "RESUME",
                                    color = ElectricCyanPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }

                    NavigationBar(
                    containerColor = DarkSlateCard.copy(alpha = 0.96f),
                    contentColor = TextPrimary,
                    tonalElevation = 0.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(30.dp))
                        .border(
                            width = 1.dp,
                            color = Color.White.copy(alpha = 0.055f),
                            shape = RoundedCornerShape(30.dp)
                        )
                ) {
                    Screen.bottomNavItems.filterNotNull().forEach { screen ->
                        val selected = currentScreen == screen
                        NavigationBarItem(
                            selected = selected,
                            onClick = { currentScreen = screen },
                            icon = {
                                Icon(
                                    imageVector = if (selected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.title,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 10.sp,
                                    fontWeight = if (selected) FontWeight.Black else FontWeight.Medium
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TrackerGold,
                                selectedTextColor = TrackerGold,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = TrackerOrange.copy(alpha = 0.18f)
                            ),
                            modifier = Modifier.testTag("nav_item_${screen.route}")
                        )
                    }
                }
            }
        },
        containerColor = DarkSlateBackground
    ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (currentScreen) {
                    Screen.Coach -> {
                        val coachState by viewModel.coachState.collectAsStateWithLifecycle()
                        val coachWorkLogs by viewModel.workLogs.collectAsStateWithLifecycle()
                        val coachTests by viewModel.testRecords.collectAsStateWithLifecycle()
                        val coachTopics by viewModel.syllabusTopics.collectAsStateWithLifecycle()
                        CoachScreen(
                            coachState = coachState,
                            onStartMission = { m ->
                                viewModel.updateMission(m.copy(status = MissionStatus.IN_PROGRESS, startedAtEpochMs = System.currentTimeMillis()))
                                focusTargetMission = m
                                showFocusScreen = true
                            },
                            onCompleteMission = { m ->
                                viewModel.updateMission(
                                    m.copy(
                                        status = MissionStatus.COMPLETED,
                                        completedQuantity = m.targetQuantity,
                                        completedAtEpochMs = System.currentTimeMillis()
                                    )
                                )
                            },
                            onRescheduleMission = { m ->
                                viewModel.updateMission(
                                    m.copy(
                                        status = MissionStatus.RESCHEDULED,
                                        deadlineEpochMs = System.currentTimeMillis() + (48 * 3600 * 1000L)
                                    )
                                )
                            },
                            onSkipMission = { m ->
                                viewModel.updateMission(m.copy(status = MissionStatus.SKIPPED))
                            },
                            onOpenCreateMission = { showCreateMissionDialog = true },
                            onOpenLogWork = { showLogWorkDialog = true },
                            onOpenFocusTimer = { m ->
                                focusTargetMission = m
                                showFocusScreen = true
                            },
                            onAskCoach = { prompt ->
                                currentScreen = Screen.Chat
                                viewModel.createChat("Tactical Check-in", initialPrompt = prompt)
                            },
                            workLogs = coachWorkLogs,
                            testRecords = coachTests,
                            syllabusTopics = coachTopics
                        )
                    }

                    Screen.Chat -> {
                        val chats by viewModel.chats.collectAsStateWithLifecycle()
                        val activeChatId by viewModel.activeChatId.collectAsStateWithLifecycle()
                        val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
                        val aiProgressStage by viewModel.aiProgressStage.collectAsStateWithLifecycle()
                        ChatScreen(
                            chats = chats,
                            activeChatId = activeChatId,
                            messages = chatMessages,
                            aiProgressStage = aiProgressStage,
                            onSelectChat = { id -> viewModel.selectChat(id) },
                            onBackToList = { viewModel.selectChat(-1) },
                            onCreateChat = { title -> viewModel.createChat(title) },
                            onRenameChat = { id, newTitle -> viewModel.renameChat(id, newTitle) },
                            onDeleteChat = { id -> viewModel.deleteChat(id) },
                            onSendMessage = { prompt, mode, attachments -> viewModel.sendChatMessage(prompt, mode, attachments) },
                            onRetryMessage = { msg ->
                                viewModel.retryChatMessage(msg)
                            },
                            onRegenerateMessage = { msg ->
                                viewModel.regenerateResponse(msg)
                            },
                            onDeleteMessage = { msgId ->
                                viewModel.deleteChatMessage(msgId)
                            },
                            onCancelGeneration = {
                                viewModel.cancelGeneration()
                            },
                            onSwitchReportFormat = { repType, newFormat ->
                                viewModel.requestReportFormatFromChat(repType, newFormat)
                            },
                            onStartHeavyAnalysis = { fileName ->
                                viewModel.startHeavyAnalysis(fileName = fileName)
                            }
                        )
                    }

                    Screen.Mission -> {
                        val missions by viewModel.missions.collectAsStateWithLifecycle()
                        MissionScreen(
                            missions = missions,
                            onStartMission = { m ->
                                viewModel.updateMission(m.copy(status = MissionStatus.IN_PROGRESS, startedAtEpochMs = System.currentTimeMillis()))
                                focusTargetMission = m
                                showFocusScreen = true
                            },
                            onCompleteMission = { m ->
                                viewModel.updateMission(
                                    m.copy(
                                        status = MissionStatus.COMPLETED,
                                        completedQuantity = m.targetQuantity,
                                        completedAtEpochMs = System.currentTimeMillis()
                                    )
                                )
                            },
                            onRescheduleMission = { m ->
                                viewModel.updateMission(
                                    m.copy(
                                        status = MissionStatus.RESCHEDULED,
                                        deadlineEpochMs = System.currentTimeMillis() + (48 * 3600 * 1000L)
                                    )
                                )
                            },
                            onSkipMission = { m ->
                                viewModel.updateMission(m.copy(status = MissionStatus.SKIPPED))
                            },
                            onUpdateMission = { m -> viewModel.updateMission(m) },
                            onDeleteMission = { m -> viewModel.deleteMission(m) },
                            onOpenCreateMission = { showCreateMissionDialog = true }
                        )
                    }

                    Screen.History -> {
                        val missions by viewModel.missions.collectAsStateWithLifecycle()
                        val focusSessions by viewModel.focusSessions.collectAsStateWithLifecycle()
                        val workLogs by viewModel.workLogs.collectAsStateWithLifecycle()
                        val syllabusTopics by viewModel.syllabusTopics.collectAsStateWithLifecycle()
                        val testRecords by viewModel.testRecords.collectAsStateWithLifecycle()
                        val scheduleSlots by viewModel.scheduleSlots.collectAsStateWithLifecycle()
                        HistoryScreen(
                            missions = missions,
                            focusSessions = focusSessions,
                            workLogs = workLogs,
                            syllabusTopics = syllabusTopics,
                            testRecords = testRecords,
                            scheduleSlots = scheduleSlots,
                            onToggleScheduleSlot = { id -> viewModel.toggleScheduleSlot(id) },
                            onAddScheduleSlot = { slot -> viewModel.addScheduleSlot(slot) },
                            onDeleteScheduleSlot = { id -> viewModel.deleteScheduleSlot(id) },
                            onResetScheduleSlots = { viewModel.resetScheduleSlots() },
                            onStartFocusForSlot = { slot ->
                                focusTargetMission = MissionEntity(
                                    title = slot.title,
                                    subject = slot.subject,
                                    chapter = slot.chapterOrTask,
                                    topic = slot.title,
                                    plannedDurationMinutes = slot.targetMinutes,
                                    targetQuantity = 15,
                                    priority = PriorityLevel.HIGH
                                )
                                showFocusScreen = true
                            },
                            onUpdateTopic = { topic -> viewModel.updateTopic(topic) },
                            onOpenRecordTest = { showTestRecordDialog = true },
                            onDeleteTest = { test -> viewModel.deleteTest(test) },
                            onRequestReport = { repType, format, testId ->
                                viewModel.generateReport(repType, format, testId)
                            },
                            onRequestHeavyAnalysis = { fileName ->
                                viewModel.startHeavyAnalysis(fileName = fileName)
                            }
                        )
                    }

                    Screen.Settings -> {
                        val notificationSettings by viewModel.notificationSettings.collectAsStateWithLifecycle()
                        val customApiKey by viewModel.customApiKey.collectAsStateWithLifecycle()
                        SettingsScreen(
                            userProfile = userProfile,
                            aiBehaviour = aiBehaviour,
                            jeeMemory = jeeMemory,
                            notificationSettings = notificationSettings,
                            customApiKey = customApiKey,
                            onSaveProfile = { viewModel.saveUserProfile(it) },
                            onSaveAIBehaviour = { viewModel.saveAIBehaviour(it) },
                            onSaveJeeMemory = { viewModel.saveJeeMemory(it) },
                            onSaveNotificationSettings = { viewModel.saveNotificationSettings(it) },
                            onSaveApiKey = { viewModel.saveCustomApiKey(it) },
                            onTestGeminiConnection = { onResult -> viewModel.testGeminiConnection(onResult) },
                            onExportBackup = { onResult -> viewModel.exportBackup(onResult) },
                            onValidateAndPreviewBackup = { json, callback -> viewModel.validateAndPreviewBackup(json, callback) },
                            onImportBackup = { json, callback -> viewModel.importBackup(json, callback) },
                            onClearAllData = { viewModel.clearAllData() }
                        )
                    }
                }
            }
        }
    }

    // Dialogs
    if (showLogWorkDialog) {
        LogWorkDialog(
            onDismiss = { showLogWorkDialog = false },
            onSave = { log ->
                viewModel.logWork(log)
                showLogWorkDialog = false
            }
        )
    }

    if (showCreateMissionDialog) {
        CreateMissionDialog(
            onDismiss = { showCreateMissionDialog = false },
            onSave = { mission ->
                viewModel.createMission(mission)
                showCreateMissionDialog = false
            }
        )
    }

    if (showTestRecordDialog) {
        TestRecordDialog(
            onDismiss = { showTestRecordDialog = false },
            onSave = { test ->
                viewModel.recordTest(test)
                showTestRecordDialog = false
            }
        )
    }

    val reportProgress by viewModel.reportProgress.collectAsStateWithLifecycle()
    reportProgress?.let { prog ->
        ReportProgressDialog(
            progress = prog,
            reportType = prog.generatedFile?.reportType ?: ReportType.TEST_ANALYSIS,
            format = prog.generatedFile?.format ?: ReportFormat.PDF,
            onDismiss = { viewModel.dismissReportProgress() },
            onSwitchFormat = { repType, newFormat ->
                viewModel.generateReport(repType, newFormat)
            }
        )
    }
}
