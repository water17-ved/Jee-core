package com.example.data.model

import com.squareup.moshi.JsonClass

enum class ExamType(val displayName: String) {
    JEE_MAIN("JEE Main"),
    JEE_ADVANCED("JEE Advanced"),
    BOTH("Both (Main + Advanced)")
}

enum class Subject(val displayName: String) {
    PHYSICS("Physics"),
    CHEMISTRY("Chemistry"),
    MATHEMATICS("Mathematics")
}

enum class PriorityLevel(val displayName: String, val weight: Int) {
    LOW("Low", 1),
    MEDIUM("Medium", 2),
    HIGH("High", 3),
    URGENT("Urgent", 4)
}

enum class MissionStatus(val displayName: String) {
    NOT_STARTED("Not Started"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Completed"),
    SKIPPED("Skipped"),
    RESCHEDULED("Rescheduled")
}

enum class MissionCreator {
    USER,
    AI
}

enum class SubjectLevel(val displayName: String) {
    NOT_STARTED("Not Started"),
    LEARNING("Learning"),
    MIXED("Mixed"),
    STRONG("Strong")
}

@JsonClass(generateAdapter = true)
data class UserProfile(
    val targetExam: ExamType = ExamType.BOTH,
    val targetYear: Int = 2026,
    val targetRank: String = "",
    val physicsLevel: SubjectLevel = SubjectLevel.LEARNING,
    val chemistryLevel: SubjectLevel = SubjectLevel.LEARNING,
    val mathsLevel: SubjectLevel = SubjectLevel.LEARNING,
    val weekdayAvailableHours: Float = 5.0f,
    val weekendAvailableHours: Float = 10.0f,
    val coachingStart: String = "08:00",
    val coachingEnd: String = "13:00",
    val mealsSchedule: String = "13:30, 20:30",
    val fixedCommitments: String = "",
    val weakAreasNotes: String = "",
    val isOnboardingComplete: Boolean = false
)

@JsonClass(generateAdapter = true)
data class AIBehaviour(
    val strictness: Float = 0.65f, // 0 = Gentle, 1 = Strict
    val conciseness: Float = 0.75f, // 0 = Detailed, 1 = Concise
    val directness: Float = 0.85f, // 0 = Explanatory, 1 = Direct
    val executionFocus: Float = 0.90f, // 0 = Discussion, 1 = Execution
    val pressureLevel: Float = 0.60f, // 0 = Low Pressure, 1 = High Pressure
    val adaptability: Float = 0.80f, // 0 = Fixed, 1 = Adaptive
    val actionOrientation: Float = 0.85f, // 0 = Questioning, 1 = Action-oriented
    val customInstructions: String = "Do not give generic motivation. Focus on tactical JEE problem solving, PYQ accuracy, and time-boxed execution."
)

@JsonClass(generateAdapter = true)
data class JeeMemory(
    val targetSummary: String = "",
    val strengths: String = "",
    val weaknesses: String = "",
    val coachingSchedule: String = "",
    val recurringProblems: String = "",
    val studyPreferences: String = "",
    val backlogNotes: String = "",
    val revisionStateSummary: String = "",
    val importedDataContext: String = ""
)

@JsonClass(generateAdapter = true)
data class ScheduleSlot(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val timeRange: String, // e.g., "06:00 - 08:30"
    val subject: Subject,
    val chapterOrTask: String,
    val targetMinutes: Int = 150,
    val isCompleted: Boolean = false,
    val slotPeriod: String = "Morning" // Morning, Afternoon, Evening, Night
)
