package com.example.data.preference

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AIBehaviour
import com.example.data.model.ExamType
import com.example.data.model.JeeMemory
import com.example.data.model.NotificationSettings
import com.example.data.model.ScheduleSlot
import com.example.data.model.Subject
import com.example.data.model.SubjectLevel
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class UserPreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("jee_core_prefs", Context.MODE_PRIVATE)

    private val _userProfile = MutableStateFlow(loadUserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _aiBehaviour = MutableStateFlow(loadAIBehaviour())
    val aiBehaviour: StateFlow<AIBehaviour> = _aiBehaviour.asStateFlow()

    private val _jeeMemory = MutableStateFlow(loadJeeMemory())
    val jeeMemory: StateFlow<JeeMemory> = _jeeMemory.asStateFlow()

    private val _notificationSettings = MutableStateFlow(loadNotificationSettings())
    val notificationSettings: StateFlow<NotificationSettings> = _notificationSettings.asStateFlow()

    private val _customGeminiKey = MutableStateFlow(prefs.getString("custom_gemini_key", "") ?: "")
    val customGeminiKey: StateFlow<String> = _customGeminiKey.asStateFlow()

    private val _scheduleSlots = MutableStateFlow(loadScheduleSlots())
    val scheduleSlots: StateFlow<List<ScheduleSlot>> = _scheduleSlots.asStateFlow()

    fun saveUserProfile(profile: UserProfile) {
        prefs.edit().apply {
            putString("target_exam", profile.targetExam.name)
            putInt("target_year", profile.targetYear)
            putString("target_rank", profile.targetRank)
            putString("physics_level", profile.physicsLevel.name)
            putString("chemistry_level", profile.chemistryLevel.name)
            putString("maths_level", profile.mathsLevel.name)
            putFloat("weekday_hours", profile.weekdayAvailableHours)
            putFloat("weekend_hours", profile.weekendAvailableHours)
            putString("coaching_start", profile.coachingStart)
            putString("coaching_end", profile.coachingEnd)
            putString("meals_schedule", profile.mealsSchedule)
            putString("fixed_commitments", profile.fixedCommitments)
            putString("weak_areas_notes", profile.weakAreasNotes)
            putBoolean("is_onboarding_complete", profile.isOnboardingComplete)
            apply()
        }
        _userProfile.value = profile
    }

    fun saveAIBehaviour(behaviour: AIBehaviour) {
        prefs.edit().apply {
            putFloat("strictness", behaviour.strictness)
            putFloat("conciseness", behaviour.conciseness)
            putFloat("directness", behaviour.directness)
            putFloat("execution_focus", behaviour.executionFocus)
            putFloat("pressure_level", behaviour.pressureLevel)
            putFloat("adaptability", behaviour.adaptability)
            putFloat("action_orientation", behaviour.actionOrientation)
            putString("custom_instructions", behaviour.customInstructions)
            apply()
        }
        _aiBehaviour.value = behaviour
    }

    fun saveJeeMemory(memory: JeeMemory) {
        prefs.edit().apply {
            putString("mem_target_summary", memory.targetSummary)
            putString("mem_strengths", memory.strengths)
            putString("mem_weaknesses", memory.weaknesses)
            putString("mem_coaching", memory.coachingSchedule)
            putString("mem_recurring_problems", memory.recurringProblems)
            putString("mem_study_pref", memory.studyPreferences)
            putString("mem_backlog", memory.backlogNotes)
            putString("mem_revision_summary", memory.revisionStateSummary)
            putString("mem_imported_context", memory.importedDataContext)
            apply()
        }
        _jeeMemory.value = memory
    }

    fun saveNotificationSettings(settings: NotificationSettings) {
        prefs.edit().apply {
            putBoolean("notif_mission", settings.missionReminders)
            putBoolean("notif_focus", settings.focusCompleteNotification)
            putBoolean("notif_revision", settings.revisionDueNotification)
            putBoolean("notif_test", settings.testReminders)
            putBoolean("notif_backlog", settings.backlogReminders)
            apply()
        }
        _notificationSettings.value = settings
    }

    fun saveCustomGeminiKey(key: String) {
        prefs.edit().putString("custom_gemini_key", key).apply()
        _customGeminiKey.value = key
    }

    fun clearAllPreferences() {
        prefs.edit().clear().apply()
        _userProfile.value = UserProfile()
        _aiBehaviour.value = AIBehaviour()
        _jeeMemory.value = JeeMemory()
        _notificationSettings.value = NotificationSettings()
        _customGeminiKey.value = ""
    }

    private fun loadUserProfile(): UserProfile {
        val examStr = prefs.getString("target_exam", ExamType.BOTH.name)
        val targetExam = try { ExamType.valueOf(examStr ?: ExamType.BOTH.name) } catch (e: Exception) { ExamType.BOTH }
        return UserProfile(
            targetExam = targetExam,
            targetYear = prefs.getInt("target_year", 2026),
            targetRank = prefs.getString("target_rank", "") ?: "",
            physicsLevel = parseSubjectLevel(prefs.getString("physics_level", SubjectLevel.LEARNING.name)),
            chemistryLevel = parseSubjectLevel(prefs.getString("chemistry_level", SubjectLevel.LEARNING.name)),
            mathsLevel = parseSubjectLevel(prefs.getString("maths_level", SubjectLevel.LEARNING.name)),
            weekdayAvailableHours = prefs.getFloat("weekday_hours", 5.0f),
            weekendAvailableHours = prefs.getFloat("weekend_hours", 10.0f),
            coachingStart = prefs.getString("coaching_start", "08:00") ?: "08:00",
            coachingEnd = prefs.getString("coaching_end", "13:00") ?: "13:00",
            mealsSchedule = prefs.getString("meals_schedule", "13:30, 20:30") ?: "13:30, 20:30",
            fixedCommitments = prefs.getString("fixed_commitments", "") ?: "",
            weakAreasNotes = prefs.getString("weak_areas_notes", "") ?: "",
            isOnboardingComplete = prefs.getBoolean("is_onboarding_complete", false)
        )
    }

    private fun parseSubjectLevel(str: String?): SubjectLevel {
        return try {
            SubjectLevel.valueOf(str ?: SubjectLevel.LEARNING.name)
        } catch (e: Exception) {
            SubjectLevel.LEARNING
        }
    }

    private fun loadAIBehaviour(): AIBehaviour {
        return AIBehaviour(
            strictness = prefs.getFloat("strictness", 0.65f),
            conciseness = prefs.getFloat("conciseness", 0.75f),
            directness = prefs.getFloat("directness", 0.85f),
            executionFocus = prefs.getFloat("execution_focus", 0.90f),
            pressureLevel = prefs.getFloat("pressure_level", 0.60f),
            adaptability = prefs.getFloat("adaptability", 0.80f),
            actionOrientation = prefs.getFloat("action_orientation", 0.85f),
            customInstructions = prefs.getString(
                "custom_instructions",
                "Do not give generic motivation. Focus on tactical JEE problem solving, PYQ accuracy, and time-boxed execution."
            ) ?: ""
        )
    }

    private fun loadJeeMemory(): JeeMemory {
        return JeeMemory(
            targetSummary = prefs.getString("mem_target_summary", "") ?: "",
            strengths = prefs.getString("mem_strengths", "") ?: "",
            weaknesses = prefs.getString("mem_weaknesses", "") ?: "",
            coachingSchedule = prefs.getString("mem_coaching", "") ?: "",
            recurringProblems = prefs.getString("mem_recurring_problems", "") ?: "",
            studyPreferences = prefs.getString("mem_study_pref", "") ?: "",
            backlogNotes = prefs.getString("mem_backlog", "") ?: "",
            revisionStateSummary = prefs.getString("mem_revision_summary", "") ?: "",
            importedDataContext = prefs.getString("mem_imported_context", "") ?: ""
        )
    }

    private fun loadNotificationSettings(): NotificationSettings {
        return NotificationSettings(
            missionReminders = prefs.getBoolean("notif_mission", true),
            focusCompleteNotification = prefs.getBoolean("notif_focus", true),
            revisionDueNotification = prefs.getBoolean("notif_revision", true),
            testReminders = prefs.getBoolean("notif_test", true),
            backlogReminders = prefs.getBoolean("notif_backlog", true)
        )
    }

    fun saveScheduleSlots(slots: List<ScheduleSlot>) {
        val array = JSONArray()
        slots.forEach { slot ->
            val obj = JSONObject().apply {
                put("id", slot.id)
                put("title", slot.title)
                put("timeRange", slot.timeRange)
                put("subject", slot.subject.name)
                put("chapterOrTask", slot.chapterOrTask)
                put("targetMinutes", slot.targetMinutes)
                put("isCompleted", slot.isCompleted)
                put("slotPeriod", slot.slotPeriod)
            }
            array.put(obj)
        }
        prefs.edit().putString("schedule_slots_json", array.toString()).apply()
        _scheduleSlots.value = slots
    }

    fun toggleScheduleSlot(slotId: String) {
        val updated = _scheduleSlots.value.map {
            if (it.id == slotId) it.copy(isCompleted = !it.isCompleted) else it
        }
        saveScheduleSlots(updated)
    }

    fun addScheduleSlot(slot: ScheduleSlot) {
        val updated = _scheduleSlots.value + slot
        saveScheduleSlots(updated)
    }

    fun deleteScheduleSlot(slotId: String) {
        val updated = _scheduleSlots.value.filter { it.id != slotId }
        saveScheduleSlots(updated)
    }

    fun resetScheduleSlotsToDefaults() {
        saveScheduleSlots(getDefaultScheduleSlots())
    }

    private fun loadScheduleSlots(): List<ScheduleSlot> {
        val json = prefs.getString("schedule_slots_json", null)
        if (json.isNullOrBlank()) {
            return getDefaultScheduleSlots()
        }
        return try {
            val array = JSONArray(json)
            val list = mutableListOf<ScheduleSlot>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    ScheduleSlot(
                        id = obj.optString("id", java.util.UUID.randomUUID().toString()),
                        title = obj.optString("title", "Study Block"),
                        timeRange = obj.optString("timeRange", "09:00 - 11:30"),
                        subject = try { Subject.valueOf(obj.optString("subject", "PHYSICS")) } catch (e: Exception) { Subject.PHYSICS },
                        chapterOrTask = obj.optString("chapterOrTask", "Problem Solving"),
                        targetMinutes = obj.optInt("targetMinutes", 150),
                        isCompleted = obj.optBoolean("isCompleted", false),
                        slotPeriod = obj.optString("slotPeriod", "Morning")
                    )
                )
            }
            if (list.isEmpty()) getDefaultScheduleSlots() else list
        } catch (e: Exception) {
            getDefaultScheduleSlots()
        }
    }

    private fun getDefaultScheduleSlots(): List<ScheduleSlot> {
        return listOf(
            ScheduleSlot(
                title = "Morning Problem Sprint",
                timeRange = "06:00 - 08:30",
                subject = Subject.PHYSICS,
                chapterOrTask = "Rotational Dynamics & Mechanics",
                targetMinutes = 150,
                isCompleted = false,
                slotPeriod = "Morning"
            ),
            ScheduleSlot(
                title = "Core Theory & Practice",
                timeRange = "10:00 - 13:00",
                subject = Subject.CHEMISTRY,
                chapterOrTask = "Organic Reaction Mechanisms",
                targetMinutes = 180,
                isCompleted = false,
                slotPeriod = "Afternoon"
            ),
            ScheduleSlot(
                title = "Intensive Maths Solving",
                timeRange = "15:00 - 18:00",
                subject = Subject.MATHEMATICS,
                chapterOrTask = "Definite Integration & Area Under Curve",
                targetMinutes = 180,
                isCompleted = false,
                slotPeriod = "Evening"
            ),
            ScheduleSlot(
                title = "Evening Mock / PYQ Drill",
                timeRange = "19:30 - 21:30",
                subject = Subject.PHYSICS,
                chapterOrTask = "Electrodynamics & Optics Drill",
                targetMinutes = 120,
                isCompleted = false,
                slotPeriod = "Evening"
            ),
            ScheduleSlot(
                title = "Night Formula Revision",
                timeRange = "22:30 - 23:30",
                subject = Subject.CHEMISTRY,
                chapterOrTask = "Physical Chemistry Formulas & Notes",
                targetMinutes = 60,
                isCompleted = false,
                slotPeriod = "Night"
            )
        )
    }
}
