package com.example.data.model

data class ChatAttachment(
    val name: String,
    val uri: String,
    val text: String? = null,
    val base64: String? = null,
    val mimeType: String? = null
)
