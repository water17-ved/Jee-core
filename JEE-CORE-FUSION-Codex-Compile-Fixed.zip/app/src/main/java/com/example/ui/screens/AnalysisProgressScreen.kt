package com.example.ui.screens

import com.example.ui.components.JeeSurface
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Subject
import com.example.report.ReportManager
import com.example.report.model.AnalysisPhase
import com.example.report.model.AnalysisProgressState
import com.example.report.model.AnalysisResultSummary
import com.example.report.model.ExtractedQuestionItem
import com.example.report.model.GeneratedReportFile
import com.example.report.model.PhaseProgressItem
import com.example.report.model.PhaseStatus
import com.example.report.model.ReportFormat
import com.example.report.model.TelemetryLogEntry
import com.example.report.model.TelemetryLogLevel
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AnalysisProgressScreen(
    state: AnalysisProgressState,
    onCancel: () -> Unit,
    onMinimize: () -> Unit,
    onRetry: () -> Unit,
    onOpenReport: (GeneratedReportFile) -> Unit,
    onShareReport: (GeneratedReportFile) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showCancelConfirmDialog by remember { mutableStateOf(false) }
    var isTerminalExpanded by remember { mutableStateOf(true) }
    var showTaxonomyPreview by remember { mutableStateOf(true) }

    val terminalListState = rememberLazyListState()

    // Auto-scroll telemetry terminal to latest entry
    LaunchedEffect(state.telemetryLogs.size) {
        if (state.telemetryLogs.isNotEmpty()) {
            terminalListState.animateScrollToItem(state.telemetryLogs.size - 1)
        }
    }

    val animatedOverallProgress by animateFloatAsState(
        targetValue = state.overallProgress,
        animationSpec = tween(durationMillis = 350, easing = FastOutSlowInEasing),
        label = "overall_progress_anim"
    )

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = DarkSlateBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "JEE CORE ANALYSIS ENGINE",
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(24.dp))
                                    .background(ElectricCyanPrimary.copy(alpha = 0.15f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (state.isCompleted) "COMPLETE" else if (state.isCancelled) "CANCELLED" else "REAL-TIME",
                                    color = if (state.isCompleted) SuccessGreen else if (state.isCancelled) Color(0xFFEF4444) else ElectricCyanPrimary,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Text(
                            text = "${state.sourceFileName} (${state.sourceFileSizeFormatted})",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (state.isCompleted || state.isCancelled) onDismiss() else onMinimize()
                        },
                        modifier = Modifier.testTag("btn_minimize_analysis")
                    ) {
                        Icon(
                            imageVector = if (state.isCompleted || state.isCancelled) Icons.AutoMirrored.Filled.ArrowBack else Icons.Default.KeyboardArrowDown,
                            contentDescription = "Minimize or back",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    if (!state.isCompleted && !state.isCancelled) {
                        IconButton(
                            onClick = { showCancelConfirmDialog = true },
                            modifier = Modifier.testTag("btn_cancel_analysis_top")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel Analysis",
                                tint = Color(0xFFEF4444)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSlateCard
                ),
                modifier = Modifier.border(width = 0.8.dp, color = DarkSlateBorder)
            )
        },
        bottomBar = {
            AnalysisBottomActionBar(
                state = state,
                onCancel = { showCancelConfirmDialog = true },
                onMinimize = onMinimize,
                onRetry = onRetry,
                onOpenReport = onOpenReport,
                onShareReport = onShareReport,
                onDismiss = onDismiss
            )
        },
        modifier = modifier.testTag("screen_analysis_progress")
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Hero HUD Progress Gauge
            item {
                HeroProgressHudCard(
                    state = state,
                    animatedProgress = animatedOverallProgress
                )
            }

            // 2. Result Summary Card (When complete)
            if (state.isCompleted && state.resultSummary != null) {
                item {
                    AnalysisResultSummaryCard(
                        summary = state.resultSummary,
                        onOpen = { state.resultSummary.generatedReportFile?.let { onOpenReport(it) } },
                        onShare = { state.resultSummary.generatedReportFile?.let { onShareReport(it) } }
                    )
                }
            }

            // 3. Error Alert (When failed)
            if (state.errorMessage != null && !state.isCancelled) {
                item {
                    AnalysisErrorCard(
                        errorMessage = state.errorMessage,
                        onRetry = onRetry
                    )
                }
            }

            // 4. Stepper: 5-Phase Diagnostic Pipeline
            item {
                Text(
                    text = "ACADEMIC PIPELINE PHASES",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyanPrimary,
                    letterSpacing = 1.sp
                )
            }

            items(state.phaseItems) { phaseItem ->
                PhaseStepCard(phaseItem = phaseItem)
            }

            // 5. Extracted Taxonomy Preview
            if (state.extractedQuestionsPreview.isNotEmpty()) {
                item {
                    ExtractedTaxonomyPreviewCard(
                        questions = state.extractedQuestionsPreview,
                        isExpanded = showTaxonomyPreview,
                        onToggleExpand = { showTaxonomyPreview = !showTaxonomyPreview }
                    )
                }
            }

            // 6. Live Telemetry Console Log
            item {
                TelemetryTerminalCard(
                    logs = state.telemetryLogs,
                    listState = terminalListState,
                    isExpanded = isTerminalExpanded,
                    onToggleExpand = { isTerminalExpanded = !isTerminalExpanded },
                    onCopyLogs = {
                        val text = state.telemetryLogs.joinToString("\n") {
                            "[${it.tag}] ${it.message}"
                        }
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("JEE CORE Logs", text))
                        Toast.makeText(context, "Telemetry logs copied to clipboard", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }
    }

    // Cancel Confirmation Dialog
    if (showCancelConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showCancelConfirmDialog = false },
            title = {
                Text(
                    text = "Abort Heavy Analysis?",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to cancel? Current OCR tokenization and document compilation progress will be discarded.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showCancelConfirmDialog = false
                        onCancel()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                    modifier = Modifier.testTag("btn_confirm_cancel_analysis")
                ) {
                    Text("Yes, Abort", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showCancelConfirmDialog = false },
                    modifier = Modifier.testTag("btn_dismiss_cancel_dialog")
                ) {
                    Text("Continue Analysis", color = ElectricCyanPrimary)
                }
            },
            containerColor = DarkSlateCard,
            modifier = Modifier.testTag("dialog_cancel_confirmation")
        )
    }
}

@Composable
private fun HeroProgressHudCard(
    state: AnalysisProgressState,
    animatedProgress: Float
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_trans")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        border = BorderStroke(1.dp, if (state.isCompleted) SuccessGreen.copy(alpha = 0.5f) else DarkSlateBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_hero_hud")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                if (state.isCompleted) SuccessGreen
                                else if (state.isCancelled) Color(0xFFEF4444)
                                else ElectricCyanPrimary.copy(alpha = pulseAlpha)
                            )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isCompleted) "AUDIT COMPLETE" else if (state.isCancelled) "PROCESS STOPPED" else "PHASE ${state.currentPhase.stepNumber} OF 5: ${state.currentPhase.name}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (state.isCompleted) SuccessGreen else ElectricCyanPrimary,
                        letterSpacing = 0.8.sp
                    )
                }

                Text(
                    text = "${(animatedProgress * 100).toInt()}%",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = if (state.isCompleted) SuccessGreen else ElectricCyanPrimary,
                    modifier = Modifier.testTag("text_overall_percentage")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Animated Dual-Track Progress Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(0xFF0F172A))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(animatedProgress)
                        .height(10.dp)
                        .background(
                            Brush.horizontalGradient(
                                colors = if (state.isCompleted) {
                                    listOf(SuccessGreen, Color(0xFF34D399))
                                } else {
                                    listOf(ElectricCyanPrimary, Color(0xFF38BDF8), Color(0xFF818CF8))
                                }
                            )
                        )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Live Operation Subtask Headline
            Text(
                text = state.currentSubtaskHeadline,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.testTag("text_current_subtask")
            )

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = DarkSlateBorder, thickness = 0.8.dp)
            Spacer(modifier = Modifier.height(12.dp))

            // Real-Time Diagnostic KPI Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                KpiHudChip(
                    label = "ELAPSED",
                    value = String.format("%02d:%02d", state.elapsedSeconds / 60, state.elapsedSeconds % 60)
                )
                KpiHudChip(
                    label = "EST. REMAINING",
                    value = if (state.isCompleted) "00:00" else "~${state.estimatedSecondsRemaining}s"
                )
                KpiHudChip(
                    label = "QUESTIONS",
                    value = "${state.extractedQuestionsPreview.size} Extracted"
                )
                KpiHudChip(
                    label = "INTEGRITY",
                    value = if (state.isCompleted) "Verified" else "Validating"
                )
            }
        }
    }
}

@Composable
private fun KpiHudChip(
    label: String,
    value: String
) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary,
            letterSpacing = 0.5.sp
        )
        Text(
            text = value,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )
    }
}

@Composable
private fun PhaseStepCard(
    phaseItem: PhaseProgressItem
) {
    val isRunning = phaseItem.status == PhaseStatus.ACTIVE
    val isCompleted = phaseItem.status == PhaseStatus.COMPLETED
    val isFailed = phaseItem.status == PhaseStatus.FAILED

    val borderColor by animateColorAsState(
        targetValue = when {
            isRunning -> ElectricCyanPrimary.copy(alpha = 0.8f)
            isCompleted -> SuccessGreen.copy(alpha = 0.4f)
            isFailed -> Color(0xFFEF4444)
            else -> DarkSlateBorder
        },
        label = "phase_border_color"
    )

    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isRunning) Color(0xFF0F2332) else DarkSlateCard
        ),
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("phase_card_${phaseItem.phase.name}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Phase Step Icon Indicator
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isCompleted -> SuccessGreen.copy(alpha = 0.2f)
                                isRunning -> ElectricCyanPrimary.copy(alpha = 0.2f)
                                isFailed -> Color(0xFFEF4444).copy(alpha = 0.2f)
                                else -> Color(0xFF1E293B)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    when {
                        isCompleted -> Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Completed",
                            tint = SuccessGreen,
                            modifier = Modifier.size(18.dp)
                        )
                        isRunning -> CircularProgressIndicator(
                            strokeWidth = 2.dp,
                            color = ElectricCyanPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        isFailed -> Icon(
                            imageVector = Icons.Default.Error,
                            contentDescription = "Failed",
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(18.dp)
                        )
                        else -> Text(
                            text = "${phaseItem.phase.stepNumber}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = phaseItem.phase.title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isRunning) ElectricCyanPrimary else TextPrimary
                    )
                    Text(
                        text = if (phaseItem.subtaskText.isNotBlank()) phaseItem.subtaskText else phaseItem.phase.shortDescription,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                if (isCompleted) {
                    Text(
                        text = "DONE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = SuccessGreen
                    )
                } else if (isRunning) {
                    Text(
                        text = "${(phaseItem.progress * 100).toInt()}%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ElectricCyanPrimary
                    )
                }
            }

            if (isRunning) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { phaseItem.progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = ElectricCyanPrimary,
                    trackColor = Color(0xFF1E293B)
                )
            }
        }
    }
}

@Composable
private fun AnalysisResultSummaryCard(
    summary: AnalysisResultSummary,
    onOpen: () -> Unit,
    onShare: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF064E3B).copy(alpha = 0.35f)),
        border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.6f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_analysis_result_summary")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = SuccessGreen,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "AUDIT ARTIFACTS READY",
                    color = SuccessGreen,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.8.sp
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "${summary.totalQuestionsExtracted} Questions cataloged with full taxonomy mapping. Score leakage analysis computed (-${summary.estimatedScoreLeakageMarks} Marks).",
                fontSize = 12.sp,
                color = TextPrimary
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Stats row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SummaryPill(label = "Physics", count = "${summary.physicsCount} Qs")
                SummaryPill(label = "Chemistry", count = "${summary.chemistryCount} Qs")
                SummaryPill(label = "Mathematics", count = "${summary.mathsCount} Qs")
                SummaryPill(label = "Weak Areas", count = "${summary.weakTopicsIdentified.size}")
            }

            if (summary.generatedReportFile != null) {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onOpen,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_summary_open_report")
                    ) {
                        Icon(
                            imageVector = if (summary.generatedReportFile.format == ReportFormat.PDF) Icons.Default.Description else Icons.Default.TableChart,
                            contentDescription = null,
                            tint = Color(0xFF00363D),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Open ${summary.generatedReportFile.format.extension.uppercase()}",
                            color = Color(0xFF00363D),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onShare,
                        border = BorderStroke(1.dp, ElectricCyanPrimary),
                        modifier = Modifier.testTag("btn_summary_share_report")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Share",
                            tint = ElectricCyanPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SummaryPill(
    label: String,
    count: String
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(24.dp))
            .background(DarkSlateCard)
            .border(0.6.dp, DarkSlateBorder, RoundedCornerShape(24.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = label, color = TextSecondary, fontSize = 9.sp)
            Text(text = count, color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AnalysisErrorCard(
    errorMessage: String,
    onRetry: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D).copy(alpha = 0.35f)),
        border = BorderStroke(1.dp, Color(0xFFEF4444)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_analysis_error")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Error,
                    contentDescription = null,
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "PIPELINE INTERRUPTION",
                    color = Color(0xFFEF4444),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(text = errorMessage, fontSize = 12.sp, color = TextPrimary)

            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onRetry,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                modifier = Modifier.testTag("btn_retry_failed_analysis")
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Retry Pipeline", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ExtractedTaxonomyPreviewCard(
    questions: List<ExtractedQuestionItem>,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        border = BorderStroke(1.dp, DarkSlateBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_extracted_taxonomy_preview")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleExpand() },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Analytics,
                        contentDescription = null,
                        tint = ElectricCyanPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "EXTRACTED QUESTIONS & TAXONOMY (${questions.size})",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }

                IconButton(
                    onClick = onToggleExpand,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "Expand",
                        tint = TextSecondary
                    )
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    Text(
                        text = "Real-time taxonomy parsed by Subject, Chapter, Topic & Difficulty:",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(questions) { q ->
                            QuestionTaxonomyItemCard(q)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuestionTaxonomyItemCard(
    question: ExtractedQuestionItem
) {
    val diffColor = when (question.difficulty.lowercase()) {
        "easy" -> SuccessGreen
        "medium" -> Color(0xFFF59E0B)
        else -> Color(0xFFEF4444)
    }

    Box(
        modifier = Modifier
            .width(180.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(Color(0xFF0F172A))
            .border(0.8.dp, DarkSlateBorder, RoundedCornerShape(18.dp))
            .padding(10.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Q${question.questionNumber} • ${question.subject.name.take(4)}",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = ElectricCyanPrimary
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(diffColor.copy(alpha = 0.2f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(text = question.difficulty, fontSize = 8.sp, color = diffColor, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = question.chapter,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = question.topic,
                fontSize = 10.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (question.identifiedConceptualTrap != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Trap: ${question.identifiedConceptualTrap}",
                    fontSize = 9.sp,
                    color = Color(0xFFFBBF24),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun TelemetryTerminalCard(
    logs: List<TelemetryLogEntry>,
    listState: LazyListState,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onCopyLogs: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF030712)),
        border = BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("card_telemetry_terminal")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = null,
                        tint = ElectricCyanPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIVE TELEMETRY STREAM",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8),
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 0.5.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onCopyLogs,
                        modifier = Modifier
                            .size(28.dp)
                            .testTag("btn_copy_terminal_logs")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Logs",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    IconButton(
                        onClick = onToggleExpand,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Toggle Expand",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            AnimatedVisibility(visible = isExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .padding(top = 8.dp)
                        .background(Color(0xFF000000), RoundedCornerShape(24.dp))
                        .padding(8.dp)
                ) {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(logs) { log ->
                            val levelColor = when (log.level) {
                                TelemetryLogLevel.SUCCESS -> Color(0xFF10B981)
                                TelemetryLogLevel.WARNING -> Color(0xFFF59E0B)
                                TelemetryLogLevel.METRIC -> Color(0xFF818CF8)
                                else -> Color(0xFF38BDF8)
                            }

                            Row(modifier = Modifier.padding(vertical = 1.dp)) {
                                Text(
                                    text = "[${log.tag}] ",
                                    color = levelColor,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = log.message,
                                    color = Color(0xFFE2E8F0),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AnalysisBottomActionBar(
    state: AnalysisProgressState,
    onCancel: () -> Unit,
    onMinimize: () -> Unit,
    onRetry: () -> Unit,
    onOpenReport: (GeneratedReportFile) -> Unit,
    onShareReport: (GeneratedReportFile) -> Unit,
    onDismiss: () -> Unit
) {
    JeeSurface(
        color = DarkSlateCard,
        border = BorderStroke(1.dp, DarkSlateBorder),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("bottom_bar_analysis_actions")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            when {
                state.isCompleted -> {
                    val file = state.resultSummary?.generatedReportFile
                    if (file != null) {
                        Button(
                            onClick = { onOpenReport(file) },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_bottom_open_report")
                        ) {
                            Icon(
                                imageVector = if (file.format == ReportFormat.PDF) Icons.Default.Description else Icons.Default.TableChart,
                                contentDescription = null,
                                tint = Color(0xFF00363D),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Open ${file.format.extension.uppercase()}",
                                color = Color(0xFF00363D),
                                fontWeight = FontWeight.Bold
                            )
                        }

                        OutlinedButton(
                            onClick = { onShareReport(file) },
                            border = BorderStroke(1.dp, ElectricCyanPrimary),
                            modifier = Modifier.testTag("btn_bottom_share_report")
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = "Share", tint = ElectricCyanPrimary)
                        }
                    }

                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                        modifier = Modifier.testTag("btn_bottom_done")
                    ) {
                        Text("Done", color = TextPrimary)
                    }
                }

                state.errorMessage != null && !state.isCancelled -> {
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_bottom_retry")
                    ) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Retry Analysis", color = Color.White)
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, DarkSlateBorder),
                        modifier = Modifier.testTag("btn_bottom_dismiss")
                    ) {
                        Text("Dismiss", color = TextSecondary)
                    }
                }

                state.isCancelled -> {
                    Button(
                        onClick = onRetry,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_bottom_restart_after_cancel")
                    ) {
                        Text("Restart Analysis", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        border = BorderStroke(1.dp, DarkSlateBorder)
                    ) {
                        Text("Close", color = TextSecondary)
                    }
                }

                else -> {
                    // Running in progress
                    OutlinedButton(
                        onClick = onCancel,
                        border = BorderStroke(1.dp, Color(0xFFEF4444)),
                        modifier = Modifier.testTag("btn_bottom_cancel_analysis")
                    ) {
                        Text("Cancel", color = Color(0xFFEF4444))
                    }

                    Button(
                        onClick = onMinimize,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                        border = BorderStroke(1.dp, ElectricCyanPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("btn_bottom_run_background")
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassEmpty,
                            contentDescription = null,
                            tint = ElectricCyanPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Run in Background", color = ElectricCyanPrimary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
