package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JEE CORE Fusion palette — inspired by the Tracker's command-center/game HUD,
// rebuilt for native Android with softer surfaces and a calmer Gemini-like hierarchy.
val DarkSlateBackground = Color(0xFF070912)
val DarkSlateSurface = Color(0xFF0E1322)
val DarkSlateCard = Color(0xFF141B2D)
val DarkSlateCardHover = Color(0xFF1A2339)
val DarkSlateBorder = Color(0x332F3D5C)

val ElectricCyanPrimary = Color(0xFF19D9FF)
val ElectricCyanDark = Color(0xFF0EA8C7)
val ElectricCyanGlow = Color(0x3319D9FF)

val TrackerOrange = Color(0xFFFF7A18)
val TrackerGold = Color(0xFFFFD43B)
val SecondaryIndigo = Color(0xFF7C5CFF)
val SecondaryPurple = Color(0xFFFF5CD6)

val SuccessGreen = Color(0xFF39FF88)
val WarningAmber = Color(0xFFFFD43B)
val ErrorRed = Color(0xFFFF4661)

val TextPrimary = Color(0xFFF5F7FF)
val TextSecondary = Color(0xFF9AA8C3)
val TextTertiary = Color(0xFF66738E)

val PhysicsAccent = Color(0xFF22D3EE)
val ChemistryAccent = Color(0xFF39FF88)
val MathsAccent = Color(0xFFFF5CD6)
