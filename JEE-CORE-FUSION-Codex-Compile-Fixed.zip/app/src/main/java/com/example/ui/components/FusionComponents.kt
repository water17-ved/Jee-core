package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.*

/**
 * The single card language used by the Fusion redesign:
 * large radius, no hard rectangular outline, subtle tonal depth.
 */
@Composable
fun JeeSurface(
    modifier: Modifier = Modifier,
    shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(26.dp),
    color: Color = DarkSlateCard,
    contentColor: Color = TextPrimary,
    border: androidx.compose.foundation.BorderStroke? = null,
    tonalElevation: Dp = 0.dp,
    shadowElevation: Dp = 0.dp,
    content: @Composable () -> Unit
) {
    val fusedShape = RoundedCornerShape(26.dp)
    Surface(
        modifier = modifier.shadow(
            elevation = if (shadowElevation > 0.dp) shadowElevation else 10.dp,
            shape = fusedShape,
            ambientColor = Color.Black.copy(alpha = .30f),
            spotColor = Color.Black.copy(alpha = .40f)
        ),
        shape = fusedShape,
        color = color,
        contentColor = contentColor,
        tonalElevation = tonalElevation,
        border = null,
        content = content
    )
}

@Composable
fun FusionPill(
    text: String,
    modifier: Modifier = Modifier,
    active: Boolean = false,
    accent: Color = ElectricCyanPrimary
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = if (active) accent.copy(alpha = .16f) else DarkSlateSurface,
        border = null
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 13.dp, vertical = 7.dp),
            color = if (active) accent else TextSecondary,
            style = MaterialTheme.typography.labelMedium
        )
    }
}

@Composable
fun FusionMetric(
    value: String,
    label: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        Text(value, color = accent, style = MaterialTheme.typography.titleLarge)
        Text(label, color = TextSecondary, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
fun FusionProgressBar(
    progress: Float,
    accent: Color = ElectricCyanPrimary,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .height(8.dp)
            .background(Color.White.copy(alpha = .06f), RoundedCornerShape(999.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(progress.coerceIn(0f, 1f))
                .background(
                    Brush.horizontalGradient(listOf(accent.copy(alpha = .65f), accent)),
                    RoundedCornerShape(999.dp)
                )
        )
    }
}
