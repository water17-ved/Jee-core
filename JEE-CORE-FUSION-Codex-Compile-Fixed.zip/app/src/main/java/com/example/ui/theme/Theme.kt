package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val FusionShapes = Shapes(
    extraSmall = RoundedCornerShape(12.dp),
    small = RoundedCornerShape(16.dp),
    medium = RoundedCornerShape(22.dp),
    large = RoundedCornerShape(28.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

private val DarkSlateColorScheme = darkColorScheme(
    primary = ElectricCyanPrimary,
    onPrimary = Color(0xFF001A20),
    primaryContainer = Color(0xFF073E49),
    onPrimaryContainer = Color(0xFF9AF3FF),
    secondary = TrackerOrange,
    onSecondary = Color(0xFF211000),
    secondaryContainer = Color(0xFF542400),
    onSecondaryContainer = Color(0xFFFFDCC5),
    tertiary = SecondaryPurple,
    onTertiary = Color(0xFF26001F),
    background = DarkSlateBackground,
    onBackground = TextPrimary,
    surface = DarkSlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSlateCard,
    onSurfaceVariant = TextSecondary,
    outline = Color(0x553A4A6B),
    outlineVariant = Color(0x332F3D5C),
    error = ErrorRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkSlateColorScheme,
        shapes = FusionShapes,
        typography = Typography,
        content = content
    )
}
