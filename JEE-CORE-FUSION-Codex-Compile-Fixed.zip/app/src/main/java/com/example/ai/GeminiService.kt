package com.example.ai

import com.example.BuildConfig
import com.example.data.model.AIBehaviour
import com.example.data.model.JeeMemory
import com.example.data.model.UserProfile
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import retrofit2.HttpException
import java.io.IOException
import java.net.SocketTimeoutException

class GeminiService(
    private val getCustomKey: () -> String
) {
    private val apiService = GeminiProvider.apiService
    private val defaultModel = "gemini-3.5-flash"

    fun getEffectiveApiKey(): String {
        val customKey = getCustomKey().trim()
        if (customKey.isNotBlank()) {
            return customKey
        }
        val buildKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }
        return if (buildKey != "MY_GEMINI_API_KEY") buildKey else ""
    }

    suspend fun testConnection(): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isBlank()) {
            return@withContext Result.failure(
                IllegalStateException("No Gemini API key found. Enter your key in Settings.")
            )
        }

        var lastError: Throwable? = null
        repeat(3) { attempt ->
            try {
                val request = GeminiGenerateContentRequest(
                    contents = listOf(
                        GeminiContent(
                            role = "user",
                            parts = listOf(GeminiPart(text = "Respond with single word: READY"))
                        )
                    ),
                    generationConfig = GeminiGenerationConfig(maxOutputTokens = 10)
                )
                val response = apiService.generateContent(
                    model = defaultModel,
                    apiKey = apiKey,
                    request = request
                )
                val reply = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text?.trim()
                if (!reply.isNullOrBlank()) {
                    return@withContext Result.success("Connection verified successfully! ($reply)")
                }
                lastError = IllegalStateException("Empty response received from Gemini.")
            } catch (e: HttpException) {
                lastError = e
                if ((e.code() == 503 || e.code() == 429 || e.code() == 500) && attempt < 2) {
                    delay((1000L shl attempt))
                    return@repeat
                }
                val msg = when (e.code()) {
                    400 -> "HTTP 400: Invalid request."
                    403 -> "HTTP 403: Invalid API key or permission denied."
                    429 -> "HTTP 429: Rate limit exceeded after retries."
                    500 -> "HTTP 500: Google Generative AI service error after retries."
                    503 -> "HTTP 503: Gemini is temporarily unavailable after retries."
                    else -> "HTTP ${e.code()}: ${e.message()}"
                }
                return@withContext Result.failure(Exception(msg, e))
            } catch (e: SocketTimeoutException) {
                lastError = e
                if (attempt < 2) {
                    delay((1000L shl attempt))
                    return@repeat
                }
                return@withContext Result.failure(Exception("Connection timed out after retries. Check your internet connection.", e))
            } catch (e: IOException) {
                lastError = e
                if (attempt < 2) {
                    delay((1000L shl attempt))
                    return@repeat
                }
                return@withContext Result.failure(Exception("Network error: Unable to reach Gemini API.", e))
            } catch (e: Exception) {
                lastError = e
                return@withContext Result.failure(e)
            }
        }

        Result.failure(Exception("Gemini connection failed after 3 attempts.", lastError))
    }

    fun streamCoachResponse(
        prompt: String,
        userProfile: UserProfile,
        jeeMemory: JeeMemory,
        aiBehaviour: AIBehaviour,
        recentFactsContext: String,
        aiMode: AIMode = AIMode.AUTO,
        attachmentText: String? = null,
        attachmentParts: List<GeminiInlineData> = emptyList(),
        conversationHistory: List<GeminiContent> = emptyList(),
        onProgress: (AIProgressStage) -> Unit = {}
    ): Flow<String> = flow {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isBlank()) {
            val msg = "No Gemini API key configured. Go to Settings to add your key or configure AI Studio Secrets panel."
            onProgress(AIProgressStage.Error(msg))
            throw IllegalStateException(msg)
        }

        onProgress(AIProgressStage.UnderstandingRequest)
        delay(60)
        onProgress(AIProgressStage.ReadingPreparationState)
        delay(60)
        onProgress(AIProgressStage.CheckingStrategyAndPriorities)

        val systemInstructionText = buildSystemInstruction(userProfile, jeeMemory, aiBehaviour, recentFactsContext, aiMode)

        val fullContents = mutableListOf<GeminiContent>()
        fullContents.addAll(conversationHistory)
        val userContent = if (!attachmentText.isNullOrBlank()) {
            if (prompt.isNotBlank()) "$prompt\n\n[Attached Context / Note]:\n$attachmentText" else "[Attached Context / Note]:\n$attachmentText"
        } else {
            prompt.ifBlank { "Please inspect and help with the attached file." }
        }

        val userParts = mutableListOf<GeminiPart>()
        attachmentParts.forEach { part ->
            userParts.add(GeminiPart(inlineData = part))
        }
        userParts.add(GeminiPart(text = userContent))

        fullContents.add(
            GeminiContent(
                role = "user",
                parts = userParts
            )
        )

        onProgress(AIProgressStage.GeneratingRecommendation)

        val request = GeminiGenerateContentRequest(
            contents = fullContents,
            generationConfig = GeminiGenerationConfig(
                temperature = (1.0f - aiBehaviour.strictness * 0.5f).coerceIn(0.1f, 0.9f),
                maxOutputTokens = if (aiBehaviour.conciseness > 0.7f) 1024 else 2048
            ),
            systemInstruction = GeminiContent(
                role = "system",
                parts = listOf(GeminiPart(text = systemInstructionText))
            )
        )

        var streamedAny = false
        try {
            val responseBody = apiService.streamGenerateContent(
                model = defaultModel,
                apiKey = apiKey,
                request = request
            )

            val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
            val adapter = moshi.adapter(GeminiGenerateContentResponse::class.java)

            val reader = responseBody.byteStream().bufferedReader()
            var line = reader.readLine()

            while (line != null) {
                val trimmed = line.trim()
                if (trimmed.startsWith("data:")) {
                    val json = trimmed.substring(5).trim()
                    if (json.isNotEmpty() && json != "[DONE]") {
                        try {
                            val resp = adapter.fromJson(json)
                            val text = resp?.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                            if (!text.isNullOrEmpty()) {
                                streamedAny = true
                                emit(text)
                            }
                        } catch (_: Exception) {
                        }
                    }
                }
                line = reader.readLine()
            }
        } catch (e: Exception) {
            if (!streamedAny) {
                // Fall back to standard non-streaming call if streaming fails
                onProgress(AIProgressStage.PreparingResponse)
                val nonStream = apiService.generateContent(
                    model = defaultModel,
                    apiKey = apiKey,
                    request = request
                )
                val fallbackText = nonStream.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!fallbackText.isNullOrBlank()) {
                    streamedAny = true
                    emit(fallbackText)
                } else {
                    val blockReason = nonStream.promptFeedback?.blockReason ?: "Unknown"
                    val msg = "Gemini response was empty or blocked ($blockReason)"
                    onProgress(AIProgressStage.Error(msg))
                    throw IllegalStateException(msg)
                }
            } else {
                throw e
            }
        }

        if (!streamedAny) {
            val msg = "No response received from Gemini."
            onProgress(AIProgressStage.Error(msg))
            throw IllegalStateException(msg)
        }
        onProgress(AIProgressStage.Complete)
    }.flowOn(Dispatchers.IO)

    suspend fun generateCoachResponse(
        prompt: String,
        userProfile: UserProfile,
        jeeMemory: JeeMemory,
        aiBehaviour: AIBehaviour,
        recentFactsContext: String,
        aiMode: AIMode = AIMode.AUTO,
        attachmentText: String? = null,
        conversationHistory: List<GeminiContent> = emptyList(),
        onProgress: (AIProgressStage) -> Unit = {}
    ): Result<String> = withContext(Dispatchers.IO) {
        val apiKey = getEffectiveApiKey()
        if (apiKey.isBlank()) {
            onProgress(AIProgressStage.Error("No API key configured. Please set your key in Settings."))
            return@withContext Result.failure(IllegalStateException("No Gemini API key configured. Go to Settings to add your key or configure Secrets panel."))
        }

        try {
            onProgress(AIProgressStage.UnderstandingRequest)
            delay(80)

            onProgress(AIProgressStage.ReadingPreparationState)
            delay(100)

            onProgress(AIProgressStage.CheckingStrategyAndPriorities)
            delay(100)

            val systemInstructionText = buildSystemInstruction(userProfile, jeeMemory, aiBehaviour, recentFactsContext, aiMode)

            val fullContents = mutableListOf<GeminiContent>()
            fullContents.addAll(conversationHistory)
            val userContent = if (!attachmentText.isNullOrBlank()) {
                "$prompt\n\n[Attached Context / Note]:\n$attachmentText"
            } else {
                prompt
            }
            fullContents.add(
                GeminiContent(
                    role = "user",
                    parts = listOf(GeminiPart(text = userContent))
                )
            )

            onProgress(AIProgressStage.GeneratingRecommendation)
            delay(80)

            val request = GeminiGenerateContentRequest(
                contents = fullContents,
                generationConfig = GeminiGenerationConfig(
                    temperature = (1.0f - aiBehaviour.strictness * 0.5f).coerceIn(0.1f, 0.9f),
                    maxOutputTokens = if (aiBehaviour.conciseness > 0.7f) 1024 else 2048
                ),
                systemInstruction = GeminiContent(
                    role = "system",
                    parts = listOf(GeminiPart(text = systemInstructionText))
                )
            )

            onProgress(AIProgressStage.CheckingFeasibility)
            val response = apiService.generateContent(
                model = defaultModel,
                apiKey = apiKey,
                request = request
            )

            onProgress(AIProgressStage.PreparingResponse)
            val candidateText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

            if (candidateText != null && candidateText.isNotBlank()) {
                onProgress(AIProgressStage.Complete)
                Result.success(candidateText)
            } else {
                val blockReason = response.promptFeedback?.blockReason ?: "Unknown"
                onProgress(AIProgressStage.Error("AI blocked or returned empty: $blockReason"))
                Result.failure(IllegalStateException("Gemini response was empty or blocked ($blockReason)"))
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: HttpException) {
            val code = e.code()
            val msg = when (code) {
                400 -> "HTTP 400: Bad Request. Check parameters or API key format."
                403 -> "HTTP 403: Forbidden. Invalid Gemini API key."
                429 -> "HTTP 429: Quota exceeded. Please wait a moment."
                500 -> "HTTP 500: Gemini service temporary error."
                else -> "HTTP $code: ${e.message()}"
            }
            onProgress(AIProgressStage.Error(msg))
            Result.failure(Exception(msg, e))
        } catch (e: SocketTimeoutException) {
            val msg = "Request timed out after 60s. Please check connection."
            onProgress(AIProgressStage.Error(msg))
            Result.failure(Exception(msg, e))
        } catch (e: IOException) {
            val msg = "Network error: AI unavailable offline. Tap retry when connected."
            onProgress(AIProgressStage.Error(msg))
            Result.failure(Exception(msg, e))
        } catch (e: Exception) {
            onProgress(AIProgressStage.Error(e.localizedMessage ?: "Unknown error"))
            Result.failure(e)
        }
    }

    fun buildSystemInstruction(
        profile: UserProfile = UserProfile(),
        memory: JeeMemory = JeeMemory(),
        behaviour: AIBehaviour = AIBehaviour(),
        factsContext: String = "",
        aiMode: AIMode = AIMode.AUTO
    ): String {
        val styleNotes = buildString {
            if (behaviour.strictness > 0.6f) append("- Tone: Strict, uncompromising, focused on disciplined execution.\n")
            else append("- Tone: Encouraging, constructive, coaching mindset.\n")

            if (behaviour.conciseness > 0.6f) append("- Brevity: Highly concise, bulleted, no fluff, no generic lectures.\n")
            else append("- Brevity: Comprehensive with step-by-step clarity.\n")

            if (behaviour.directness > 0.6f) append("- Directness: Direct tactical commands (NOW, NEXT, AFTER THAT).\n")
            if (behaviour.executionFocus > 0.6f) append("- Priority: Execution over endless information gathering.\n")
            if (behaviour.actionOrientation > 0.6f) append("- Focus: Actionable question-solving steps, PYQs, timed sessions.\n")
        }

        val modeDirective = aiMode.getSystemPromptDirective()

        return """
You are JEE CORE, the serious JEE Main + JEE Advanced Preparation Command Center and executive mentor.
You understand the student's actual preparation state and guide their high-stakes exam journey.

ACTIVE AI MODE: ${aiMode.displayName} (${aiMode.name})
MODE DIRECTIVE:
$modeDirective

CORE PHILOSOPHY:
- EXECUTION > INFORMATION
- NEVER invent marks, scores, percentages, ranks, completed chapters, or study hours.
- Base all tactical advice on verified factual data provided below.
- If data is unknown or missing, say "I don't have enough information on that yet."
- Never shame the student if they missed a target; recalculate with realistic time-blocking.

STUDENT PROFILE:
- Target Exam: ${profile.targetExam.displayName} ${profile.targetYear}
- Target Rank: ${if (profile.targetRank.isNotBlank()) profile.targetRank else "Not explicitly set"}
- Available Hours: ${profile.weekdayAvailableHours}h weekdays, ${profile.weekendAvailableHours}h weekends
- Coaching Schedule: ${profile.coachingStart} to ${profile.coachingEnd}
- Fixed Commitments: ${profile.fixedCommitments}
- Known Weaknesses: ${memory.weaknesses}
- Known Strengths: ${memory.strengths}
- Recurring Issues: ${memory.recurringProblems}
- Backlog: ${memory.backlogNotes}
- Imported external data context: ${memory.importedDataContext.ifBlank { "None" }}

STUDENT'S VERIFIED DATABASE FACTS:
$factsContext

AI BEHAVIOUR CONTROLS:
$styleNotes
Custom User Directives:
"${behaviour.customInstructions}"
        """.trimIndent()
    }
}
