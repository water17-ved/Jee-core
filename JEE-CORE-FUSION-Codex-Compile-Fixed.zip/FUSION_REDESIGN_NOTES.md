# JEE CORE Fusion Redesign

This build merges the *useful product attributes* of the supplied JEE Battle Royale Tracker into JEE CORE without embedding the old web/Capacitor implementation.

## UI direction
- Native Jetpack Compose remains the foundation.
- Tracker-inspired Command Center language: level/XP-style progress, subject zones, battle log, revision due, question/study/test metrics.
- Dark violet/navy base with orange/gold, cyan, green and magenta subject accents.
- Large rounded surfaces, no hard rectangular card borders, floating bottom navigation and pill controls.
- Chat bubbles are deliberately asymmetric but fully rounded rather than squared message boxes.

## Tracker-derived data concepts integrated
- Daily question logging
- Study-hours history
- Daily schedule
- Daily targets
- Test / mock history
- Syllabus progress
- Revision due
- Weak-subject context
- Battle-log style analytics

## JSON import
JEE CORE now accepts:
1. Native JEE CORE backup JSON.
2. JEE Battle Royale Tracker JSON (including its v4 backup shape).
3. Arbitrary JSON objects.
4. Root JSON arrays.

Tracker fields are mapped into CORE where there is a direct semantic match; an external-data summary is also preserved for AI context.

## Multimedia
Chat attachment selection now supports multiple files in one turn:
- images
- audio
- video
- PDF
- JSON
- text

Supported small media is sent as Gemini inline data. Text/JSON content can also be extracted locally. Larger files remain selected but are not blindly loaded into memory.

## Gemini hardening
- API key is sent using the `x-goog-api-key` header.
- Connection testing retries transient 500/503/429 failures with backoff.
- 503 now produces a useful diagnostic instead of a generic failure.

## Build note
The local environment cannot download Gradle 9.3.1 because outbound access to services.gradle.org is unavailable. The project should therefore be compiled/validated through Codemagic/Android Studio before release.
