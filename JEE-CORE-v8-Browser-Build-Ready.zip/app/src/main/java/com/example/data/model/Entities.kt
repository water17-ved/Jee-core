package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
@Entity(tableName = "missions")
data class MissionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subject: Subject,
    val chapter: String,
    val topic: String,
    val plannedDurationMinutes: Int = 45,
    val timeSpentMinutes: Int = 0,
    val deadlineEpochMs: Long = System.currentTimeMillis() + (24 * 3600 * 1000L),
    val priority: PriorityLevel = PriorityLevel.HIGH,
    val status: MissionStatus = MissionStatus.NOT_STARTED,
    val targetQuantity: Int = 15,
    val completedQuantity: Int = 0,
    val notes: String = "",
    val createdBy: MissionCreator = MissionCreator.USER,
    val aiReason: String = "",
    val createdAtEpochMs: Long = System.currentTimeMillis(),
    val startedAtEpochMs: Long? = null,
    val completedAtEpochMs: Long? = null,
    val updatedAtEpochMs: Long = System.currentTimeMillis()
)

@JsonClass(generateAdapter = true)
@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val missionId: Long? = null,
    val missionTitle: String? = null,
    val subject: Subject,
    val chapter: String,
    val topic: String,
    val plannedDurationMinutes: Int,
    val actualDurationMinutes: Int,
    val questionsCompleted: Int = 0,
    val startTimeEpochMs: Long,
    val endTimeEpochMs: Long,
    val isCompleted: Boolean = true,
    val notes: String = ""
)

@JsonClass(generateAdapter = true)
@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val createdAtEpochMs: Long = System.currentTimeMillis(),
    val updatedAtEpochMs: Long = System.currentTimeMillis(),
    val messageCount: Int = 0
)

@JsonClass(generateAdapter = true)
@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: Long,
    val role: String, // "user" or "model"
    val content: String,
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val stageStatus: String = "", // For honest stage-based progress indicators if any
    val aiMode: String = "AUTO",
    val attachmentUri: String? = null,
    val attachmentName: String? = null,
    val attachmentType: String? = null,
    val isError: Boolean = false
)

enum class TopicState(val displayName: String) {
    NOT_STARTED("Not Started"),
    LEARNING("Learning"),
    COMPLETED_ONCE("Completed Once"),
    NEEDS_REVISION("Needs Revision"),
    STRONG("Strong"),
    WEAK("Weak")
}

@JsonClass(generateAdapter = true)
@Entity(tableName = "syllabus_topics")
data class SyllabusTopicEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: Subject,
    val chapter: String,
    val topicName: String,
    val state: TopicState = TopicState.NOT_STARTED,
    val confidenceScore: Int = 0, // 0 - 100
    val lastStudiedEpochMs: Long? = null,
    val lastRevisedEpochMs: Long? = null,
    val nextRevisionEpochMs: Long? = null,
    val pyqsAttempted: Int = 0,
    val pyqsCorrect: Int = 0,
    val testAccuracyPercent: Int = 0,
    val isWeakArea: Boolean = false,
    val notes: String = ""
)

@JsonClass(generateAdapter = true)
@Entity(tableName = "test_records")
data class TestRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val testName: String,
    val testDateEpochMs: Long = System.currentTimeMillis(),
    val examType: ExamType = ExamType.JEE_MAIN,
    val totalMarks: Int = 300,
    val userScore: Int = 0,
    val physicsScore: Int = 0,
    val chemistryScore: Int = 0,
    val mathsScore: Int = 0,
    val percentile: Float = 0.0f,
    val attempted: Int = 0,
    val correct: Int = 0,
    val incorrect: Int = 0,
    val skipped: Int = 0,
    val accuracy: Float = 0.0f,
    val timeSpentMinutes: Int = 180,
    val analysisNotes: String = "",
    // Error counts
    val conceptualErrors: Int = 0,
    val calculationErrors: Int = 0,
    val sillyMistakes: Int = 0,
    val formulaRecallErrors: Int = 0,
    val timePressureErrors: Int = 0,
    val guessErrors: Int = 0,
    val knewButMissedErrors: Int = 0,
    val weakChaptersIdentified: String = ""
)

@JsonClass(generateAdapter = true)
@Entity(tableName = "work_logs")
data class WorkLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subject: Subject,
    val chapter: String,
    val topic: String,
    val whatDidYouDo: String,
    val durationMinutes: Int,
    val questionsAttempted: Int = 0,
    val questionsCorrect: Int = 0,
    val questionsIncorrect: Int = 0,
    val notes: String = "",
    val timestampEpochMs: Long = System.currentTimeMillis(),
    val linkedMissionId: Long? = null
)
