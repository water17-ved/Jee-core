package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.model.ExamType
import com.example.data.model.MissionCreator
import com.example.data.model.MissionStatus
import com.example.data.model.PriorityLevel
import com.example.data.model.Subject
import com.example.data.model.TopicState

class Converters {
    @TypeConverter
    fun fromSubject(value: Subject?): String? = value?.name

    @TypeConverter
    fun toSubject(value: String?): Subject? = value?.let {
        try { Subject.valueOf(it) } catch (e: Exception) { Subject.PHYSICS }
    }

    @TypeConverter
    fun fromPriority(value: PriorityLevel?): String? = value?.name

    @TypeConverter
    fun toPriority(value: String?): PriorityLevel? = value?.let {
        try { PriorityLevel.valueOf(it) } catch (e: Exception) { PriorityLevel.HIGH }
    }

    @TypeConverter
    fun fromMissionStatus(value: MissionStatus?): String? = value?.name

    @TypeConverter
    fun toMissionStatus(value: String?): MissionStatus? = value?.let {
        try { MissionStatus.valueOf(it) } catch (e: Exception) { MissionStatus.NOT_STARTED }
    }

    @TypeConverter
    fun fromMissionCreator(value: MissionCreator?): String? = value?.name

    @TypeConverter
    fun toMissionCreator(value: String?): MissionCreator? = value?.let {
        try { MissionCreator.valueOf(it) } catch (e: Exception) { MissionCreator.USER }
    }

    @TypeConverter
    fun fromTopicState(value: TopicState?): String? = value?.name

    @TypeConverter
    fun toTopicState(value: String?): TopicState? = value?.let {
        try { TopicState.valueOf(it) } catch (e: Exception) { TopicState.NOT_STARTED }
    }

    @TypeConverter
    fun fromExamType(value: ExamType?): String? = value?.name

    @TypeConverter
    fun toExamType(value: String?): ExamType? = value?.let {
        try { ExamType.valueOf(it) } catch (e: Exception) { ExamType.JEE_MAIN }
    }
}
