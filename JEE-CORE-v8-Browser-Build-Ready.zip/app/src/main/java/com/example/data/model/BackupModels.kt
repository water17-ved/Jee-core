package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class NotificationSettings(
    val missionReminders: Boolean = true,
    val focusCompleteNotification: Boolean = true,
    val revisionDueNotification: Boolean = true,
    val testReminders: Boolean = true,
    val backlogReminders: Boolean = true
)

@JsonClass(generateAdapter = true)
data class BackupData(
    val schemaVersion: Int = 2,
    val exportedAt: Long = System.currentTimeMillis(),
    val appVersion: String = "1.0.0",
    val userProfile: UserProfile = UserProfile(),
    val jeeMemory: JeeMemory = JeeMemory(),
    val aiBehaviour: AIBehaviour = AIBehaviour(),
    val notificationSettings: NotificationSettings = NotificationSettings(),
    val missions: List<MissionEntity> = emptyList(),
    val focusSessions: List<FocusSessionEntity> = emptyList(),
    val chats: List<ChatEntity> = emptyList(),
    val chatMessages: List<ChatMessageEntity> = emptyList(),
    val syllabusTopics: List<SyllabusTopicEntity> = emptyList(),
    val testRecords: List<TestRecordEntity> = emptyList(),
    val workLogs: List<WorkLogEntity> = emptyList()
)

data class BackupPreview(
    val schemaVersion: Int,
    val exportedAt: Long,
    val appVersion: String,
    val targetExam: String,
    val targetYear: Int,
    val missionCount: Int,
    val focusSessionCount: Int,
    val chatCount: Int,
    val messageCount: Int,
    val syllabusCount: Int,
    val testCount: Int,
    val workLogCount: Int
)
