package com.example.data.repository

import androidx.room.withTransaction
import com.example.data.local.AppDatabase
import com.example.data.model.BackupData
import com.example.data.model.BackupPreview
import com.example.data.model.ChatEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ExamType
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionCreator
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.PriorityLevel
import com.example.data.model.Subject
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.TopicState
import com.example.data.model.WorkLogEntity
import com.example.data.preference.UserPreferencesManager
import com.squareup.moshi.Moshi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class JeeCoreRepository(
    private val database: AppDatabase,
    val preferencesManager: UserPreferencesManager
) {
    private val missionDao = database.missionDao()
    private val focusSessionDao = database.focusSessionDao()
    private val chatDao = database.chatDao()
    private val syllabusDao = database.syllabusDao()
    private val testRecordDao = database.testRecordDao()
    private val workLogDao = database.workLogDao()

    private val moshi = Moshi.Builder().build()
    private val backupAdapter = moshi.adapter(BackupData::class.java)

    // Missions
    val allMissions: Flow<List<MissionEntity>> = missionDao.getAllMissions()

    suspend fun insertMission(mission: MissionEntity): Long = withContext(Dispatchers.IO) {
        missionDao.insertMission(mission)
    }

    suspend fun updateMission(mission: MissionEntity) = withContext(Dispatchers.IO) {
        missionDao.updateMission(mission.copy(updatedAtEpochMs = System.currentTimeMillis()))
    }

    suspend fun deleteMission(mission: MissionEntity) = withContext(Dispatchers.IO) {
        missionDao.deleteMission(mission)
    }

    // Focus sessions
    val allFocusSessions: Flow<List<FocusSessionEntity>> = focusSessionDao.getAllFocusSessions()

    suspend fun recordFocusSession(session: FocusSessionEntity): Long = withContext(Dispatchers.IO) {
        focusSessionDao.insertSession(session)
    }

    // Work Logs
    val allWorkLogs: Flow<List<WorkLogEntity>> = workLogDao.getAllWorkLogs()

    suspend fun logWork(log: WorkLogEntity): Long = withContext(Dispatchers.IO) {
        val id = workLogDao.insertWorkLog(log)
        // If linked to mission, update mission progress
        log.linkedMissionId?.let { missionId ->
            val mission = missionDao.getMissionById(missionId)
            if (mission != null) {
                val newCompleted = mission.completedQuantity + log.questionsAttempted
                val newStatus = if (newCompleted >= mission.targetQuantity) {
                    MissionStatus.COMPLETED
                } else {
                    MissionStatus.IN_PROGRESS
                }
                missionDao.updateMission(
                    mission.copy(
                        completedQuantity = newCompleted,
                        timeSpentMinutes = mission.timeSpentMinutes + log.durationMinutes,
                        status = newStatus,
                        completedAtEpochMs = if (newStatus == MissionStatus.COMPLETED) System.currentTimeMillis() else null
                    )
                )
            }
        }
        id
    }

    // Chat
    val allChats: Flow<List<ChatEntity>> = chatDao.getAllChats()

    fun getMessagesForChat(chatId: Long): Flow<List<ChatMessageEntity>> =
        chatDao.getMessagesForChat(chatId)

    suspend fun createChat(title: String): Long = withContext(Dispatchers.IO) {
        chatDao.insertChat(ChatEntity(title = title))
    }

    suspend fun renameChat(chatId: Long, newTitle: String) = withContext(Dispatchers.IO) {
        val chat = chatDao.getChatById(chatId)
        if (chat != null) {
            chatDao.updateChat(chat.copy(title = newTitle, updatedAtEpochMs = System.currentTimeMillis()))
        }
    }

    suspend fun deleteChat(chatId: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessagesForChat(chatId)
        chatDao.deleteChatById(chatId)
    }

    suspend fun insertChatMessage(message: ChatMessageEntity): Long = withContext(Dispatchers.IO) {
        val id = chatDao.insertMessage(message)
        val chat = chatDao.getChatById(message.chatId)
        if (chat != null) {
            chatDao.updateChat(
                chat.copy(
                    updatedAtEpochMs = System.currentTimeMillis(),
                    messageCount = chat.messageCount + 1
                )
            )
        }
        id
    }

    suspend fun updateChatMessage(message: ChatMessageEntity) = withContext(Dispatchers.IO) {
        chatDao.updateMessage(message)
    }

    suspend fun deleteChatMessage(messageId: Long) = withContext(Dispatchers.IO) {
        chatDao.deleteMessageById(messageId)
    }

    // Syllabus
    val allSyllabusTopics: Flow<List<SyllabusTopicEntity>> = syllabusDao.getAllTopics()
    val weakAndRevisionTopics: Flow<List<SyllabusTopicEntity>> = syllabusDao.getWeakAndRevisionTopics()

    suspend fun updateTopic(topic: SyllabusTopicEntity) = withContext(Dispatchers.IO) {
        syllabusDao.updateTopic(topic)
    }

    // Tests
    val allTests: Flow<List<TestRecordEntity>> = testRecordDao.getAllTests()

    suspend fun recordTest(test: TestRecordEntity): Long = withContext(Dispatchers.IO) {
        testRecordDao.insertTest(test)
    }

    suspend fun deleteTest(test: TestRecordEntity) = withContext(Dispatchers.IO) {
        testRecordDao.deleteTest(test)
    }

    // Seed static standard syllabus if empty (all student metrics start empty at 0)
    suspend fun initializeSyllabusIfNeeded() = withContext(Dispatchers.IO) {
        if (syllabusDao.getTopicCount() == 0) {
            val defaultTopics = listOf(
                // Physics
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Electrostatics", topicName = "Coulomb's Law & Electric Field"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Electrostatics", topicName = "Capacitance & Dielectrics"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Mechanics", topicName = "Rotational Dynamics & Torque"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Mechanics", topicName = "Work, Energy & Power"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Current Electricity", topicName = "Kirchhoff's Laws & Potentiometer"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Optics", topicName = "Wave Optics & Interference"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Modern Physics", topicName = "Photoelectric Effect & Atomic Models"),
                SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Thermodynamics", topicName = "First Law & Heat Engines"),

                // Chemistry
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Chemical Bonding", topicName = "Molecular Orbital Theory & VSEPR"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Thermodynamics", topicName = "Enthalpy, Entropy & Gibbs Free Energy"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Equilibrium", topicName = "Ionic Equilibrium & Buffer Solutions"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Organic Chemistry", topicName = "Reaction Mechanisms (Sn1/Sn2/E1/E2)"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Coordination Chemistry", topicName = "Crystal Field Theory & Isomerism"),
                SyllabusTopicEntity(subject = Subject.CHEMISTRY, chapter = "Electrochemistry", topicName = "Nernst Equation & Cell Potential"),

                // Mathematics
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Calculus", topicName = "Definite Integration & Properties"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Calculus", topicName = "Application of Derivatives (Maxima/Minima)"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Algebra", topicName = "Complex Numbers Geometry"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Vectors & 3D", topicName = "Shortest Distance & Planes"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Coordinate Geometry", topicName = "Conic Sections (Parabola & Ellipse)"),
                SyllabusTopicEntity(subject = Subject.MATHEMATICS, chapter = "Probability", topicName = "Conditional Probability & Bayes' Theorem")
            )
            syllabusDao.insertTopics(defaultTopics)
        }
    }

    // Export complete backup as JSON (never including raw API secrets)
    suspend fun exportBackupJson(): String = withContext(Dispatchers.IO) {
        val profile = preferencesManager.userProfile.value
        val memory = preferencesManager.jeeMemory.value
        val behaviour = preferencesManager.aiBehaviour.value
        val notificationSettings = preferencesManager.notificationSettings.value

        val missions = missionDao.getAllMissionsList()
        val focusSessions = focusSessionDao.getAllFocusSessionsList()
        val chats = chatDao.getAllChatsList()
        val chatMessages = chatDao.getAllMessagesList()
        val syllabusTopics = syllabusDao.getAllTopicsList()
        val testRecords = testRecordDao.getAllTestsList()
        val workLogs = workLogDao.getAllWorkLogsList()

        val backup = BackupData(
            schemaVersion = 2,
            exportedAt = System.currentTimeMillis(),
            appVersion = "1.0.0",
            userProfile = profile,
            jeeMemory = memory,
            aiBehaviour = behaviour,
            notificationSettings = notificationSettings,
            missions = missions,
            focusSessions = focusSessions,
            chats = chats,
            chatMessages = chatMessages,
            syllabusTopics = syllabusTopics,
            testRecords = testRecords,
            workLogs = workLogs
        )
        backupAdapter.indent("  ").toJson(backup)
    }

    // Validate schema and generate preview before restore
    suspend fun validateAndPreviewBackup(jsonString: String): Result<BackupPreview> = withContext(Dispatchers.IO) {
        try {
            val backup = backupAdapter.fromJson(jsonString)
                ?: return@withContext Result.failure(IllegalArgumentException("Invalid or malformed JSON."))

            if (backup.schemaVersion > 2) {
                return@withContext Result.failure(
                    IllegalArgumentException("Unsupported backup version ${backup.schemaVersion}. Current supported version is 2. Please update JEE CORE.")
                )
            }

            val preview = BackupPreview(
                schemaVersion = backup.schemaVersion,
                exportedAt = backup.exportedAt,
                appVersion = backup.appVersion,
                targetExam = backup.userProfile.targetExam.displayName,
                targetYear = backup.userProfile.targetYear,
                missionCount = backup.missions.size,
                focusSessionCount = backup.focusSessions.size,
                chatCount = backup.chats.size,
                messageCount = backup.chatMessages.size,
                syllabusCount = backup.syllabusTopics.size,
                testCount = backup.testRecords.size,
                workLogCount = backup.workLogs.size
            )
            Result.success(preview)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Import backup JSON with atomic transaction and preserved ID relationships
    suspend fun importBackupJson(jsonString: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val backup = backupAdapter.fromJson(jsonString)
                ?: return@withContext Result.failure(IllegalArgumentException("Invalid backup JSON format"))

            if (backup.schemaVersion > 2) {
                return@withContext Result.failure(
                    IllegalArgumentException("Unsupported backup version ${backup.schemaVersion}. Current supported version is 2.")
                )
            }

            database.withTransaction {
                // Clear existing records
                missionDao.clearAll()
                focusSessionDao.clearAll()
                chatDao.clearAllChats()
                chatDao.clearAllMessages()
                syllabusDao.clearAll()
                testRecordDao.clearAll()
                workLogDao.clearAll()

                // Insert missions and create old ID -> new ID mapping for relationship integrity
                val missionIdMap = mutableMapOf<Long, Long>()
                backup.missions.forEach { oldMission ->
                    val oldId = oldMission.id
                    val newId = missionDao.insertMission(oldMission.copy(id = 0))
                    missionIdMap[oldId] = newId
                }

                // Insert focus sessions, remapping linked mission ID
                backup.focusSessions.forEach { oldSession ->
                    val remappedMissionId = oldSession.missionId?.let { missionIdMap[it] ?: it }
                    focusSessionDao.insertSession(oldSession.copy(id = 0, missionId = remappedMissionId))
                }

                // Insert work logs, remapping linked mission ID
                backup.workLogs.forEach { oldLog ->
                    val remappedMissionId = oldLog.linkedMissionId?.let { missionIdMap[it] ?: it }
                    workLogDao.insertWorkLog(oldLog.copy(id = 0, linkedMissionId = remappedMissionId))
                }

                // Insert chats and chat messages, preserving relationship integrity
                val chatIdMap = mutableMapOf<Long, Long>()
                backup.chats.forEach { oldChat ->
                    val oldId = oldChat.id
                    val newId = chatDao.insertChat(oldChat.copy(id = 0))
                    chatIdMap[oldId] = newId
                }

                backup.chatMessages.forEach { oldMsg ->
                    val remappedChatId = chatIdMap[oldMsg.chatId] ?: oldMsg.chatId
                    chatDao.insertMessage(oldMsg.copy(id = 0, chatId = remappedChatId))
                }

                // Insert syllabus topics and tests
                if (backup.syllabusTopics.isNotEmpty()) {
                    syllabusDao.insertTopics(backup.syllabusTopics.map { it.copy(id = 0) })
                }
                if (backup.testRecords.isNotEmpty()) {
                    testRecordDao.insertTests(backup.testRecords.map { it.copy(id = 0) })
                }
            }

            // Restore preferences
            preferencesManager.saveUserProfile(backup.userProfile)
            preferencesManager.saveJeeMemory(backup.jeeMemory)
            preferencesManager.saveAIBehaviour(backup.aiBehaviour)
            preferencesManager.saveNotificationSettings(backup.notificationSettings)

            Result.success(true)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun clearAllData() = withContext(Dispatchers.IO) {
        database.withTransaction {
            missionDao.clearAll()
            focusSessionDao.clearAll()
            chatDao.clearAllChats()
            chatDao.clearAllMessages()
            syllabusDao.clearAll()
            testRecordDao.clearAll()
            workLogDao.clearAll()
        }
        preferencesManager.clearAllPreferences()
    }
}
