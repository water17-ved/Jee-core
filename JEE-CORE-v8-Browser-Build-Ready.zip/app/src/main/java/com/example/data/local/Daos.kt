package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ChatEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.Subject
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.WorkLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MissionDao {
    @Query("SELECT * FROM missions ORDER BY priority DESC, deadlineEpochMs ASC, createdAtEpochMs DESC")
    fun getAllMissions(): Flow<List<MissionEntity>>

    @Query("SELECT * FROM missions ORDER BY id ASC")
    suspend fun getAllMissionsList(): List<MissionEntity>

    @Query("SELECT * FROM missions WHERE status = :status ORDER BY priority DESC, deadlineEpochMs ASC")
    fun getMissionsByStatus(status: MissionStatus): Flow<List<MissionEntity>>

    @Query("SELECT * FROM missions WHERE id = :id")
    suspend fun getMissionById(id: Long): MissionEntity?

    @Query("SELECT COUNT(*) FROM missions")
    suspend fun getMissionCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMission(mission: MissionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMissions(missions: List<MissionEntity>)

    @Update
    suspend fun updateMission(mission: MissionEntity)

    @Delete
    suspend fun deleteMission(mission: MissionEntity)

    @Query("DELETE FROM missions WHERE id = :id")
    suspend fun deleteMissionById(id: Long)

    @Query("DELETE FROM missions")
    suspend fun clearAll()
}

@Dao
interface FocusSessionDao {
    @Query("SELECT * FROM focus_sessions ORDER BY startTimeEpochMs DESC")
    fun getAllFocusSessions(): Flow<List<FocusSessionEntity>>

    @Query("SELECT * FROM focus_sessions ORDER BY id ASC")
    suspend fun getAllFocusSessionsList(): List<FocusSessionEntity>

    @Query("SELECT * FROM focus_sessions WHERE startTimeEpochMs >= :sinceEpochMs ORDER BY startTimeEpochMs DESC")
    fun getSessionsSince(sinceEpochMs: Long): Flow<List<FocusSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: FocusSessionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessions(sessions: List<FocusSessionEntity>)

    @Delete
    suspend fun deleteSession(session: FocusSessionEntity)

    @Query("DELETE FROM focus_sessions")
    suspend fun clearAll()
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY updatedAtEpochMs DESC")
    fun getAllChats(): Flow<List<ChatEntity>>

    @Query("SELECT * FROM chats ORDER BY id ASC")
    suspend fun getAllChatsList(): List<ChatEntity>

    @Query("SELECT * FROM chat_messages ORDER BY id ASC")
    suspend fun getAllMessagesList(): List<ChatMessageEntity>

    @Query("SELECT * FROM chats WHERE id = :id")
    suspend fun getChatById(id: Long): ChatEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChat(chat: ChatEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChats(chats: List<ChatEntity>)

    @Update
    suspend fun updateChat(chat: ChatEntity)

    @Query("DELETE FROM chats WHERE id = :id")
    suspend fun deleteChatById(id: Long)

    @Query("SELECT * FROM chat_messages WHERE chatId = :chatId ORDER BY timestampEpochMs ASC")
    fun getMessagesForChat(chatId: Long): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessages(messages: List<ChatMessageEntity>)

    @Update
    suspend fun updateMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteMessageById(id: Long)

    @Query("DELETE FROM chat_messages WHERE chatId = :chatId")
    suspend fun deleteMessagesForChat(chatId: Long)

    @Query("DELETE FROM chats")
    suspend fun clearAllChats()

    @Query("DELETE FROM chat_messages")
    suspend fun clearAllMessages()
}

@Dao
interface SyllabusDao {
    @Query("SELECT * FROM syllabus_topics ORDER BY subject ASC, chapter ASC, topicName ASC")
    fun getAllTopics(): Flow<List<SyllabusTopicEntity>>

    @Query("SELECT * FROM syllabus_topics ORDER BY id ASC")
    suspend fun getAllTopicsList(): List<SyllabusTopicEntity>

    @Query("SELECT * FROM syllabus_topics WHERE subject = :subject ORDER BY chapter ASC")
    fun getTopicsBySubject(subject: Subject): Flow<List<SyllabusTopicEntity>>

    @Query("SELECT * FROM syllabus_topics WHERE isWeakArea = 1 OR state = 'WEAK' OR state = 'NEEDS_REVISION'")
    fun getWeakAndRevisionTopics(): Flow<List<SyllabusTopicEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopic(topic: SyllabusTopicEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(topics: List<SyllabusTopicEntity>)

    @Update
    suspend fun updateTopic(topic: SyllabusTopicEntity)

    @Query("SELECT COUNT(*) FROM syllabus_topics")
    suspend fun getTopicCount(): Int

    @Query("DELETE FROM syllabus_topics")
    suspend fun clearAll()
}

@Dao
interface TestRecordDao {
    @Query("SELECT * FROM test_records ORDER BY testDateEpochMs DESC")
    fun getAllTests(): Flow<List<TestRecordEntity>>

    @Query("SELECT * FROM test_records ORDER BY id ASC")
    suspend fun getAllTestsList(): List<TestRecordEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTest(test: TestRecordEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTests(tests: List<TestRecordEntity>)

    @Update
    suspend fun updateTest(test: TestRecordEntity)

    @Delete
    suspend fun deleteTest(test: TestRecordEntity)

    @Query("DELETE FROM test_records")
    suspend fun clearAll()
}

@Dao
interface WorkLogDao {
    @Query("SELECT * FROM work_logs ORDER BY timestampEpochMs DESC")
    fun getAllWorkLogs(): Flow<List<WorkLogEntity>>

    @Query("SELECT * FROM work_logs ORDER BY id ASC")
    suspend fun getAllWorkLogsList(): List<WorkLogEntity>

    @Query("SELECT * FROM work_logs WHERE timestampEpochMs >= :sinceEpochMs ORDER BY timestampEpochMs DESC")
    fun getWorkLogsSince(sinceEpochMs: Long): Flow<List<WorkLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkLog(log: WorkLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkLogs(logs: List<WorkLogEntity>)

    @Delete
    suspend fun deleteWorkLog(log: WorkLogEntity)

    @Query("DELETE FROM work_logs")
    suspend fun clearAll()
}
