package com.example.notification

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import com.example.data.preference.UserPreferencesManager

object NotificationHelper {
    const val CHANNEL_ID_MISSIONS = "jee_core_missions"
    const val CHANNEL_ID_FOCUS = "jee_core_focus"
    const val CHANNEL_ID_REVISION = "jee_core_revision"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val missionChannel = NotificationChannel(
                CHANNEL_ID_MISSIONS,
                "Missions & Deadlines",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Tactical reminders for daily JEE missions"
                enableVibration(true)
            }

            val focusChannel = NotificationChannel(
                CHANNEL_ID_FOCUS,
                "Focus Sessions",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when your focus timer finishes"
                enableVibration(true)
            }

            val revisionChannel = NotificationChannel(
                CHANNEL_ID_REVISION,
                "Revision & Backlog",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Periodic prompts for overdue chapters"
            }

            notificationManager.createNotificationChannels(listOf(missionChannel, focusChannel, revisionChannel))
        }
    }

    fun hasNotificationPermission(context: Context): Boolean {
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun sendTestNotification(context: Context): Boolean {
        if (!hasNotificationPermission(context)) return false

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_MISSIONS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("JEE CORE Active Alert")
            .setContentText("Your study command center is connected and monitoring execution.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(101, notification)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    fun sendFocusCompleteNotification(context: Context, missionTitle: String, durationMinutes: Int): Boolean {
        if (!hasNotificationPermission(context)) return false

        val prefs = UserPreferencesManager(context)
        if (!prefs.notificationSettings.value.focusCompleteNotification) {
            return false
        }

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            1002,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_FOCUS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Focus Session Complete")
            .setContentText("Completed $durationMinutes min sprint: $missionTitle. Log questions now.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(102, notification)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    fun sendMissionReminderNotification(context: Context, missionTitle: String): Boolean {
        if (!hasNotificationPermission(context)) return false

        val prefs = UserPreferencesManager(context)
        if (!prefs.notificationSettings.value.missionReminders) {
            return false
        }

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            1003,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_MISSIONS)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Mission Reminder")
            .setContentText("Target mission pending: $missionTitle")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(103, notification)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    fun sendRevisionDueNotification(context: Context, topicName: String): Boolean {
        if (!hasNotificationPermission(context)) return false

        val prefs = UserPreferencesManager(context)
        if (!prefs.notificationSettings.value.revisionDueNotification) {
            return false
        }

        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            1004,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID_REVISION)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Revision Due")
            .setContentText("Time to revise: $topicName. Spaced repetition due today.")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        return try {
            NotificationManagerCompat.from(context).notify(104, notification)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    fun scheduleMissionReminder(context: Context, missionTitle: String, triggerAtEpochMs: Long, requestCode: Int = 2001) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, JeeReminderReceiver::class.java).apply {
            action = JeeReminderReceiver.ACTION_MISSION_REMINDER
            putExtra(JeeReminderReceiver.EXTRA_MISSION_TITLE, missionTitle)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            alarmManager.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtEpochMs,
                pendingIntent
            )
        } catch (_: SecurityException) {
            alarmManager.set(
                AlarmManager.RTC_WAKEUP,
                triggerAtEpochMs,
                pendingIntent
            )
        }
    }

    fun cancelScheduledReminder(context: Context, requestCode: Int = 2001) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, JeeReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        pendingIntent?.let {
            alarmManager.cancel(it)
        }
    }
}
