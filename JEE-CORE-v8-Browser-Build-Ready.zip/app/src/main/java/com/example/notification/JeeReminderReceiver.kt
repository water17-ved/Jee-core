package com.example.notification

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.preference.UserPreferencesManager

class JeeReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = UserPreferencesManager(context)
        val settings = prefs.notificationSettings.value

        when (intent?.action) {
            ACTION_MISSION_REMINDER -> {
                if (settings.missionReminders) {
                    val missionTitle = intent.getStringExtra(EXTRA_MISSION_TITLE) ?: "Pending JEE Mission"
                    NotificationHelper.sendMissionReminderNotification(context, missionTitle)
                }
            }
            ACTION_REVISION_REMINDER -> {
                if (settings.revisionDueNotification) {
                    val topicName = intent.getStringExtra(EXTRA_TOPIC_NAME) ?: "Overdue Topic"
                    NotificationHelper.sendRevisionDueNotification(context, topicName)
                }
            }
        }
    }

    companion object {
        const val ACTION_MISSION_REMINDER = "com.example.notification.ACTION_MISSION_REMINDER"
        const val ACTION_REVISION_REMINDER = "com.example.notification.ACTION_REVISION_REMINDER"
        const val EXTRA_MISSION_TITLE = "extra_mission_title"
        const val EXTRA_TOPIC_NAME = "extra_topic_name"
    }
}
