package com.example.ai

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GeminiGenerateContentRequest(
    val contents: List<GeminiContent>,
    val generationConfig: GeminiGenerationConfig? = null,
    val systemInstruction: GeminiContent? = null
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    val role: String? = null,
    val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    val text: String? = null,
    val inlineData: GeminiInlineData? = null
)

@JsonClass(generateAdapter = true)
data class GeminiInlineData(
    val mimeType: String,
    val data: String
)

@JsonClass(generateAdapter = true)
data class GeminiGenerationConfig(
    val temperature: Float? = 0.4f,
    val topP: Float? = 0.95f,
    val topK: Int? = 40,
    val maxOutputTokens: Int? = 2048
)

@JsonClass(generateAdapter = true)
data class GeminiGenerateContentResponse(
    val candidates: List<GeminiCandidate>? = null,
    val promptFeedback: GeminiPromptFeedback? = null
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    val content: GeminiContent? = null,
    val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class GeminiPromptFeedback(
    val blockReason: String? = null
)

sealed class AIProgressStage(val step: Int, val description: String) {
    object Idle : AIProgressStage(0, "Ready")
    object UnderstandingRequest : AIProgressStage(1, "Understanding your request")
    object ReadingPreparationState : AIProgressStage(2, "Reading your preparation state")
    object CheckingStrategyAndPriorities : AIProgressStage(3, "Checking strategy and priorities")
    object GeneratingRecommendation : AIProgressStage(4, "Generating a practical recommendation")
    object CheckingFeasibility : AIProgressStage(5, "Checking feasibility against your behavior profile")
    object PreparingResponse : AIProgressStage(6, "Preparing the response")
    object Complete : AIProgressStage(7, "Complete")
    data class Error(val message: String) : AIProgressStage(-1, message)
}
