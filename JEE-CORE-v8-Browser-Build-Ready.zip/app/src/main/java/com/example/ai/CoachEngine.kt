package com.example.ai

import com.example.data.model.ExamType
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionCreator
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.PriorityLevel
import com.example.data.model.Subject
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.TopicState
import com.example.data.model.UserProfile
import com.example.data.model.WorkLogEntity
import java.util.Calendar

data class CoachExecutionState(
    val plannedMinutes: Int,
    val completedMinutes: Int,
    val remainingMinutes: Int,
    val progressPercent: Int,
    val questionsCompletedToday: Int,
    val accuracyToday: Float,
    val nowMission: MissionEntity?,
    val whyThisExplanation: String,
    val nextMission: MissionEntity?,
    val afterThatMission: MissionEntity?,
    val adaptiveRecoveryNote: String? = null,
    val profileIncomplete: Boolean = false
)

object CoachEngine {

    fun computeCoachState(
        profile: UserProfile,
        missions: List<MissionEntity>,
        focusSessions: List<FocusSessionEntity>,
        workLogs: List<WorkLogEntity>,
        syllabusTopics: List<SyllabusTopicEntity>,
        recentTests: List<TestRecordEntity>
    ): CoachExecutionState {
        if (!profile.isOnboardingComplete) {
            return CoachExecutionState(
                plannedMinutes = 0,
                completedMinutes = 0,
                remainingMinutes = 0,
                progressPercent = 0,
                questionsCompletedToday = 0,
                accuracyToday = 0f,
                nowMission = null,
                whyThisExplanation = "Profile setup not yet completed. Configure your target exam and time to activate the command center.",
                nextMission = null,
                afterThatMission = null,
                adaptiveRecoveryNote = null,
                profileIncomplete = true
            )
        }

        val startOfToday = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        // Calculate today's execution from actual sessions & logs
        val todaySessions = focusSessions.filter { it.startTimeEpochMs >= startOfToday }
        val todayLogs = workLogs.filter { it.timestampEpochMs >= startOfToday }

        val completedFocusMinutes = todaySessions.sumOf { it.actualDurationMinutes }
        val completedLogMinutes = todayLogs.sumOf { it.durationMinutes }
        val totalCompletedMinutes = maxOf(completedFocusMinutes, completedLogMinutes)

        // Today's missions
        val todayMissions = missions.filter {
            it.deadlineEpochMs <= startOfToday + 24 * 3600 * 1000L ||
                    it.status == MissionStatus.IN_PROGRESS ||
                    it.createdAtEpochMs >= startOfToday
        }

        val plannedMinutes = if (todayMissions.isNotEmpty()) {
            todayMissions.sumOf { it.plannedDurationMinutes }
        } else {
            val isWeekend = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) in listOf(Calendar.SATURDAY, Calendar.SUNDAY)
            val available = if (isWeekend) profile.weekendAvailableHours else profile.weekdayAvailableHours
            (available * 60).toInt()
        }

        val remainingMinutes = (plannedMinutes - totalCompletedMinutes).coerceAtLeast(0)
        val progressPercent = if (plannedMinutes > 0) {
            ((totalCompletedMinutes.toFloat() / plannedMinutes.toFloat()) * 100).toInt().coerceIn(0, 100)
        } else 0

        val totalQuestionsToday = todayLogs.sumOf { it.questionsAttempted } + todaySessions.sumOf { it.questionsCompleted }
        val correctQuestionsToday = todayLogs.sumOf { it.questionsCorrect }
        val accuracyToday = if (todayLogs.sumOf { it.questionsAttempted } > 0) {
            (correctQuestionsToday.toFloat() / todayLogs.sumOf { it.questionsAttempted }.toFloat()) * 100f
        } else 0f

        // Calculate candidate missions: Active / Not started
        val activeOrPendingMissions = missions.filter {
            it.status == MissionStatus.IN_PROGRESS || it.status == MissionStatus.NOT_STARTED
        }.sortedWith(
            compareByDescending<MissionEntity> { it.status == MissionStatus.IN_PROGRESS }
                .thenByDescending { it.priority.weight }
                .thenBy { it.deadlineEpochMs }
        )

        val nowMission: MissionEntity?
        val whyThis: String
        val nextMission: MissionEntity?
        val afterThatMission: MissionEntity?

        if (activeOrPendingMissions.isNotEmpty()) {
            nowMission = activeOrPendingMissions[0]
            nextMission = activeOrPendingMissions.getOrNull(1)
            afterThatMission = activeOrPendingMissions.getOrNull(2)

            // Determine why this from real database records
            val matchedTopic = syllabusTopics.find {
                it.chapter.equals(nowMission.chapter, ignoreCase = true) ||
                        it.topicName.equals(nowMission.topic, ignoreCase = true)
            }
            val matchedTest = recentTests.firstOrNull()

            whyThis = when {
                nowMission.status == MissionStatus.IN_PROGRESS ->
                    "Currently active session in ${nowMission.subject.displayName}. You have completed ${nowMission.completedQuantity}/${nowMission.targetQuantity} units."
                matchedTopic != null && matchedTopic.isWeakArea ->
                    "${nowMission.chapter} is flagged as a high-priority weak area with accuracy (${matchedTopic.pyqsCorrect}/${matchedTopic.pyqsAttempted.coerceAtLeast(1)} PYQs correct). Fits your remaining time block."
                matchedTopic != null && matchedTopic.state == TopicState.NEEDS_REVISION ->
                    "Revision for ${nowMission.topic} is due based on your syllabus tracking interval."
                matchedTest != null && matchedTest.accuracy < 60f ->
                    "Recent test performance in ${nowMission.subject.displayName} indicated vulnerability under time pressure. Targeted practice recommended."
                nowMission.priority == PriorityLevel.URGENT || nowMission.priority == PriorityLevel.HIGH ->
                    "High priority milestone with pending deadline. Requires focused problem solving."
                else ->
                    "Calculated based on your target exam (${profile.targetExam.displayName}) and your daily self-study window."
            }
        } else {
            nowMission = null
            whyThis = "No missions scheduled yet. Tap '+ Mission' to create your first targeted study block."
            nextMission = null
            afterThatMission = null
        }

        // Adaptive recovery check
        val skippedOrOverdue = missions.filter {
            it.status == MissionStatus.SKIPPED ||
                    (it.status == MissionStatus.NOT_STARTED && it.deadlineEpochMs < System.currentTimeMillis())
        }

        val adaptiveNote = if (skippedOrOverdue.isNotEmpty()) {
            val count = skippedOrOverdue.size
            val topChapter = skippedOrOverdue.first().chapter
            "You are slightly behind on $count scheduled tasks (e.g. $topChapter). Rather than dumping everything on tomorrow, JEE CORE recommends prioritizing the highest yield PYQs first."
        } else if (remainingMinutes > 0 && totalCompletedMinutes == 0 && Calendar.getInstance().get(Calendar.HOUR_OF_DAY) >= 19) {
            "Evening check: Today's remaining target is ${(remainingMinutes / 60)}h ${(remainingMinutes % 60)}m. Split your remaining time into two focused 45-min sprints."
        } else null

        return CoachExecutionState(
            plannedMinutes = plannedMinutes,
            completedMinutes = totalCompletedMinutes,
            remainingMinutes = remainingMinutes,
            progressPercent = progressPercent,
            questionsCompletedToday = totalQuestionsToday,
            accuracyToday = accuracyToday,
            nowMission = nowMission,
            whyThisExplanation = whyThis,
            nextMission = nextMission,
            afterThatMission = afterThatMission,
            adaptiveRecoveryNote = adaptiveNote,
            profileIncomplete = false
        )
    }

    fun generateFactsContext(
        profile: UserProfile,
        missions: List<MissionEntity>,
        focusSessions: List<FocusSessionEntity>,
        workLogs: List<WorkLogEntity>,
        syllabusTopics: List<SyllabusTopicEntity>,
        recentTests: List<TestRecordEntity>
    ): String {
        return buildString {
            append("1. Syllabus Weak Areas:\n")
            val weak = syllabusTopics.filter { it.isWeakArea || it.state == TopicState.WEAK }
            if (weak.isEmpty()) {
                append("   None explicitly flagged.\n")
            } else {
                weak.forEach {
                    append("   - [${it.subject.displayName}] ${it.chapter}: ${it.topicName} (Score: ${it.confidenceScore}%, PYQs: ${it.pyqsCorrect}/${it.pyqsAttempted})\n")
                }
            }

            append("2. Recent Test Records:\n")
            if (recentTests.isEmpty()) {
                append("   No formal mock tests recorded yet.\n")
            } else {
                recentTests.take(3).forEach {
                    append("   - ${it.testName}: Score ${it.userScore}/${it.totalMarks} (${it.accuracy}% accuracy). P: ${it.physicsScore}, C: ${it.chemistryScore}, M: ${it.mathsScore}. Errors: ${it.conceptualErrors} conceptual, ${it.calculationErrors} calc.\n")
                }
            }

            append("3. Active Missions (${missions.count { it.status == MissionStatus.IN_PROGRESS || it.status == MissionStatus.NOT_STARTED }} pending):\n")
            missions.take(5).forEach {
                append("   - [${it.status.displayName}] ${it.title} (${it.subject.displayName} - ${it.chapter}), ${it.plannedDurationMinutes}m, Priority: ${it.priority.displayName}\n")
            }

            append("4. Recent Work Log & Focus Hours:\n")
            val totalMinutes = focusSessions.sumOf { it.actualDurationMinutes } + workLogs.sumOf { it.durationMinutes }
            append("   - Total logged focus: ${totalMinutes / 60}h ${totalMinutes % 60}m across ${focusSessions.size} sessions.\n")
        }
    }
}
