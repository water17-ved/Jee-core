package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.preference.UserPreferencesManager
import com.example.data.repository.JeeCoreRepository
import com.example.notification.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class JeeCoreApp : Application() {
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var repository: JeeCoreRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.getDatabase(this)
        val preferencesManager = UserPreferencesManager(this)
        repository = JeeCoreRepository(database, preferencesManager)

        NotificationHelper.createNotificationChannels(this)

        applicationScope.launch {
            repository.initializeSyllabusIfNeeded()
        }
    }
}
