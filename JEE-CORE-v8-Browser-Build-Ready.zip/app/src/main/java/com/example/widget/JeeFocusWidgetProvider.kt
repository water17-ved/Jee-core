package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.preference.UserPreferencesManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class JeeFocusWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAll(context, appWidgetManager, appWidgetIds)
    }

    companion object {
        fun updateAll(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                val prefs = UserPreferencesManager(context)
                val userProfile = prefs.userProfile.value

                val startOfDay = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }.timeInMillis

                val allLogs = db.workLogDao().getAllWorkLogsList()
                val todayLogs = allLogs.filter { it.timestampEpochMs >= startOfDay }
                val todayMinutes = todayLogs.sumOf { it.durationMinutes }

                val targetHours = userProfile.weekdayAvailableHours
                val hours = todayMinutes / 60
                val mins = todayMinutes % 60

                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    putExtra("OPEN_FOCUS_TIMER", true)
                }
                val pendingIntent = PendingIntent.getActivity(
                    context, 2, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                for (widgetId in appWidgetIds) {
                    val views = RemoteViews(context.packageName, R.layout.widget_jee_focus).apply {
                        setTextViewText(R.id.widget_focus_duration, "${hours}h ${mins}m")
                        setTextViewText(R.id.widget_focus_sessions, "${todayLogs.size} logs today")
                        setTextViewText(R.id.widget_focus_target, "Goal: %.1fh / day".format(targetHours))
                        setOnClickPendingIntent(R.id.widget_focus_root, pendingIntent)
                        setOnClickPendingIntent(R.id.widget_focus_btn, pendingIntent)
                    }
                    appWidgetManager.updateAppWidget(widgetId, views)
                }
            }
        }
    }
}
