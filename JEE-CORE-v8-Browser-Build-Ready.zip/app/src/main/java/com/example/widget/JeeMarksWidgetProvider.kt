package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JeeMarksWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAll(context, appWidgetManager, appWidgetIds)
    }

    companion object {
        fun updateAll(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                val tests = db.testRecordDao().getAllTestsList()
                val latest = tests.maxByOrNull { it.testDateEpochMs }

                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pendingIntent = PendingIntent.getActivity(
                    context, 1, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                for (widgetId in appWidgetIds) {
                    val views = RemoteViews(context.packageName, R.layout.widget_jee_marks).apply {
                        if (latest != null) {
                            setTextViewText(R.id.widget_test_name, latest.testName)
                            setTextViewText(R.id.widget_test_score, "${latest.userScore} / ${latest.totalMarks}")
                            setTextViewText(R.id.widget_accuracy_badge, "${latest.accuracy.toInt()}% Acc")
                            setTextViewText(
                                R.id.widget_subject_scores,
                                "P: ${latest.physicsScore} | C: ${latest.chemistryScore} | M: ${latest.mathsScore}"
                            )

                            val errText = if (latest.conceptualErrors > 0 || latest.calculationErrors > 0 || latest.sillyMistakes > 0) {
                                "Errors: ${latest.conceptualErrors} concept | ${latest.calculationErrors} calc | ${latest.sillyMistakes} silly"
                            } else if (latest.weakChaptersIdentified.isNotBlank()) {
                                "Weak area: ${latest.weakChaptersIdentified}"
                            } else {
                                "Exam: ${latest.examType.displayName}"
                            }
                            setTextViewText(R.id.widget_error_summary, errText)
                        } else {
                            setTextViewText(R.id.widget_test_name, "No tests logged yet")
                            setTextViewText(R.id.widget_test_score, "-- / 300")
                            setTextViewText(R.id.widget_accuracy_badge, "--% Acc")
                            setTextViewText(R.id.widget_subject_scores, "Tap to log mock test diagnostics")
                            setTextViewText(R.id.widget_error_summary, "Log tests to track error patterns")
                        }
                        setOnClickPendingIntent(R.id.widget_marks_root, pendingIntent)
                    }
                    appWidgetManager.updateAppWidget(widgetId, views)
                }
            }
        }
    }
}
