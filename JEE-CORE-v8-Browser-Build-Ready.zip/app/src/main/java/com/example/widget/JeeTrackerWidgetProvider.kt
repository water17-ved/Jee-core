package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.model.Subject
import com.example.data.model.TopicState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class JeeTrackerWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        updateAll(context, appWidgetManager, appWidgetIds)
    }

    companion object {
        fun updateAll(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
            CoroutineScope(Dispatchers.IO).launch {
                val db = AppDatabase.getDatabase(context)
                val topics = db.syllabusDao().getAllTopicsList()
                val missions = db.missionDao().getAllMissionsList()

                val pTopics = topics.filter { it.subject == Subject.PHYSICS }
                val cTopics = topics.filter { it.subject == Subject.CHEMISTRY }
                val mTopics = topics.filter { it.subject == Subject.MATHEMATICS }

                val pPct = if (pTopics.isNotEmpty()) (pTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE } * 100) / pTopics.size else 0
                val cPct = if (cTopics.isNotEmpty()) (cTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE } * 100) / cTopics.size else 0
                val mPct = if (mTopics.isNotEmpty()) (mTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE } * 100) / mTopics.size else 0

                val totalMastered = topics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE }
                val totalPct = if (topics.isNotEmpty()) (totalMastered * 100) / topics.size else 0

                val activeMission = missions.firstOrNull { it.status == com.example.data.model.MissionStatus.IN_PROGRESS }
                    ?: missions.firstOrNull { it.status == com.example.data.model.MissionStatus.NOT_STARTED }

                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pendingIntent = PendingIntent.getActivity(
                    context, 0, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )

                for (widgetId in appWidgetIds) {
                    val views = RemoteViews(context.packageName, R.layout.widget_jee_tracker).apply {
                        setTextViewText(R.id.widget_total_percent, "$totalPct% SYLLABUS")
                        setProgressBar(R.id.widget_progress_bar, 100, totalPct, false)
                        setTextViewText(R.id.widget_physics_text, "P: $pPct%")
                        setTextViewText(R.id.widget_chem_text, "C: $cPct%")
                        setTextViewText(R.id.widget_math_text, "M: $mPct%")

                        val statusText = if (activeMission != null) {
                            "Next: ${activeMission.title} (${activeMission.subject.displayName})"
                        } else {
                            "All targets active. Tap to enter Command Center."
                        }
                        setTextViewText(R.id.widget_status_text, statusText)
                        setOnClickPendingIntent(R.id.widget_tracker_root, pendingIntent)
                    }
                    appWidgetManager.updateAppWidget(widgetId, views)
                }
            }
        }
    }
}
