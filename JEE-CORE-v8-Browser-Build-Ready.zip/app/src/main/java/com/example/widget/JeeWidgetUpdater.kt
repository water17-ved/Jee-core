package com.example.widget

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context

object JeeWidgetUpdater {
    fun updateAllWidgets(context: Context) {
        val appWidgetManager = AppWidgetManager.getInstance(context) ?: return

        // 1. Tracker Widget
        val trackerComponent = ComponentName(context, JeeTrackerWidgetProvider::class.java)
        val trackerIds = appWidgetManager.getAppWidgetIds(trackerComponent)
        if (trackerIds.isNotEmpty()) {
            JeeTrackerWidgetProvider.updateAll(context, appWidgetManager, trackerIds)
        }

        // 2. Marks Widget
        val marksComponent = ComponentName(context, JeeMarksWidgetProvider::class.java)
        val marksIds = appWidgetManager.getAppWidgetIds(marksComponent)
        if (marksIds.isNotEmpty()) {
            JeeMarksWidgetProvider.updateAll(context, appWidgetManager, marksIds)
        }

        // 3. Focus Widget
        val focusComponent = ComponentName(context, JeeFocusWidgetProvider::class.java)
        val focusIds = appWidgetManager.getAppWidgetIds(focusComponent)
        if (focusIds.isNotEmpty()) {
            JeeFocusWidgetProvider.updateAll(context, appWidgetManager, focusIds)
        }
    }
}
