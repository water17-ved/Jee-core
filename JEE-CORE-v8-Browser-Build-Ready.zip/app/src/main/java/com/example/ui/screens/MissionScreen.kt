package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.PriorityLevel
import com.example.ui.components.PriorityBadge
import com.example.ui.components.SubjectBadge
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.util.Calendar

enum class MissionFilterTab(val label: String) {
    ALL("ALL"),
    TODAY("TODAY"),
    ACTIVE("ACTIVE"),
    COMPLETED("COMPLETED"),
    RESCHEDULED("RESCHEDULED")
}

@Composable
fun MissionScreen(
    missions: List<MissionEntity>,
    onStartMission: (MissionEntity) -> Unit,
    onCompleteMission: (MissionEntity) -> Unit,
    onRescheduleMission: (MissionEntity) -> Unit,
    onSkipMission: (MissionEntity) -> Unit,
    onUpdateMission: (MissionEntity) -> Unit,
    onDeleteMission: (MissionEntity) -> Unit,
    onOpenCreateMission: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(MissionFilterTab.ALL) }
    var detailedMission by remember { mutableStateOf<MissionEntity?>(null) }

    val startOfToday = remember {
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    val filteredMissions = remember(missions, selectedTab) {
        when (selectedTab) {
            MissionFilterTab.ALL -> missions
            MissionFilterTab.TODAY -> missions.filter {
                it.createdAtEpochMs >= startOfToday || it.deadlineEpochMs <= startOfToday + 24 * 3600 * 1000L
            }
            MissionFilterTab.ACTIVE -> missions.filter {
                it.status == MissionStatus.IN_PROGRESS || it.status == MissionStatus.NOT_STARTED
            }
            MissionFilterTab.COMPLETED -> missions.filter { it.status == MissionStatus.COMPLETED }
            MissionFilterTab.RESCHEDULED -> missions.filter { it.status == MissionStatus.RESCHEDULED }
        }
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenCreateMission,
                containerColor = ElectricCyanPrimary,
                contentColor = Color(0xFF00363D),
                modifier = Modifier.testTag("fab_add_mission")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Mission")
            }
        },
        containerColor = DarkSlateBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = "EXECUTION MISSIONS",
                color = TextPrimary,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Tabs Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                MissionFilterTab.values().forEach { tab ->
                    val isSelected = selectedTab == tab
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateCard)
                            .border(
                                1.dp,
                                if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { selectedTab = tab }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = tab.label,
                            color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (filteredMissions.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No missions in this category", color = TextSecondary, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = onOpenCreateMission,
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricCyanPrimary)
                        ) {
                            Text("+ Create Mission")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredMissions, key = { it.id }) { mission ->
                        MissionItemCard(
                            mission = mission,
                            onClick = { detailedMission = mission },
                            onStart = { onStartMission(mission) },
                            onComplete = { onCompleteMission(mission) },
                            onReschedule = { onRescheduleMission(mission) },
                            onSkip = { onSkipMission(mission) }
                        )
                    }
                }
            }
        }
    }

    // Mission Detail Dialog / Editor
    detailedMission?.let { mission ->
        MissionDetailDialog(
            mission = mission,
            onDismiss = { detailedMission = null },
            onSave = { updated ->
                onUpdateMission(updated)
                detailedMission = null
            },
            onDelete = {
                onDeleteMission(mission)
                detailedMission = null
            }
        )
    }
}

@Composable
fun MissionItemCard(
    mission: MissionEntity,
    onClick: () -> Unit,
    onStart: () -> Unit,
    onComplete: () -> Unit,
    onReschedule: () -> Unit,
    onSkip: () -> Unit
) {
    val progress = if (mission.targetQuantity > 0) {
        (mission.completedQuantity.toFloat() / mission.targetQuantity.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSlateCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("mission_card_${mission.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    SubjectBadge(subject = mission.subject)
                    Text(
                        text = mission.status.displayName.uppercase(),
                        color = when (mission.status) {
                            MissionStatus.COMPLETED -> SuccessGreen
                            MissionStatus.IN_PROGRESS -> ElectricCyanPrimary
                            MissionStatus.RESCHEDULED -> WarningAmber
                            MissionStatus.SKIPPED -> Color(0xFF64748B)
                            else -> TextSecondary
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                PriorityBadge(priority = mission.priority)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = mission.title,
                color = TextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "${mission.chapter} • ${mission.topic}",
                color = TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = if (mission.status == MissionStatus.COMPLETED) SuccessGreen else ElectricCyanPrimary,
                trackColor = DarkSlateBorder
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${mission.completedQuantity} / ${mission.targetQuantity} PYQs",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Text(
                    text = "${mission.plannedDurationMinutes}m planned",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (mission.status != MissionStatus.COMPLETED) {
                    Button(
                        onClick = onStart,
                        modifier = Modifier.weight(1f).height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("START", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    Button(
                        onClick = onComplete,
                        modifier = Modifier.weight(1f).height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("DONE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = onReschedule,
                        modifier = Modifier.weight(1f).height(36.dp),
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Text("RESCHEDULE", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                } else {
                    OutlinedButton(
                        onClick = onReschedule,
                        modifier = Modifier.fillMaxWidth().height(36.dp),
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Text("REPEAT / REVISE MISSION", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun MissionDetailDialog(
    mission: MissionEntity,
    onDismiss: () -> Unit,
    onSave: (MissionEntity) -> Unit,
    onDelete: () -> Unit
) {
    var title by remember { mutableStateOf(mission.title) }
    var plannedDuration by remember { mutableStateOf(mission.plannedDurationMinutes.toString()) }
    var targetQuantity by remember { mutableStateOf(mission.targetQuantity.toString()) }
    var completedQuantity by remember { mutableStateOf(mission.completedQuantity.toString()) }
    var priority by remember { mutableStateOf(mission.priority) }
    var notes by remember { mutableStateOf(mission.notes) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Mission Details", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = plannedDuration,
                        onValueChange = { plannedDuration = it },
                        label = { Text("Duration (m)") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
                    )
                    OutlinedTextField(
                        value = targetQuantity,
                        onValueChange = { targetQuantity = it },
                        label = { Text("Target PYQs") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = completedQuantity,
                    onValueChange = { completedQuantity = it },
                    label = { Text("Completed PYQs") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text("CANCEL")
                    }
                    Button(
                        onClick = {
                            val duration = plannedDuration.toIntOrNull() ?: mission.plannedDurationMinutes
                            val target = targetQuantity.toIntOrNull() ?: mission.targetQuantity
                            val completed = completedQuantity.toIntOrNull() ?: mission.completedQuantity
                            val status = if (completed >= target) MissionStatus.COMPLETED else mission.status
                            onSave(
                                mission.copy(
                                    title = title,
                                    plannedDurationMinutes = duration,
                                    targetQuantity = target,
                                    completedQuantity = completed,
                                    status = status,
                                    notes = notes
                                )
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                    ) {
                        Text("SAVE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
