package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.CoachExecutionState
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.ui.components.PriorityBadge
import com.example.ui.components.MarkdownRenderer
import com.example.ui.components.SubjectBadge
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.DarkSlateCardHover
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun CoachScreen(
    coachState: CoachExecutionState,
    onStartMission: (MissionEntity) -> Unit,
    onCompleteMission: (MissionEntity) -> Unit,
    onRescheduleMission: (MissionEntity) -> Unit,
    onSkipMission: (MissionEntity) -> Unit,
    onOpenCreateMission: () -> Unit,
    onOpenLogWork: () -> Unit,
    onOpenFocusTimer: (MissionEntity?) -> Unit,
    onAskCoach: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkSlateBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        // Today's Execution Summary Header
        TodayExecutionCard(coachState)

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Action Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            QuickActionButton(
                label = "+ MISSION",
                icon = Icons.Default.Add,
                modifier = Modifier.weight(1f),
                onClick = onOpenCreateMission,
                testTag = "quick_add_mission"
            )
            QuickActionButton(
                label = "LOG WORK",
                icon = Icons.Default.Edit,
                modifier = Modifier.weight(1f),
                onClick = onOpenLogWork,
                testTag = "quick_log_work"
            )
            QuickActionButton(
                label = "FOCUS",
                icon = Icons.Default.Timer,
                modifier = Modifier.weight(1f),
                onClick = { onOpenFocusTimer(coachState.nowMission) },
                testTag = "quick_focus_timer"
            )
            QuickActionButton(
                label = "ASK COACH",
                icon = Icons.Default.HelpOutline,
                modifier = Modifier.weight(1f),
                onClick = { onAskCoach("Give me an immediate tactical evaluation of my preparation today.") },
                testTag = "quick_ask_coach"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Adaptive Recovery Banner if behind schedule
        if (coachState.adaptiveRecoveryNote != null) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = WarningAmber.copy(alpha = 0.12f),
                border = androidx.compose.foundation.BorderStroke(1.dp, WarningAmber.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(20.dp))
                    Column {
                        Text(
                            "ADAPTIVE RECOVERY RECOMMENDATION",
                            color = WarningAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        MarkdownRenderer(
                            markdown = coachState.adaptiveRecoveryNote,
                            textColor = TextPrimary
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // RIGHT NOW Section
        Text(
            text = "RIGHT NOW",
            color = ElectricCyanPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        val nowMission = coachState.nowMission
        if (nowMission != null) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.2.dp, ElectricCyanPrimary.copy(alpha = 0.8f)),
                modifier = Modifier.fillMaxWidth().testTag("right_now_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SubjectBadge(subject = nowMission.subject)
                        PriorityBadge(priority = nowMission.priority)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = nowMission.title,
                        color = TextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "${nowMission.chapter} • ${nowMission.topic}",
                        color = TextSecondary,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Target: ${nowMission.targetQuantity} PYQs (${nowMission.plannedDurationMinutes}m)",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Done: ${nowMission.completedQuantity}",
                            color = ElectricCyanPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Tactical Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onStartMission(nowMission) },
                            modifier = Modifier.weight(1.2f).height(42.dp).testTag("start_now_mission"),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF00363D), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("START", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }

                        Button(
                            onClick = { onCompleteMission(nowMission) },
                            modifier = Modifier.weight(1f).height(42.dp).testTag("done_now_mission"),
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("DONE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { onRescheduleMission(nowMission) },
                            modifier = Modifier.weight(1f).height(42.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                        ) {
                            Text("RESCHEDULE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { onSkipMission(nowMission) },
                            modifier = Modifier.weight(0.7f).height(42.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                        ) {
                            Text("SKIP", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No active missions right now", color = TextSecondary, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onOpenCreateMission,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                    ) {
                        Text("+ Create First Mission", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // WHY THIS? Card
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = DarkSlateCardHover,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = ElectricCyanPrimary, modifier = Modifier.size(18.dp))
                Column {
                    Text("WHY THIS?", color = ElectricCyanPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(3.dp))
                    MarkdownRenderer(
                        markdown = coachState.whyThisExplanation,
                        textColor = TextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // NEXT Section
        Text(
            text = "NEXT",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        val nextMission = coachState.nextMission
        if (nextMission != null) {
            MissionPreviewCard(mission = nextMission, onStart = { onStartMission(nextMission) })
        } else {
            Text("No upcoming mission queued", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp))
        }

        Spacer(modifier = Modifier.height(16.dp))

        // AFTER THAT Section
        Text(
            text = "AFTER THAT",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(6.dp))

        val afterThatMission = coachState.afterThatMission
        if (afterThatMission != null) {
            MissionPreviewCard(mission = afterThatMission, onStart = { onStartMission(afterThatMission) })
        } else {
            Text("No tertiary mission queued", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp))
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun TodayExecutionCard(coachState: CoachExecutionState) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = DarkSlateCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
        modifier = Modifier.fillMaxWidth().testTag("today_execution_card")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TODAY'S EXECUTION",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "${coachState.progressPercent}%",
                    color = ElectricCyanPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            LinearProgressIndicator(
                progress = { coachState.progressPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = ElectricCyanPrimary,
                trackColor = DarkSlateBorder
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                MetricColumn(
                    label = "PLANNED",
                    value = "${coachState.plannedMinutes / 60}h ${coachState.plannedMinutes % 60}m"
                )
                MetricColumn(
                    label = "COMPLETED",
                    value = "${coachState.completedMinutes / 60}h ${coachState.completedMinutes % 60}m",
                    valueColor = SuccessGreen
                )
                MetricColumn(
                    label = "REMAINING",
                    value = "${coachState.remainingMinutes / 60}h ${coachState.remainingMinutes % 60}m"
                )
                MetricColumn(
                    label = "ACCURACY",
                    value = if (coachState.accuracyToday > 0) "${coachState.accuracyToday.toInt()}%" else "--",
                    valueColor = if (coachState.accuracyToday >= 75) SuccessGreen else ElectricCyanPrimary
                )
            }
        }
    }
}

@Composable
private fun MetricColumn(
    label: String,
    value: String,
    valueColor: Color = TextPrimary
) {
    Column {
        Text(label, color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(2.dp))
        Text(value, color = valueColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun QuickActionButton(
    label: String,
    icon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(DarkSlateCard)
            .border(1.dp, DarkSlateBorder, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 4.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = null, tint = ElectricCyanPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, color = TextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MissionPreviewCard(
    mission: MissionEntity,
    onStart: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = DarkSlateCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SubjectBadge(subject = mission.subject)
                    Text(
                        text = "${mission.plannedDurationMinutes}m • ${mission.targetQuantity} PYQs",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = mission.title,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            IconButton(
                onClick = onStart,
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(ElectricCyanPrimary.copy(alpha = 0.15f))
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = "Start", tint = ElectricCyanPrimary, modifier = Modifier.size(20.dp))
            }
        }
    }
}
