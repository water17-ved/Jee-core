package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkSlateColorScheme = darkColorScheme(
    primary = ElectricCyanPrimary,
    onPrimary = Color(0xFF00363D),
    primaryContainer = Color(0xFF004F58),
    onPrimaryContainer = Color(0xFF97F0FF),

    secondary = SecondaryIndigo,
    onSecondary = Color(0xFF1E1B4B),
    secondaryContainer = Color(0xFF312E81),
    onSecondaryContainer = Color(0xFFE0E7FF),

    tertiary = SecondaryPurple,
    onTertiary = Color(0xFF3B0764),

    background = DarkSlateBackground,
    onBackground = TextPrimary,

    surface = DarkSlateSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSlateCard,
    onSurfaceVariant = TextSecondary,

    outline = DarkSlateBorder,
    outlineVariant = Color(0xFF1E293B),

    error = ErrorRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // JEE CORE is phone-first dark slate by specification
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkSlateColorScheme,
        typography = Typography,
        content = content
    )
}
