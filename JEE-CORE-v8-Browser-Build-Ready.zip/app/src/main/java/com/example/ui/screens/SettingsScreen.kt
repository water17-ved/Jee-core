package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.AIBehaviour
import com.example.data.model.BackupPreview
import com.example.data.model.ExamType
import com.example.data.model.JeeMemory
import com.example.data.model.NotificationSettings
import com.example.data.model.UserProfile
import com.example.notification.NotificationHelper
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.DarkSlateCardHover
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsScreen(
    userProfile: UserProfile,
    aiBehaviour: AIBehaviour,
    jeeMemory: JeeMemory,
    notificationSettings: NotificationSettings,
    customApiKey: String,
    onSaveProfile: (UserProfile) -> Unit,
    onSaveAIBehaviour: (AIBehaviour) -> Unit,
    onSaveJeeMemory: (JeeMemory) -> Unit,
    onSaveNotificationSettings: (NotificationSettings) -> Unit,
    onSaveApiKey: (String) -> Unit,
    onTestGeminiConnection: ((Result<String>) -> Unit) -> Unit,
    onExportBackup: ((String) -> Unit) -> Unit,
    onValidateAndPreviewBackup: (String, (Result<BackupPreview>) -> Unit) -> Unit = { _, _ -> },
    onImportBackup: (String, (Boolean, String?) -> Unit) -> Unit,
    onClearAllData: () -> Unit
) {
    val context = LocalContext.current
    var expandedSection by remember { mutableStateOf("ai_behaviour") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkSlateBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text("COMMAND CENTER SETTINGS", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Spacer(modifier = Modifier.height(14.dp))

        // 1. AI Behaviour Section
        SettingsAccordion(
            title = "AI Behaviour Tuning",
            subtitle = "Strictness, conciseness, directness and custom rules",
            isExpanded = expandedSection == "ai_behaviour",
            onToggle = { expandedSection = if (expandedSection == "ai_behaviour") "" else "ai_behaviour" }
        ) {
            AIBehaviourEditor(aiBehaviour, onSaveAIBehaviour)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2. Profile & Schedule
        SettingsAccordion(
            title = "Profile & Study Schedule",
            subtitle = "${userProfile.targetExam.displayName} ${userProfile.targetYear} • ${userProfile.weekdayAvailableHours.toInt()}h/day",
            isExpanded = expandedSection == "profile",
            onToggle = { expandedSection = if (expandedSection == "profile") "" else "profile" }
        ) {
            ProfileEditor(userProfile, onSaveProfile)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3. JEE Memory
        SettingsAccordion(
            title = "JEE Memory Core",
            subtitle = "What the AI coach continuously tracks about your preparation",
            isExpanded = expandedSection == "memory",
            onToggle = { expandedSection = if (expandedSection == "memory") "" else "memory" }
        ) {
            JeeMemoryEditor(jeeMemory, onSaveJeeMemory)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 4. Gemini API Configuration
        SettingsAccordion(
            title = "Gemini API Configuration",
            subtitle = "Model: gemini-3.5-flash • Key and connection test",
            isExpanded = expandedSection == "gemini",
            onToggle = { expandedSection = if (expandedSection == "gemini") "" else "gemini" }
        ) {
            GeminiConfigEditor(customApiKey, onSaveApiKey, onTestGeminiConnection)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 5. Notifications
        SettingsAccordion(
            title = "Android Notifications",
            subtitle = "Real notifications with channels & permission test",
            isExpanded = expandedSection == "notifications",
            onToggle = { expandedSection = if (expandedSection == "notifications") "" else "notifications" }
        ) {
            NotificationsEditor(context, notificationSettings, onSaveNotificationSettings)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 6. Data & Backup
        SettingsAccordion(
            title = "Data & JSON Backup",
            subtitle = "Export JSON backup, preview & restore state, or reset",
            isExpanded = expandedSection == "data",
            onToggle = { expandedSection = if (expandedSection == "data") "" else "data" }
        ) {
            DataBackupEditor(context, onExportBackup, onValidateAndPreviewBackup, onImportBackup, onClearAllData)
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 7. About
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("JEE CORE", color = ElectricCyanPrimary, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text("Version 1.0.0 (Native Android Build)", color = TextSecondary, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Deterministic local execution engine + Gemini AI interpretation. Zero data sold. Offline-first Room persistence.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun SettingsAccordion(
    title: String,
    subtitle: String,
    isExpanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSlateCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isExpanded) ElectricCyanPrimary.copy(alpha = 0.6f) else DarkSlateBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggle)
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(subtitle, color = TextSecondary, fontSize = 11.sp)
                }
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandMore else Icons.Default.ChevronRight,
                    contentDescription = null,
                    tint = if (isExpanded) ElectricCyanPrimary else TextSecondary
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    content()
                }
            }
        }
    }
}

@Composable
fun AIBehaviourEditor(
    behaviour: AIBehaviour,
    onSave: (AIBehaviour) -> Unit
) {
    var strictness by remember { mutableFloatStateOf(behaviour.strictness) }
    var conciseness by remember { mutableFloatStateOf(behaviour.conciseness) }
    var directness by remember { mutableFloatStateOf(behaviour.directness) }
    var executionFocus by remember { mutableFloatStateOf(behaviour.executionFocus) }
    var instructions by remember { mutableStateOf(behaviour.customInstructions) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Strictness: ${if (strictness > 0.6f) "Uncompromising" else "Gentle"}", color = TextPrimary, fontSize = 12.sp)
            Text("${(strictness * 100).toInt()}%", color = ElectricCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = strictness, onValueChange = { strictness = it }, colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Brevity: ${if (conciseness > 0.6f) "Ultra Concise" else "Detailed"}", color = TextPrimary, fontSize = 12.sp)
            Text("${(conciseness * 100).toInt()}%", color = ElectricCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = conciseness, onValueChange = { conciseness = it }, colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Directness: ${if (directness > 0.6f) "Direct Commands" else "Explanatory"}", color = TextPrimary, fontSize = 12.sp)
            Text("${(directness * 100).toInt()}%", color = ElectricCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Slider(value = directness, onValueChange = { directness = it }, colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary))

        OutlinedTextField(
            value = instructions,
            onValueChange = { instructions = it },
            label = { Text("Custom Directives for Coach") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )

        Button(
            onClick = {
                onSave(
                    behaviour.copy(
                        strictness = strictness,
                        conciseness = conciseness,
                        directness = directness,
                        executionFocus = executionFocus,
                        customInstructions = instructions
                    )
                )
            },
            modifier = Modifier.fillMaxWidth().height(42.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
        ) {
            Text("SAVE AI CONTROLS", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun ProfileEditor(
    profile: UserProfile,
    onSave: (UserProfile) -> Unit
) {
    var exam by remember { mutableStateOf(profile.targetExam) }
    var year by remember { mutableIntStateOf(profile.targetYear) }
    var rank by remember { mutableStateOf(profile.targetRank) }
    var weekdayHours by remember { mutableFloatStateOf(profile.weekdayAvailableHours) }
    var weekendHours by remember { mutableFloatStateOf(profile.weekendAvailableHours) }
    var coachingStart by remember { mutableStateOf(profile.coachingStart) }
    var coachingEnd by remember { mutableStateOf(profile.coachingEnd) }
    var meals by remember { mutableStateOf(profile.mealsSchedule) }
    var fixed by remember { mutableStateOf(profile.fixedCommitments) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ExamType.values().forEach { et ->
                val isSelected = exam == et
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateBackground)
                        .border(1.dp, if (isSelected) ElectricCyanPrimary else DarkSlateBorder, RoundedCornerShape(6.dp))
                        .clickable { exam = et }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(et.displayName.take(8), color = if (isSelected) ElectricCyanPrimary else TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        OutlinedTextField(
            value = rank,
            onValueChange = { rank = it },
            label = { Text("Target Rank / Percentile") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Weekday: ${weekdayHours.toInt()}h", color = TextPrimary, fontSize = 12.sp)
            Text("Weekend: ${weekendHours.toInt()}h", color = ElectricCyanPrimary, fontSize = 12.sp)
        }
        Slider(value = weekdayHours, onValueChange = { weekdayHours = it }, valueRange = 2f..14f, colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary))

        OutlinedTextField(
            value = fixed,
            onValueChange = { fixed = it },
            label = { Text("Fixed Commitments") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )

        Button(
            onClick = {
                onSave(
                    profile.copy(
                        targetExam = exam,
                        targetYear = year,
                        targetRank = rank,
                        weekdayAvailableHours = weekdayHours,
                        weekendAvailableHours = weekendHours,
                        coachingStart = coachingStart,
                        coachingEnd = coachingEnd,
                        mealsSchedule = meals,
                        fixedCommitments = fixed
                    )
                )
            },
            modifier = Modifier.fillMaxWidth().height(42.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
        ) {
            Text("SAVE PROFILE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun JeeMemoryEditor(
    memory: JeeMemory,
    onSave: (JeeMemory) -> Unit
) {
    var strengths by remember { mutableStateOf(memory.strengths) }
    var weaknesses by remember { mutableStateOf(memory.weaknesses) }
    var recurring by remember { mutableStateOf(memory.recurringProblems) }
    var backlog by remember { mutableStateOf(memory.backlogNotes) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value = strengths,
            onValueChange = { strengths = it },
            label = { Text("Strengths") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
        OutlinedTextField(
            value = weaknesses,
            onValueChange = { weaknesses = it },
            label = { Text("Weaknesses") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
        OutlinedTextField(
            value = recurring,
            onValueChange = { recurring = it },
            label = { Text("Recurring Test Traps") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
        OutlinedTextField(
            value = backlog,
            onValueChange = { backlog = it },
            label = { Text("Current Backlog") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )

        Button(
            onClick = {
                onSave(
                    memory.copy(
                        strengths = strengths,
                        weaknesses = weaknesses,
                        recurringProblems = recurring,
                        backlogNotes = backlog
                    )
                )
            },
            modifier = Modifier.fillMaxWidth().height(42.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
        ) {
            Text("UPDATE JEE MEMORY", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
fun GeminiConfigEditor(
    customApiKey: String,
    onSaveApiKey: (String) -> Unit,
    onTestConnection: ((Result<String>) -> Unit) -> Unit
) {
    var key by remember { mutableStateOf(customApiKey) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var isTesting by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Model: gemini-3.5-flash", color = ElectricCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

        OutlinedTextField(
            value = key,
            onValueChange = { key = it },
            label = { Text("Custom Gemini API Key") },
            placeholder = { Text("Enter key or leave blank to use BuildConfig") },
            modifier = Modifier.fillMaxWidth().testTag("settings_gemini_key_input"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { onSaveApiKey(key.trim()) },
                modifier = Modifier.weight(1f).height(42.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
            ) {
                Text("SAVE KEY", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            OutlinedButton(
                onClick = {
                    isTesting = true
                    testResult = null
                    onTestConnection { res ->
                        isTesting = false
                        testResult = res.fold(
                            onSuccess = { "SUCCESS: $it" },
                            onFailure = { "ERROR: ${it.localizedMessage}" }
                        )
                    }
                },
                modifier = Modifier.weight(1f).height(42.dp).testTag("test_gemini_btn"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricCyanPrimary)
            ) {
                if (isTesting) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = ElectricCyanPrimary, strokeWidth = 2.dp)
                } else {
                    Text("TEST CONNECTION", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        testResult?.let { res ->
            val isSuccess = res.startsWith("SUCCESS")
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isSuccess) SuccessGreen.copy(alpha = 0.15f) else ErrorRed.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSuccess) SuccessGreen else ErrorRed),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = res,
                    color = if (isSuccess) SuccessGreen else ErrorRed,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(10.dp)
                )
            }
        }
    }
}

@Composable
fun NotificationsEditor(
    context: Context,
    settings: NotificationSettings,
    onSave: (NotificationSettings) -> Unit
) {
    var missionReminders by remember { mutableStateOf(settings.missionReminders) }
    var focusComplete by remember { mutableStateOf(settings.focusCompleteNotification) }
    var revisionDue by remember { mutableStateOf(settings.revisionDueNotification) }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Mission Deadlines & Prompts", color = TextPrimary, fontSize = 13.sp)
            Switch(checked = missionReminders, onCheckedChange = {
                missionReminders = it
                onSave(settings.copy(missionReminders = it))
            }, colors = SwitchDefaults.colors(checkedThumbColor = ElectricCyanPrimary))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Focus Session Complete Alert", color = TextPrimary, fontSize = 13.sp)
            Switch(checked = focusComplete, onCheckedChange = {
                focusComplete = it
                onSave(settings.copy(focusCompleteNotification = it))
            }, colors = SwitchDefaults.colors(checkedThumbColor = ElectricCyanPrimary))
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Revision Due Alerts", color = TextPrimary, fontSize = 13.sp)
            Switch(checked = revisionDue, onCheckedChange = {
                revisionDue = it
                onSave(settings.copy(revisionDueNotification = it))
            }, colors = SwitchDefaults.colors(checkedThumbColor = ElectricCyanPrimary))
        }

        Spacer(modifier = Modifier.height(4.dp))

        Button(
            onClick = {
                val sent = NotificationHelper.sendTestNotification(context)
                if (sent) {
                    Toast.makeText(context, "Test notification triggered!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Notifications disabled in system settings.", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth().height(42.dp).testTag("trigger_test_notification"),
            colors = ButtonDefaults.buttonColors(containerColor = DarkSlateCardHover),
            border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyanPrimary)
        ) {
            Icon(Icons.Default.Notifications, contentDescription = null, tint = ElectricCyanPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("TRIGGER REAL NOTIFICATION TEST", color = ElectricCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
    }
}

@Composable
fun DataBackupEditor(
    context: Context,
    onExport: ((String) -> Unit) -> Unit,
    onValidateAndPreview: (String, (Result<BackupPreview>) -> Unit) -> Unit,
    onImport: (String, (Boolean, String?) -> Unit) -> Unit,
    onClearAll: () -> Unit
) {
    var backupJsonToSave by remember { mutableStateOf<String?>(null) }
    var showImportDialog by remember { mutableStateOf(false) }
    var showResetConfirm by remember { mutableStateOf(false) }
    var previewData by remember { mutableStateOf<Pair<BackupPreview, String>?>(null) }

    val createDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        uri?.let { targetUri ->
            backupJsonToSave?.let { json ->
                try {
                    context.contentResolver.openOutputStream(targetUri)?.use { out ->
                        out.write(json.toByteArray(Charsets.UTF_8))
                    }
                    Toast.makeText(context, "Backup exported successfully to file!", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Export error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    val openDocLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { targetUri ->
            try {
                val json = context.contentResolver.openInputStream(targetUri)?.bufferedReader()?.use { it.readText() }
                if (json.isNullOrBlank()) {
                    Toast.makeText(context, "File is empty", Toast.LENGTH_SHORT).show()
                } else {
                    onValidateAndPreview(json) { result ->
                        if (result.isSuccess) {
                            previewData = Pair(result.getOrThrow(), json)
                        } else {
                            val err = result.exceptionOrNull()?.localizedMessage ?: "Invalid backup file"
                            Toast.makeText(context, "Cannot restore: $err", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Read error: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        // Export Row
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    onExport { json ->
                        backupJsonToSave = json
                        val dateTag = SimpleDateFormat("yyyyMMdd_HHmm", Locale.getDefault()).format(Date())
                        createDocLauncher.launch("jee_core_backup_$dateTag.json")
                    }
                },
                modifier = Modifier.weight(1f).height(42.dp).testTag("export_backup_file_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
            ) {
                Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF00363D), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("EXPORT FILE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }

            OutlinedButton(
                onClick = {
                    onExport { json ->
                        backupJsonToSave = json
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("JEE CORE Backup", json))
                        Toast.makeText(context, "Backup JSON copied to clipboard!", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.weight(1f).height(42.dp).testTag("export_backup_clipboard_btn"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricCyanPrimary)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, tint = ElectricCyanPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("COPY JSON", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Import Row
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = {
                    openDocLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
                },
                modifier = Modifier.weight(1f).height(42.dp).testTag("import_backup_file_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = DarkSlateCardHover),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyanPrimary)
            ) {
                Icon(Icons.Default.Upload, contentDescription = null, tint = ElectricCyanPrimary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("OPEN FILE", color = ElectricCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }

            OutlinedButton(
                onClick = { showImportDialog = true },
                modifier = Modifier.weight(1f).height(42.dp).testTag("import_backup_btn"),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = ElectricCyanPrimary)
            ) {
                Text("PASTE JSON", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        backupJsonToSave?.let { json ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = DarkSlateBackground,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("BACKUP READY (COPIED/SAVED):", color = SuccessGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(json.take(160) + if (json.length > 160) "..." else "", color = TextPrimary, fontSize = 10.sp, maxLines = 3)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Button(
            onClick = { showResetConfirm = true },
            modifier = Modifier.fillMaxWidth().height(40.dp).testTag("reset_all_data_btn"),
            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed.copy(alpha = 0.2f)),
            border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed)
        ) {
            Text("RESET & CLEAR ALL APP DATA", color = ErrorRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }

    // Pre-Restore Preview Dialog
    previewData?.let { (preview, json) ->
        val dateFormatted = try {
            SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault()).format(Date(preview.exportedAt))
        } catch (_: Exception) {
            "Unknown"
        }

        Dialog(onDismissRequest = { previewData = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyanPrimary),
                modifier = Modifier.padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("Backup Preview", color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Verify backup contents before applying restore", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSlateBackground,
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, DarkSlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Schema: v${preview.schemaVersion} • App: v${preview.appVersion}", color = ElectricCyanPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Exported: $dateFormatted", color = TextSecondary, fontSize = 11.sp)
                            Text("Target: ${preview.targetExam} (${preview.targetYear})", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("• Missions: ${preview.missionCount}", color = TextPrimary, fontSize = 12.sp)
                            Text("• Focus Sessions: ${preview.focusSessionCount}", color = TextPrimary, fontSize = 12.sp)
                            Text("• Chat Sessions: ${preview.chatCount} (${preview.messageCount} messages)", color = TextPrimary, fontSize = 12.sp)
                            Text("• Daily Work Logs: ${preview.workLogCount}", color = TextPrimary, fontSize = 12.sp)
                            Text("• Test Records: ${preview.testCount}", color = TextPrimary, fontSize = 12.sp)
                            Text("• Syllabus Topics: ${preview.syllabusCount}", color = TextPrimary, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = ErrorRed.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "⚠️ CAUTION: Restoring will overwrite existing missions, test records, chats, and focus sessions. This cannot be undone.",
                            color = ErrorRed,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(10.dp),
                            lineHeight = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { previewData = null }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                onImport(json) { success, err ->
                                    if (success) {
                                        Toast.makeText(context, "Data restored successfully!", Toast.LENGTH_LONG).show()
                                        previewData = null
                                        showImportDialog = false
                                    } else {
                                        Toast.makeText(context, "Restore failed: $err", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                        ) {
                            Text("CONFIRM RESTORE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    // Import Dialog
    if (showImportDialog) {
        var importInput by remember { mutableStateOf("") }
        var importError by remember { mutableStateOf<String?>(null) }

        Dialog(onDismissRequest = { showImportDialog = false }) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Import Backup JSON", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Paste JSON to validate and preview before restoring", color = TextSecondary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = importInput,
                        onValueChange = { importInput = it },
                        label = { Text("Paste JSON string") },
                        modifier = Modifier.fillMaxWidth().height(140.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
                    )
                    importError?.let { err ->
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(err, color = ErrorRed, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showImportDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                if (importInput.isBlank()) {
                                    importError = "Please paste JSON string"
                                } else {
                                    onValidateAndPreview(importInput) { result ->
                                        if (result.isSuccess) {
                                            previewData = Pair(result.getOrThrow(), importInput)
                                            showImportDialog = false
                                            importError = null
                                        } else {
                                            importError = result.exceptionOrNull()?.localizedMessage ?: "Invalid backup JSON"
                                        }
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                        ) {
                            Text("PREVIEW", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Reset Confirm Dialog
    if (showResetConfirm) {
        Dialog(onDismissRequest = { showResetConfirm = false }) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, ErrorRed),
                modifier = Modifier.padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Confirm Factory Reset", color = ErrorRed, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("This will permanently clear all missions, history, tests, and configuration.", color = TextSecondary, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showResetConfirm = false }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                onClearAll()
                                showResetConfirm = false
                                Toast.makeText(context, "All data reset.", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                        ) {
                            Text("RESET ALL", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
