package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PriorityLevel
import com.example.data.model.Subject
import com.example.ui.theme.ChemistryAccent
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MathsAccent
import com.example.ui.theme.PhysicsAccent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber

@Composable
fun SubjectBadge(subject: Subject, modifier: Modifier = Modifier) {
    val (bgColor, textColor) = when (subject) {
        Subject.PHYSICS -> PhysicsAccent.copy(alpha = 0.2f) to PhysicsAccent
        Subject.CHEMISTRY -> ChemistryAccent.copy(alpha = 0.2f) to ChemistryAccent
        Subject.MATHEMATICS -> MathsAccent.copy(alpha = 0.2f) to MathsAccent
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(0.8.dp, textColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(
            text = subject.displayName,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
fun PriorityBadge(priority: PriorityLevel, modifier: Modifier = Modifier) {
    val color = when (priority) {
        PriorityLevel.LOW -> Color(0xFF64748B)
        PriorityLevel.MEDIUM -> Color(0xFF38BDF8)
        PriorityLevel.HIGH -> WarningAmber
        PriorityLevel.URGENT -> ErrorRed
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(color.copy(alpha = 0.15f))
            .border(0.8.dp, color.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
            .padding(horizontal = 7.dp, vertical = 2.dp)
    ) {
        Text(
            text = priority.displayName.uppercase(),
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
