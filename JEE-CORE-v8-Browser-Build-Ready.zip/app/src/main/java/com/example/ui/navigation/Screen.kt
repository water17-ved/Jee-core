package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Assignment
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val selectedIcon: ImageVector, val unselectedIcon: ImageVector) {
    data object Coach : Screen("coach", "COACH", Icons.Filled.Home, Icons.Outlined.Home)
    data object Chat : Screen("chat", "CHAT", Icons.Filled.Chat, Icons.Outlined.Chat)
    data object Mission : Screen("mission", "MISSION", Icons.Filled.Assignment, Icons.Outlined.Assignment)
    data object History : Screen("history", "HISTORY", Icons.Filled.History, Icons.Outlined.History)
    data object Settings : Screen("settings", "SETTINGS", Icons.Filled.Settings, Icons.Outlined.Settings)

    companion object {
        val bottomNavItems: List<Screen>
            get() = listOf(Coach, Chat, Mission, History, Settings)
    }
}
