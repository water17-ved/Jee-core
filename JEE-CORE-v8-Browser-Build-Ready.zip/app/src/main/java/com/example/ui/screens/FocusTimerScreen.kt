package com.example.ui.screens

import android.os.SystemClock
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionEntity
import com.example.data.model.Subject
import com.example.notification.NotificationHelper
import com.example.ui.components.SubjectBadge
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FocusTimerScreen(
    mission: MissionEntity?,
    onNavigateBack: () -> Unit,
    onSessionCompleted: (FocusSessionEntity) -> Unit
) {
    val context = LocalContext.current
    var selectedPresetMinutes by remember { mutableStateOf(mission?.plannedDurationMinutes ?: 45) }
    var totalSeconds by remember { mutableLongStateOf(selectedPresetMinutes * 60L) }
    var remainingSeconds by remember { mutableLongStateOf(totalSeconds) }
    var isRunning by remember { mutableStateOf(false) }
    var endTimestampEpochMs by remember { mutableLongStateOf(0L) }
    var showPostSessionDialog by remember { mutableStateOf(false) }

    var questionsDone by remember { mutableStateOf(mission?.targetQuantity?.toString() ?: "15") }
    var sessionNotes by remember { mutableStateOf("") }
    val startTimeEpochMs = remember { System.currentTimeMillis() }

    // Timestamp-based accurate ticker
    LaunchedEffect(isRunning, endTimestampEpochMs) {
        while (isRunning) {
            val now = System.currentTimeMillis()
            val remaining = ((endTimestampEpochMs - now) / 1000L).coerceAtLeast(0L)
            remainingSeconds = remaining
            if (remaining <= 0) {
                isRunning = false
                NotificationHelper.sendFocusCompleteNotification(
                    context = context,
                    missionTitle = mission?.title ?: "Focus Sprint",
                    durationMinutes = selectedPresetMinutes
                )
                showPostSessionDialog = true
            }
            delay(500)
        }
    }

    val progress = if (totalSeconds > 0) {
        (remainingSeconds.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val minutes = remainingSeconds / 60
    val seconds = remainingSeconds % 60
    val timeFormatted = String.format("%02d:%02d", minutes, seconds)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("FOCUS COMMAND", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSlateBackground,
                    titleContentColor = TextPrimary,
                    navigationIconContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkSlateBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            if (mission != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SubjectBadge(subject = mission.subject)
                    Text(
                        text = mission.chapter,
                        color = TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = mission.title,
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Text(
                    text = "Tactical Problem Solving Block",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Presets
            Text("SELECT DURATION PRESET", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf(25, 45, 60, 90, 120).forEach { mins ->
                    val isSelected = selectedPresetMinutes == mins
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateCard)
                            .border(
                                1.dp,
                                if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                RoundedCornerShape(8.dp)
                            )
                            .clickable(enabled = !isRunning) {
                                selectedPresetMinutes = mins
                                totalSeconds = mins * 60L
                                remainingSeconds = totalSeconds
                            }
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "${mins}m",
                            color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Circular Clock UI
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(260.dp)
            ) {
                CircularProgressIndicator(
                    progress = { 1f },
                    modifier = Modifier.fillMaxSize(),
                    color = DarkSlateBorder,
                    strokeWidth = 10.dp
                )
                CircularProgressIndicator(
                    progress = { progress },
                    modifier = Modifier.fillMaxSize(),
                    color = ElectricCyanPrimary,
                    strokeWidth = 10.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = timeFormatted,
                        fontSize = 54.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = TextPrimary
                    )
                    Text(
                        text = if (isRunning) "ACTIVE EXECUTION" else if (remainingSeconds == 0L) "COMPLETED" else "READY",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isRunning) ElectricCyanPrimary else if (remainingSeconds == 0L) SuccessGreen else TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.height(36.dp))

            // Controls
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Reset / Cancel
                IconButton(
                    onClick = {
                        isRunning = false
                        totalSeconds = selectedPresetMinutes * 60L
                        remainingSeconds = totalSeconds
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(DarkSlateCard)
                        .border(1.dp, DarkSlateBorder, CircleShape)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = TextSecondary)
                }

                // Play / Pause
                Button(
                    onClick = {
                        if (isRunning) {
                            isRunning = false
                        } else {
                            if (remainingSeconds <= 0L) {
                                remainingSeconds = selectedPresetMinutes * 60L
                                totalSeconds = remainingSeconds
                            }
                            endTimestampEpochMs = System.currentTimeMillis() + (remainingSeconds * 1000L)
                            isRunning = true
                        }
                    },
                    modifier = Modifier
                        .height(56.dp)
                        .width(150.dp)
                        .testTag("toggle_timer_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary),
                    shape = RoundedCornerShape(28.dp)
                ) {
                    Icon(
                        imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isRunning) "Pause" else "Start",
                        tint = Color(0xFF00363D)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isRunning) "PAUSE" else "START",
                        color = Color(0xFF00363D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                // Finish Early
                IconButton(
                    onClick = {
                        isRunning = false
                        showPostSessionDialog = true
                    },
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(DarkSlateCard)
                        .border(1.dp, DarkSlateBorder, CircleShape)
                ) {
                    Icon(Icons.Default.Check, contentDescription = "Finish", tint = SuccessGreen)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Post Session Dialog / Card
            AnimatedVisibility(visible = showPostSessionDialog) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = DarkSlateCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyanPrimary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Log Completed Focus Block",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        val actualElapsedMins = ((totalSeconds - remainingSeconds) / 60L).coerceAtLeast(1L).toInt()

                        Text("Actual Time: $actualElapsedMins minutes", color = TextSecondary, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = questionsDone,
                            onValueChange = { questionsDone = it },
                            label = { Text("Questions Solved") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth().testTag("focus_questions_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricCyanPrimary,
                                unfocusedBorderColor = DarkSlateBorder
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = sessionNotes,
                            onValueChange = { sessionNotes = it },
                            label = { Text("Notes / Observations") },
                            placeholder = { Text("Solved 2023 PYQs; revised friction formulas") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricCyanPrimary,
                                unfocusedBorderColor = DarkSlateBorder
                            )
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                val session = FocusSessionEntity(
                                    missionId = mission?.id,
                                    missionTitle = mission?.title,
                                    subject = mission?.subject ?: Subject.PHYSICS,
                                    chapter = mission?.chapter ?: "General Physics",
                                    topic = mission?.topic ?: "Problem Set",
                                    plannedDurationMinutes = selectedPresetMinutes,
                                    actualDurationMinutes = actualElapsedMins,
                                    questionsCompleted = questionsDone.toIntOrNull() ?: 0,
                                    startTimeEpochMs = startTimeEpochMs,
                                    endTimeEpochMs = System.currentTimeMillis(),
                                    notes = sessionNotes
                                )
                                onSessionCompleted(session)
                                onNavigateBack()
                            },
                            modifier = Modifier.fillMaxWidth().testTag("save_focus_session_btn"),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                        ) {
                            Text("SAVE & UPDATE COMMAND CENTER", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
