package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExamType
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionEntity
import com.example.data.model.ScheduleSlot
import com.example.data.model.Subject
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.TopicState
import com.example.data.model.WorkLogEntity
import com.example.report.model.ReportFormat
import com.example.report.model.ReportType
import com.example.ui.components.SubjectBadge
import com.example.ui.dialogs.AddScheduleSlotDialog
import com.example.ui.dialogs.EditTopicDialog
import com.example.ui.theme.ChemistryAccent
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MathsAccent
import com.example.ui.theme.PhysicsAccent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class HistoryRange(val label: String, val days: Int) {
    TODAY("Today", 1),
    WEEK("7 Days", 7),
    MONTH("30 Days", 30),
    ALL("All Time", 365)
}

enum class HistoryViewSection(val label: String) {
    TIMELINE("TIMELINE"),
    SCHEDULE("SCHEDULE"),
    SYLLABUS("SYLLABUS"),
    TESTS("TESTS")
}

@Composable
fun HistoryScreen(
    missions: List<MissionEntity>,
    focusSessions: List<FocusSessionEntity>,
    workLogs: List<WorkLogEntity>,
    syllabusTopics: List<SyllabusTopicEntity>,
    testRecords: List<TestRecordEntity>,
    scheduleSlots: List<ScheduleSlot> = emptyList(),
    onToggleScheduleSlot: (String) -> Unit = {},
    onAddScheduleSlot: (ScheduleSlot) -> Unit = {},
    onDeleteScheduleSlot: (String) -> Unit = {},
    onResetScheduleSlots: () -> Unit = {},
    onStartFocusForSlot: (ScheduleSlot) -> Unit = {},
    onUpdateTopic: (SyllabusTopicEntity) -> Unit = {},
    onOpenRecordTest: () -> Unit,
    onDeleteTest: (TestRecordEntity) -> Unit,
    onRequestReport: (ReportType, ReportFormat, Long?) -> Unit = { _, _, _ -> },
    onRequestHeavyAnalysis: ((String) -> Unit)? = null
) {
    var selectedRange by remember { mutableStateOf(HistoryRange.TODAY) }
    var selectedSection by remember { mutableStateOf(HistoryViewSection.TIMELINE) }

    var editingTopic by remember { mutableStateOf<SyllabusTopicEntity?>(null) }
    var showAddSlotDialog by remember { mutableStateOf(false) }

    val cutoffEpochMs = remember(selectedRange) {
        val cal = Calendar.getInstance()
        if (selectedRange == HistoryRange.TODAY) {
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)
            cal.timeInMillis
        } else {
            System.currentTimeMillis() - (selectedRange.days * 24L * 3600L * 1000L)
        }
    }

    val filteredLogs = remember(workLogs, cutoffEpochMs) {
        workLogs.filter { it.timestampEpochMs >= cutoffEpochMs }
    }

    val totalStudyMinutes = remember(filteredLogs) {
        filteredLogs.sumOf { it.durationMinutes }
    }

    val totalQuestions = remember(filteredLogs) {
        filteredLogs.sumOf { it.questionsAttempted }
    }

    val correctQuestions = remember(filteredLogs) {
        filteredLogs.sumOf { it.questionsCorrect }
    }

    val accuracy = remember(totalQuestions, correctQuestions) {
        if (totalQuestions > 0) (correctQuestions.toFloat() / totalQuestions.toFloat()) * 100f else 0f
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkSlateBackground)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text("TRACKERS & ANALYTICS", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)

        Spacer(modifier = Modifier.height(10.dp))

        // Range Filter Buttons (Only shown for Timeline)
        if (selectedSection == HistoryViewSection.TIMELINE) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                HistoryRange.values().forEach { range ->
                    val isSelected = selectedRange == range
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateCard)
                            .border(1.dp, if (isSelected) ElectricCyanPrimary else DarkSlateBorder, RoundedCornerShape(8.dp))
                            .clickable { selectedRange = range }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(range.label, color = if (isSelected) ElectricCyanPrimary else TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Summary Statistics Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.fillMaxWidth().testTag("history_stats_card")
            ) {
                Row(
                    modifier = Modifier
                        .padding(14.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("STUDY TIME", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("${totalStudyMinutes / 60}h ${totalStudyMinutes % 60}m", color = SuccessGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("QUESTIONS", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("$totalQuestions done", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("ACCURACY", color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(if (totalQuestions > 0) "${accuracy.toInt()}%" else "--", color = ElectricCyanPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }

        // View Selector: Timeline / Schedule / Syllabus / Tests
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HistoryViewSection.values().forEach { sec ->
                val isSelected = selectedSection == sec
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.25f) else DarkSlateCard)
                        .border(1.dp, if (isSelected) ElectricCyanPrimary else DarkSlateBorder, RoundedCornerShape(8.dp))
                        .clickable { selectedSection = sec }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(sec.label, color = if (isSelected) ElectricCyanPrimary else TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Content Section
        when (selectedSection) {
            HistoryViewSection.TIMELINE -> {
                if (filteredLogs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("No logs recorded in this period", color = TextSecondary, fontSize = 13.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredLogs, key = { it.id }) { log ->
                            WorkLogItemCard(log = log)
                        }
                    }
                }
            }
            HistoryViewSection.SCHEDULE -> {
                ScheduleTrackerView(
                    slots = scheduleSlots,
                    onToggleSlot = onToggleScheduleSlot,
                    onOpenAddSlot = { showAddSlotDialog = true },
                    onDeleteSlot = onDeleteScheduleSlot,
                    onResetDefaults = onResetScheduleSlots,
                    onStartFocus = onStartFocusForSlot,
                    modifier = Modifier.weight(1f)
                )
            }
            HistoryViewSection.SYLLABUS -> {
                SyllabusAnalyticsView(
                    syllabusTopics = syllabusTopics,
                    onEditTopic = { topic -> editingTopic = topic },
                    onRequestReport = onRequestReport,
                    modifier = Modifier.weight(1f)
                )
            }
            HistoryViewSection.TESTS -> {
                TestsListView(
                    testRecords = testRecords,
                    onOpenRecordTest = onOpenRecordTest,
                    onDeleteTest = onDeleteTest,
                    onRequestReport = onRequestReport,
                    onRequestHeavyAnalysis = onRequestHeavyAnalysis,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }

    // Dialogs
    editingTopic?.let { topic ->
        EditTopicDialog(
            topic = topic,
            onDismiss = { editingTopic = null },
            onSave = { updated ->
                onUpdateTopic(updated)
                editingTopic = null
            }
        )
    }

    if (showAddSlotDialog) {
        AddScheduleSlotDialog(
            onDismiss = { showAddSlotDialog = false },
            onSave = { slot ->
                onAddScheduleSlot(slot)
                showAddSlotDialog = false
            }
        )
    }
}

@Composable
fun ScheduleTrackerView(
    slots: List<ScheduleSlot>,
    onToggleSlot: (String) -> Unit,
    onOpenAddSlot: () -> Unit,
    onDeleteSlot: (String) -> Unit,
    onResetDefaults: () -> Unit,
    onStartFocus: (ScheduleSlot) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalPlannedMins = remember(slots) { slots.sumOf { it.targetMinutes } }
    val completedMins = remember(slots) { slots.filter { it.isCompleted }.sumOf { it.targetMinutes } }
    val completedSlots = remember(slots) { slots.count { it.isCompleted } }
    val adherencePercent = remember(totalPlannedMins, completedMins) {
        if (totalPlannedMins > 0) ((completedMins.toFloat() / totalPlannedMins.toFloat()) * 100).toInt() else 0
    }

    LazyColumn(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Schedule Adherence Banner
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.fillMaxWidth().testTag("schedule_adherence_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("DAILY SCHEDULE ADHERENCE", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("$adherencePercent%", color = if (adherencePercent >= 70) SuccessGreen else ElectricCyanPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    LinearProgressIndicator(
                        progress = { adherencePercent / 100f },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = if (adherencePercent >= 70) SuccessGreen else ElectricCyanPrimary,
                        trackColor = DarkSlateBorder
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Planned: ${totalPlannedMins / 60}h ${totalPlannedMins % 60}m", color = TextSecondary, fontSize = 12.sp)
                        Text("Done: ${completedMins / 60}h ${completedMins % 60}m", color = SuccessGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Slots: $completedSlots/${slots.size}", color = ElectricCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Action Buttons Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("STUDY TIME BLOCKS", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onResetDefaults,
                        modifier = Modifier.height(32.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset", modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset", fontSize = 11.sp)
                    }

                    Button(
                        onClick = onOpenAddSlot,
                        modifier = Modifier.height(32.dp).testTag("btn_add_schedule_slot"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = Color(0xFF00363D), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Slot", color = Color(0xFF00363D), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (slots.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 30.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No schedule slots created. Tap 'Add Slot' or 'Reset' to load standard JEE routine.", color = TextSecondary, fontSize = 13.sp)
                }
            }
        } else {
            // Group slots by Period
            val grouped = slots.groupBy { it.slotPeriod }
            listOf("Morning", "Afternoon", "Evening", "Night").forEach { period ->
                val periodSlots = grouped[period] ?: emptyList()
                if (periodSlots.isNotEmpty()) {
                    item {
                        Text(
                            period.uppercase(Locale.getDefault()),
                            color = WarningAmber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }

                    items(periodSlots, key = { it.id }) { slot ->
                        ScheduleSlotCard(
                            slot = slot,
                            onToggle = { onToggleSlot(slot.id) },
                            onDelete = { onDeleteSlot(slot.id) },
                            onStartFocus = { onStartFocus(slot) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ScheduleSlotCard(
    slot: ScheduleSlot,
    onToggle: () -> Unit,
    onDelete: () -> Unit,
    onStartFocus: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSlateCard,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (slot.isCompleted) SuccessGreen.copy(alpha = 0.5f) else DarkSlateBorder
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Checkbox button
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (slot.isCompleted) SuccessGreen else Color.Transparent)
                    .border(
                        1.5.dp,
                        if (slot.isCompleted) SuccessGreen else TextSecondary,
                        CircleShape
                    )
                    .clickable { onToggle() },
                contentAlignment = Alignment.Center
            ) {
                if (slot.isCompleted) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = "Completed",
                        tint = Color(0xFF00363D),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        SubjectBadge(subject = slot.subject)
                        Text(
                            slot.title,
                            color = if (slot.isCompleted) TextSecondary else TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(slot.timeRange, color = ElectricCyanPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(slot.chapterOrTask, color = TextSecondary, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${slot.targetMinutes} min", color = TextSecondary, fontSize = 11.sp)
                    if (slot.isCompleted) {
                        Text("COMPLETED", color = SuccessGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Start Focus button & delete icon
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!slot.isCompleted) {
                    IconButton(onClick = onStartFocus, modifier = Modifier.size(32.dp)) {
                        Icon(
                            Icons.Default.PlayArrow,
                            contentDescription = "Start Focus",
                            tint = ElectricCyanPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
                    Icon(
                        Icons.Default.Close,
                        contentDescription = "Delete",
                        tint = TextSecondary.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun WorkLogItemCard(log: WorkLogEntity) {
    val dateStr = remember(log.timestampEpochMs) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(log.timestampEpochMs))
    }

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = DarkSlateCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    SubjectBadge(subject = log.subject)
                    Text(log.chapter, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Text(dateStr, color = TextSecondary, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(log.whatDidYouDo, color = TextSecondary, fontSize = 12.sp)

            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("${log.durationMinutes} min", color = ElectricCyanPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Text("${log.questionsAttempted} PYQs (${log.questionsCorrect} correct)", color = SuccessGreen, fontSize = 11.sp)
            }

            if (log.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text("Note: ${log.notes}", color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun SyllabusAnalyticsView(
    syllabusTopics: List<SyllabusTopicEntity>,
    onEditTopic: (SyllabusTopicEntity) -> Unit,
    onRequestReport: (ReportType, ReportFormat, Long?) -> Unit = { _, _, _ -> },
    modifier: Modifier = Modifier
) {
    var selectedSubjectFilter by remember { mutableStateOf<Subject?>(null) }
    var selectedStateFilter by remember { mutableStateOf<TopicState?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val physicsTopics = remember(syllabusTopics) { syllabusTopics.filter { it.subject == Subject.PHYSICS } }
    val chemTopics = remember(syllabusTopics) { syllabusTopics.filter { it.subject == Subject.CHEMISTRY } }
    val mathTopics = remember(syllabusTopics) { syllabusTopics.filter { it.subject == Subject.MATHEMATICS } }

    val pMastery = remember(physicsTopics) {
        if (physicsTopics.isNotEmpty()) (physicsTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE } * 100) / physicsTopics.size else 0
    }
    val cMastery = remember(chemTopics) {
        if (chemTopics.isNotEmpty()) (chemTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE } * 100) / chemTopics.size else 0
    }
    val mMastery = remember(mathTopics) {
        if (mathTopics.isNotEmpty()) (mathTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE } * 100) / mathTopics.size else 0
    }

    val overallMastery = remember(syllabusTopics) {
        if (syllabusTopics.isNotEmpty()) (syllabusTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE } * 100) / syllabusTopics.size else 0
    }

    val filteredTopics = remember(syllabusTopics, selectedSubjectFilter, selectedStateFilter, searchQuery) {
        syllabusTopics.filter { topic ->
            val matchSubject = selectedSubjectFilter == null || topic.subject == selectedSubjectFilter
            val matchState = selectedStateFilter == null || topic.state == selectedStateFilter
            val matchQuery = searchQuery.isBlank() ||
                    topic.topicName.contains(searchQuery, ignoreCase = true) ||
                    topic.chapter.contains(searchQuery, ignoreCase = true)
            matchSubject && matchState && matchQuery
        }
    }

    LazyColumn(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Master Progress Card
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.fillMaxWidth().testTag("syllabus_mastery_card")
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SYLLABUS MASTERY", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("$overallMastery% OVERALL", color = ElectricCyanPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }

                    SubjectProgressRow("Physics", pMastery, PhysicsAccent, physicsTopics.size)
                    SubjectProgressRow("Chemistry", cMastery, ChemistryAccent, chemTopics.size)
                    SubjectProgressRow("Mathematics", mMastery, MathsAccent, mathTopics.size)

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onRequestReport(ReportType.SYLLABUS_MASTERY, ReportFormat.PDF, null) },
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, DarkSlateBorder),
                            modifier = Modifier.weight(1f).height(32.dp).testTag("btn_export_syllabus_pdf")
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, tint = ElectricCyanPrimary, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export PDF", color = TextPrimary, fontSize = 10.sp)
                        }

                        OutlinedButton(
                            onClick = { onRequestReport(ReportType.SYLLABUS_MASTERY, ReportFormat.XLSX, null) },
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, DarkSlateBorder),
                            modifier = Modifier.weight(1f).height(32.dp).testTag("btn_export_syllabus_excel")
                        ) {
                            Icon(Icons.Default.TableChart, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export Excel", color = TextPrimary, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // Quick Topic Counts Summary
        item {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    val strongCount = syllabusTopics.count { it.state == TopicState.STRONG }
                    val learningCount = syllabusTopics.count { it.state == TopicState.LEARNING }
                    val weakCount = syllabusTopics.count { it.isWeakArea || it.state == TopicState.WEAK || it.state == TopicState.NEEDS_REVISION }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TOTAL", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("${syllabusTopics.size}", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("STRONG", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("$strongCount", color = SuccessGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("LEARNING", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("$learningCount", color = ElectricCyanPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("WEAK / REV", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        Text("$weakCount", color = WarningAmber, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search chapter or topic...", color = TextSecondary, fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextSecondary, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotBlank()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricCyanPrimary,
                    unfocusedBorderColor = DarkSlateBorder,
                    focusedContainerColor = DarkSlateCard,
                    unfocusedContainerColor = DarkSlateCard
                ),
                singleLine = true
            )
        }

        // Subject Filter Tabs
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val subjects = listOf<Subject?>(null, Subject.PHYSICS, Subject.CHEMISTRY, Subject.MATHEMATICS)
                subjects.forEach { sub ->
                    val isSelected = selectedSubjectFilter == sub
                    val label = sub?.displayName?.take(4) ?: "ALL"
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateCard)
                            .border(1.dp, if (isSelected) ElectricCyanPrimary else DarkSlateBorder, RoundedCornerShape(8.dp))
                            .clickable { selectedSubjectFilter = sub }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Filter by state row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf<TopicState?>(null, TopicState.STRONG, TopicState.LEARNING, TopicState.NEEDS_REVISION, TopicState.WEAK).forEach { st ->
                    val isSelected = selectedStateFilter == st
                    val label = when (st) {
                        null -> "All States"
                        TopicState.STRONG -> "Strong"
                        TopicState.LEARNING -> "Learning"
                        TopicState.NEEDS_REVISION -> "Revision"
                        TopicState.WEAK -> "Weak"
                        else -> st.displayName
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) WarningAmber.copy(alpha = 0.2f) else DarkSlateCard)
                            .border(1.dp, if (isSelected) WarningAmber else DarkSlateBorder, RoundedCornerShape(6.dp))
                            .clickable { selectedStateFilter = st }
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            label,
                            color = if (isSelected) WarningAmber else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Group topics by chapter
        val chaptersGrouped = filteredTopics.groupBy { it.chapter }
        if (chaptersGrouped.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No topics match the selected filters", color = TextSecondary, fontSize = 12.sp)
                }
            }
        } else {
            chaptersGrouped.forEach { (chapterName, topicList) ->
                val chSub = topicList.firstOrNull()?.subject ?: Subject.PHYSICS
                val chMastered = topicList.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE }
                val chPercent = if (topicList.isNotEmpty()) (chMastered * 100) / topicList.size else 0

                item {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = DarkSlateCard,
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    SubjectBadge(subject = chSub)
                                    Text(chapterName, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                                Text("$chMastered/${topicList.size} ($chPercent%)", color = ElectricCyanPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                topicList.forEach { topic ->
                                    SyllabusTopicRow(
                                        topic = topic,
                                        onEdit = { onEditTopic(topic) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SyllabusTopicRow(
    topic: SyllabusTopicEntity,
    onEdit: () -> Unit
) {
    val stateColor = when (topic.state) {
        TopicState.STRONG -> SuccessGreen
        TopicState.COMPLETED_ONCE -> Color(0xFF14B8A6)
        TopicState.LEARNING -> ElectricCyanPrimary
        TopicState.NEEDS_REVISION -> WarningAmber
        TopicState.WEAK -> ErrorRed
        TopicState.NOT_STARTED -> TextSecondary
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(DarkSlateBackground.copy(alpha = 0.6f))
            .border(0.5.dp, DarkSlateBorder, RoundedCornerShape(6.dp))
            .clickable { onEdit() }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(topic.topicName, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                if (topic.isWeakArea) {
                    Icon(Icons.Default.Warning, contentDescription = "Weak", tint = WarningAmber, modifier = Modifier.size(12.dp))
                }
            }
            Text(
                "${topic.confidenceScore}% conf • ${topic.pyqsCorrect}/${topic.pyqsAttempted} PYQs",
                color = TextSecondary,
                fontSize = 10.sp
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(stateColor.copy(alpha = 0.2f))
                    .border(0.5.dp, stateColor, RoundedCornerShape(4.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(topic.state.displayName, color = stateColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }

            IconButton(onClick = onEdit, modifier = Modifier.size(22.dp)) {
                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(12.dp))
            }
        }
    }
}

@Composable
fun SubjectProgressRow(name: String, percent: Int, color: Color, topicCount: Int) {
    Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("$name ($topicCount topics)", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("$percent%", color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { percent / 100f },
            modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = DarkSlateBorder
        )
    }
}

@Composable
fun TestsListView(
    testRecords: List<TestRecordEntity>,
    onOpenRecordTest: () -> Unit,
    onDeleteTest: (TestRecordEntity) -> Unit,
    onRequestReport: (ReportType, ReportFormat, Long?) -> Unit = { _, _, _ -> },
    onRequestHeavyAnalysis: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var selectedExamFilter by remember { mutableStateOf<ExamType?>(null) }

    val filteredTests = remember(testRecords, selectedExamFilter) {
        if (selectedExamFilter == null) testRecords else testRecords.filter { it.examType == selectedExamFilter }
    }

    val avgScore = remember(testRecords) {
        if (testRecords.isNotEmpty()) testRecords.map { it.userScore }.average().toInt() else 0
    }

    val maxScore = remember(testRecords) {
        testRecords.maxOfOrNull { it.userScore } ?: 0
    }

    val avgAccuracy = remember(testRecords) {
        if (testRecords.isNotEmpty()) testRecords.map { it.accuracy }.average().toFloat() else 0f
    }

    val pAvg = remember(testRecords) {
        if (testRecords.isNotEmpty()) testRecords.map { it.physicsScore }.average().toInt() else 0
    }
    val cAvg = remember(testRecords) {
        if (testRecords.isNotEmpty()) testRecords.map { it.chemistryScore }.average().toInt() else 0
    }
    val mAvg = remember(testRecords) {
        if (testRecords.isNotEmpty()) testRecords.map { it.mathsScore }.average().toInt() else 0
    }

    // Estimated percentile
    val estimatedPercentile = remember(avgScore) {
        when {
            avgScore >= 240 -> "99.8%ile"
            avgScore >= 200 -> "99.2%ile"
            avgScore >= 180 -> "98.7%ile"
            avgScore >= 150 -> "97.1%ile"
            avgScore >= 120 -> "94.5%ile"
            avgScore >= 100 -> "91.0%ile"
            avgScore > 0 -> "85.0%ile"
            else -> "--"
        }
    }

    val totalConceptErrors = remember(testRecords) { testRecords.sumOf { it.conceptualErrors } }
    val totalCalcErrors = remember(testRecords) { testRecords.sumOf { it.calculationErrors } }
    val totalSillyErrors = remember(testRecords) { testRecords.sumOf { it.sillyMistakes } }
    val totalTimeErrors = remember(testRecords) { testRecords.sumOf { it.timePressureErrors } }

    LazyColumn(modifier = modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Top Test Benchmark Card
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.fillMaxWidth().testTag("test_benchmark_card")
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TEST PERFORMANCE BENCHMARKS", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(SuccessGreen.copy(alpha = 0.2f))
                                .border(0.5.dp, SuccessGreen, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Est: $estimatedPercentile", color = SuccessGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("AVG SCORE", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("$avgScore / 300", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("PEAK SCORE", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("$maxScore / 300", color = ElectricCyanPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("ACCURACY", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text(if (testRecords.isNotEmpty()) "${avgAccuracy.toInt()}%" else "--", color = SuccessGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                        Column {
                            Text("TESTS", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("${testRecords.size} taken", color = TextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Subject Averages: P: $pAvg | C: $cAvg | M: $mAvg", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }

        // Mistake Diagnostics Row
        if (testRecords.isNotEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSlateCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("CONCEPT", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("$totalConceptErrors", color = ErrorRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("CALCULATION", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("$totalCalcErrors", color = WarningAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("SILLY", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("$totalSillyErrors", color = WarningAmber, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("TIME/RUSH", color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("$totalTimeErrors", color = ElectricCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Action Bar + Filter
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf<ExamType?>(null, ExamType.JEE_MAIN, ExamType.JEE_ADVANCED).forEach { et ->
                        val isSelected = selectedExamFilter == et
                        val label = when (et) {
                            null -> "All"
                            ExamType.JEE_MAIN -> "Main"
                            ExamType.JEE_ADVANCED -> "Adv"
                            else -> et.displayName
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateCard)
                                .border(1.dp, if (isSelected) ElectricCyanPrimary else DarkSlateBorder, RoundedCornerShape(6.dp))
                                .clickable { selectedExamFilter = et }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, color = if (isSelected) ElectricCyanPrimary else TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Button(
                    onClick = onOpenRecordTest,
                    modifier = Modifier.height(34.dp).testTag("btn_add_test_record"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("+ Record Test", color = Color(0xFF00363D), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Export Actions Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { onRequestReport(ReportType.MULTI_TEST_SUMMARY, ReportFormat.PDF, null) },
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(0.8.dp, DarkSlateBorder),
                    modifier = Modifier.weight(1f).height(32.dp).testTag("btn_export_tests_pdf")
                ) {
                    Icon(Icons.Default.Description, contentDescription = null, tint = ElectricCyanPrimary, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("PDF Report", color = TextPrimary, fontSize = 10.sp)
                }

                OutlinedButton(
                    onClick = { onRequestReport(ReportType.MULTI_TEST_SUMMARY, ReportFormat.XLSX, null) },
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(0.8.dp, DarkSlateBorder),
                    modifier = Modifier.weight(1f).height(32.dp).testTag("btn_export_tests_excel")
                ) {
                    Icon(Icons.Default.TableChart, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Excel Export", color = TextPrimary, fontSize = 10.sp)
                }

                if (onRequestHeavyAnalysis != null) {
                    OutlinedButton(
                        onClick = { onRequestHeavyAnalysis("JEE_Mock_Performance_Audit.pdf") },
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, ElectricCyanPrimary),
                        modifier = Modifier.weight(1f).height(32.dp).testTag("btn_export_tests_audit")
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null, tint = ElectricCyanPrimary, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Deep Audit", color = ElectricCyanPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (filteredTests.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(vertical = 30.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "No test records yet. Add your mock test scores to unlock Coach test diagnostics.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            items(filteredTests, key = { it.id }) { test ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSlateCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Column {
                                Text(test.testName, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text(test.examType.displayName, color = ElectricCyanPrimary, fontSize = 11.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { onRequestReport(ReportType.TEST_ANALYSIS, ReportFormat.PDF, test.id) },
                                    modifier = Modifier.size(28.dp).testTag("btn_export_test_${test.id}")
                                ) {
                                    Icon(Icons.Default.Description, contentDescription = "Export Test Analysis PDF", tint = ElectricCyanPrimary, modifier = Modifier.size(16.dp))
                                }
                                IconButton(onClick = { onDeleteTest(test) }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Score: ${test.userScore}/${test.totalMarks}", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Accuracy: ${test.accuracy.toInt()}%", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text("P: ${test.physicsScore} | C: ${test.chemistryScore} | M: ${test.mathsScore}", color = TextSecondary, fontSize = 12.sp)

                        if (test.conceptualErrors > 0 || test.calculationErrors > 0 || test.sillyMistakes > 0) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                "Errors: ${test.conceptualErrors} concept, ${test.calculationErrors} calc, ${test.sillyMistakes} silly",
                                color = WarningAmber,
                                fontSize = 11.sp
                            )
                        }

                        if (test.weakChaptersIdentified.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Identified: ${test.weakChaptersIdentified}", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
