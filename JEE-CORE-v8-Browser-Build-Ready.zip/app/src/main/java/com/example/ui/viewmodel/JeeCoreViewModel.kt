package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.JeeCoreApp
import com.example.ai.AIMode
import com.example.ai.AIProgressStage
import com.example.ai.CoachEngine
import com.example.ai.CoachExecutionState
import com.example.ai.GeminiContent
import com.example.ai.GeminiPart
import com.example.ai.GeminiService
import com.example.data.model.AIBehaviour
import com.example.data.model.BackupPreview
import com.example.data.model.ChatEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.FocusSessionEntity
import com.example.data.model.JeeMemory
import com.example.data.model.MissionCreator
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.NotificationSettings
import com.example.data.model.PriorityLevel
import com.example.data.model.ScheduleSlot
import com.example.data.model.Subject
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.TopicState
import com.example.data.model.UserProfile
import com.example.data.model.WorkLogEntity
import com.example.report.AnalysisProgressEngine
import com.example.report.ReportIntentParser
import com.example.report.ReportManager
import com.example.report.model.AnalysisPhase
import com.example.report.model.AnalysisProgressState
import com.example.report.model.GeneratedReportFile
import com.example.report.model.ReportFormat
import com.example.report.model.ReportProgress
import com.example.report.model.ReportType
import com.example.widget.JeeWidgetUpdater
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class JeeCoreViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as JeeCoreApp).repository
    private val preferences = repository.preferencesManager

    val userProfile: StateFlow<UserProfile> = preferences.userProfile
    val aiBehaviour: StateFlow<AIBehaviour> = preferences.aiBehaviour
    val jeeMemory: StateFlow<JeeMemory> = preferences.jeeMemory
    val notificationSettings: StateFlow<NotificationSettings> = preferences.notificationSettings
    val customApiKey: StateFlow<String> = preferences.customGeminiKey
    val scheduleSlots: StateFlow<List<ScheduleSlot>> = preferences.scheduleSlots

    val missions: StateFlow<List<MissionEntity>> = repository.allMissions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val focusSessions: StateFlow<List<FocusSessionEntity>> = repository.allFocusSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workLogs: StateFlow<List<WorkLogEntity>> = repository.allWorkLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val syllabusTopics: StateFlow<List<SyllabusTopicEntity>> = repository.allSyllabusTopics
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val testRecords: StateFlow<List<TestRecordEntity>> = repository.allTests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chats: StateFlow<List<ChatEntity>> = repository.allChats
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeChatId = MutableStateFlow<Long?>(null)
    val activeChatId: StateFlow<Long?> = _activeChatId.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessageEntity>> = _chatMessages.asStateFlow()

    private val _aiProgressStage = MutableStateFlow<AIProgressStage>(AIProgressStage.Idle)
    val aiProgressStage: StateFlow<AIProgressStage> = _aiProgressStage.asStateFlow()

    private val reportManager = ReportManager(application)
    private val _reportProgress = MutableStateFlow<ReportProgress?>(null)
    val reportProgress: StateFlow<ReportProgress?> = _reportProgress.asStateFlow()

    private val analysisEngine = AnalysisProgressEngine(application)
    private val _analysisProgressState = MutableStateFlow<AnalysisProgressState?>(null)
    val analysisProgressState: StateFlow<AnalysisProgressState?> = _analysisProgressState.asStateFlow()

    private var activeAnalysisJob: Job? = null

    fun dismissReportProgress() {
        _reportProgress.value = null
    }

    fun startHeavyAnalysis(
        fileName: String = "JEE_Mock_Analysis.pdf",
        fileSizeBytes: Long = 3_450_000L,
        reportType: ReportType = ReportType.COMPLETE_PERFORMANCE,
        format: ReportFormat = ReportFormat.PDF,
        specificTestId: Long? = null,
        onComplete: ((GeneratedReportFile) -> Unit)? = null
    ) {
        activeAnalysisJob?.cancel()
        activeAnalysisJob = viewModelScope.launch {
            analysisEngine.runHeavyAnalysisPipeline(
                fileName = fileName,
                fileSizeBytes = fileSizeBytes,
                reportType = reportType,
                format = format,
                userProfile = userProfile.value,
                tests = testRecords.value,
                syllabusTopics = syllabusTopics.value,
                missions = missions.value,
                focusSessions = focusSessions.value,
                workLogs = workLogs.value,
                scheduleSlots = scheduleSlots.value,
                specificTestId = specificTestId
            ).collect { state ->
                _analysisProgressState.value = state
                if (state.isCompleted && state.resultSummary?.generatedReportFile != null) {
                    onComplete?.invoke(state.resultSummary.generatedReportFile)
                }
            }
        }
    }

    fun cancelHeavyAnalysis() {
        activeAnalysisJob?.cancel()
        activeAnalysisJob = null
        _analysisProgressState.value = _analysisProgressState.value?.copy(
            isCancelled = true,
            currentPhase = AnalysisPhase.FAILED,
            errorMessage = "Analysis was manually cancelled.",
            currentSubtaskHeadline = "Analysis cancelled by user."
        )
    }

    fun minimizeHeavyAnalysis() {
        _analysisProgressState.value = _analysisProgressState.value?.copy(isMinimized = true)
    }

    fun restoreHeavyAnalysis() {
        _analysisProgressState.value = _analysisProgressState.value?.copy(isMinimized = false)
    }

    fun dismissHeavyAnalysis() {
        _analysisProgressState.value = null
        activeAnalysisJob?.cancel()
        activeAnalysisJob = null
    }

    fun retryHeavyAnalysis() {
        val current = _analysisProgressState.value
        val fileName = current?.sourceFileName ?: "JEE_Mock_Analysis.pdf"
        startHeavyAnalysis(fileName = fileName)
    }

    fun openReport(reportFile: GeneratedReportFile) {
        reportManager.openReport(reportFile)
    }

    fun shareReport(reportFile: GeneratedReportFile) {
        reportManager.shareReport(reportFile)
    }

    fun generateReport(
        reportType: ReportType,
        format: ReportFormat,
        specificTestId: Long? = null,
        onComplete: ((GeneratedReportFile) -> Unit)? = null
    ) {
        viewModelScope.launch {
            reportManager.generateReportFlow(
                reportType = reportType,
                format = format,
                userProfile = userProfile.value,
                tests = testRecords.value,
                syllabusTopics = syllabusTopics.value,
                missions = missions.value,
                focusSessions = focusSessions.value,
                workLogs = workLogs.value,
                scheduleSlots = scheduleSlots.value,
                specificTestId = specificTestId
            ).collect { prog ->
                _reportProgress.value = prog
                if (prog.isFinished && prog.generatedFile != null) {
                    onComplete?.invoke(prog.generatedFile)
                }
            }
        }
    }

    fun requestReportFormatFromChat(reportType: ReportType, targetFormat: ReportFormat) {
        val prompt = "Create ${reportType.displayName} in ${targetFormat.displayName}"
        sendChatMessage(prompt)
    }

    private var activeGenerationJob: Job? = null

    fun cancelGeneration() {
        activeGenerationJob?.cancel()
        activeGenerationJob = null
        _aiProgressStage.value = AIProgressStage.Idle
    }

    // Deterministic factual Coach state engine
    val coachState: StateFlow<CoachExecutionState> = combine(
        combine(userProfile, missions, focusSessions) { profile, mList, fList ->
            Triple(profile, mList, fList)
        },
        combine(workLogs, syllabusTopics, testRecords) { wList, sList, tList ->
            Triple(wList, sList, tList)
        }
    ) { (profile, mList, fList), (wList, sList, tList) ->
        CoachEngine.computeCoachState(profile, mList, fList, wList, sList, tList)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        CoachExecutionState(
            plannedMinutes = 0,
            completedMinutes = 0,
            remainingMinutes = 0,
            progressPercent = 0,
            questionsCompletedToday = 0,
            accuracyToday = 0f,
            nowMission = null,
            whyThisExplanation = "Loading command center...",
            nextMission = null,
            afterThatMission = null
        )
    )

    private val geminiService = GeminiService {
        preferences.customGeminiKey.value
    }

    fun saveUserProfile(profile: UserProfile) {
        preferences.saveUserProfile(profile)
    }

    fun saveAIBehaviour(behaviour: AIBehaviour) {
        preferences.saveAIBehaviour(behaviour)
    }

    fun saveJeeMemory(memory: JeeMemory) {
        preferences.saveJeeMemory(memory)
    }

    fun saveNotificationSettings(settings: NotificationSettings) {
        preferences.saveNotificationSettings(settings)
    }

    fun saveCustomApiKey(key: String) {
        preferences.saveCustomGeminiKey(key)
    }

    fun testGeminiConnection(onResult: (Result<String>) -> Unit) {
        viewModelScope.launch {
            val res = geminiService.testConnection()
            onResult(res)
        }
    }

    fun createMission(mission: MissionEntity) {
        viewModelScope.launch {
            repository.insertMission(mission)
        }
    }

    fun updateMission(mission: MissionEntity) {
        viewModelScope.launch {
            repository.updateMission(mission)
        }
    }

    fun deleteMission(mission: MissionEntity) {
        viewModelScope.launch {
            repository.deleteMission(mission)
        }
    }

    fun recordFocusSession(session: FocusSessionEntity) {
        viewModelScope.launch {
            repository.recordFocusSession(session)
            // Also create a work log entry for history
            repository.logWork(
                WorkLogEntity(
                    subject = session.subject,
                    chapter = session.chapter,
                    topic = session.topic,
                    whatDidYouDo = "Focus Session (${session.actualDurationMinutes}m)",
                    durationMinutes = session.actualDurationMinutes,
                    questionsAttempted = session.questionsCompleted,
                    questionsCorrect = session.questionsCompleted,
                    questionsIncorrect = 0,
                    notes = session.notes,
                    linkedMissionId = session.missionId
                )
            )
            JeeWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun logWork(log: WorkLogEntity) {
        viewModelScope.launch {
            repository.logWork(log)
            // Update topic stats in syllabus
            val existing = syllabusTopics.value.find {
                it.chapter.equals(log.chapter, ignoreCase = true) || it.topicName.equals(log.topic, ignoreCase = true)
            }
            if (existing != null) {
                val newAttempted = existing.pyqsAttempted + log.questionsAttempted
                val newCorrect = existing.pyqsCorrect + log.questionsCorrect
                val newAccuracy = if (newAttempted > 0) ((newCorrect.toFloat() / newAttempted) * 100).toInt() else existing.testAccuracyPercent
                val newState = if (newAccuracy >= 75) TopicState.STRONG else if (newAccuracy < 50) TopicState.WEAK else TopicState.LEARNING

                repository.updateTopic(
                    existing.copy(
                        pyqsAttempted = newAttempted,
                        pyqsCorrect = newCorrect,
                        testAccuracyPercent = newAccuracy,
                        lastStudiedEpochMs = System.currentTimeMillis(),
                        state = newState
                    )
                )
            }
            JeeWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun recordTest(test: TestRecordEntity) {
        viewModelScope.launch {
            repository.recordTest(test)
            // If weak chapters identified, update syllabus isWeakArea
            if (test.weakChaptersIdentified.isNotBlank()) {
                val weakNames = test.weakChaptersIdentified.split(",").map { it.trim() }
                syllabusTopics.value.filter { topic ->
                    weakNames.any { it.equals(topic.chapter, ignoreCase = true) }
                }.forEach { topic ->
                    repository.updateTopic(topic.copy(isWeakArea = true, state = TopicState.WEAK))
                }
            }
            JeeWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun deleteTest(test: TestRecordEntity) {
        viewModelScope.launch {
            repository.deleteTest(test)
            JeeWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    fun updateTopic(topic: SyllabusTopicEntity) {
        viewModelScope.launch {
            repository.updateTopic(topic)
            JeeWidgetUpdater.updateAllWidgets(getApplication())
        }
    }

    // Schedule Slot operations
    fun toggleScheduleSlot(slotId: String) {
        preferences.toggleScheduleSlot(slotId)
    }

    fun addScheduleSlot(slot: ScheduleSlot) {
        preferences.addScheduleSlot(slot)
    }

    fun deleteScheduleSlot(slotId: String) {
        preferences.deleteScheduleSlot(slotId)
    }

    fun resetScheduleSlots() {
        preferences.resetScheduleSlotsToDefaults()
    }

    // Chat operations
    fun selectChat(chatId: Long) {
        _activeChatId.value = chatId
        viewModelScope.launch {
            repository.getMessagesForChat(chatId).collect { msgs ->
                _chatMessages.value = msgs
            }
        }
    }

    fun createChat(title: String, initialPrompt: String? = null, onCreated: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.createChat(title)
            selectChat(id)
            onCreated(id)
            if (!initialPrompt.isNullOrBlank()) {
                sendChatMessage(initialPrompt)
            }
        }
    }

    fun renameChat(chatId: Long, newTitle: String) {
        viewModelScope.launch {
            repository.renameChat(chatId, newTitle)
        }
    }

    fun deleteChat(chatId: Long) {
        viewModelScope.launch {
            repository.deleteChat(chatId)
            if (_activeChatId.value == chatId) {
                _activeChatId.value = null
                _chatMessages.value = emptyList()
            }
        }
    }

    fun sendChatMessage(
        prompt: String,
        aiMode: AIMode = AIMode.AUTO,
        attachmentName: String? = null,
        attachmentUri: String? = null,
        attachmentText: String? = null,
        attachmentBase64: String? = null,
        attachmentMimeType: String? = null
    ) {
        val chatId = _activeChatId.value ?: return
        if (prompt.isBlank() && attachmentText.isNullOrBlank() && attachmentBase64.isNullOrBlank()) return

        activeGenerationJob?.cancel()
        activeGenerationJob = viewModelScope.launch {
            // Check if user is requesting document/report generation
            val reportRequest = ReportIntentParser.parse(prompt)

            // Save user message
            val userMsg = ChatMessageEntity(
                chatId = chatId,
                role = "user",
                content = prompt.trim(),
                aiMode = aiMode.name,
                attachmentName = attachmentName,
                attachmentUri = attachmentUri
            )
            repository.insertChatMessage(userMsg)

            // Insert initial model placeholder message
            val initialModelMsg = ChatMessageEntity(
                chatId = chatId,
                role = "model",
                content = "",
                aiMode = aiMode.name,
                isError = false
            )
            val modelMsgId = repository.insertChatMessage(initialModelMsg)

            if (reportRequest != null) {
                try {
                    reportManager.generateReportFlow(
                        reportType = reportRequest.reportType,
                        format = reportRequest.format,
                        userProfile = userProfile.value,
                        tests = testRecords.value,
                        syllabusTopics = syllabusTopics.value,
                        missions = missions.value,
                        focusSessions = focusSessions.value,
                        workLogs = workLogs.value,
                        scheduleSlots = scheduleSlots.value,
                        specificTestId = reportRequest.specificTestId
                    ).collect { progress ->
                        if (!progress.isFinished) {
                            repository.updateChatMessage(
                                initialModelMsg.copy(
                                    id = modelMsgId,
                                    content = "Generating **${reportRequest.reportType.displayName}** (${reportRequest.format.displayName})...\n\n*${progress.stageDescription} (${progress.percentage}%)*"
                                )
                            )
                        } else if (progress.generatedFile != null) {
                            val file = progress.generatedFile
                            val countUnit = if (file.format == ReportFormat.PDF) "pages" else "worksheets"
                            val sizeKb = (file.sizeBytes / 1024).coerceAtLeast(1)

                            val contentText = "### 📄 ${file.title}\n\n" +
                                    "Your official document has been compiled directly from verified local records.\n\n" +
                                    "• **Format**: ${file.format.displayName} (${file.pageOrSheetCount} $countUnit, $sizeKb KB)\n" +
                                    "• **Analysis Scope**: ${reportRequest.reportType.description}\n" +
                                    "• **Target**: ${userProfile.value.targetExam.displayName} ${userProfile.value.targetYear} • AIR ${userProfile.value.targetRank.ifBlank { "Top 5000" }}\n\n" +
                                    "Use the card below to open, share, or save the file to your device."

                            val reportTypeTag = "report:${file.format.name}:${file.reportType.name}:${file.pageOrSheetCount}:${file.sizeBytes}"
                            repository.updateChatMessage(
                                initialModelMsg.copy(
                                    id = modelMsgId,
                                    content = contentText,
                                    attachmentUri = file.uri.toString(),
                                    attachmentName = file.filename,
                                    attachmentType = reportTypeTag,
                                    isError = false
                                )
                            )
                        }
                    }
                } catch (e: Exception) {
                    repository.updateChatMessage(
                        initialModelMsg.copy(
                            id = modelMsgId,
                            content = "⚠️ Failed to generate report: ${e.localizedMessage}",
                            isError = true
                        )
                    )
                }
                return@launch
            }

            // Compile verified facts context
            val factsContext = CoachEngine.generateFactsContext(
                userProfile.value,
                missions.value,
                focusSessions.value,
                workLogs.value,
                syllabusTopics.value,
                testRecords.value
            )

            // Prepare history contents for multi-turn (excluding the newly inserted placeholder)
            val history = _chatMessages.value
                .filter { it.id != modelMsgId && it.content.isNotBlank() }
                .takeLast(8)
                .map {
                    GeminiContent(
                        role = if (it.role == "user") "user" else "model",
                        parts = listOf(GeminiPart(text = it.content))
                    )
                }

            var accumulatedText = ""
            var hasReceivedChunk = false

            try {
                geminiService.streamCoachResponse(
                    prompt = prompt,
                    userProfile = userProfile.value,
                    jeeMemory = jeeMemory.value,
                    aiBehaviour = aiBehaviour.value,
                    recentFactsContext = factsContext,
                    aiMode = aiMode,
                    attachmentText = attachmentText,
                    attachmentBase64 = attachmentBase64,
                    attachmentMimeType = attachmentMimeType,
                    conversationHistory = history,
                    onProgress = { stage ->
                        _aiProgressStage.value = stage
                    }
                ).collect { chunk ->
                    accumulatedText += chunk
                    hasReceivedChunk = true
                    repository.updateChatMessage(
                        initialModelMsg.copy(
                            id = modelMsgId,
                            content = accumulatedText
                        )
                    )
                }

                if (!hasReceivedChunk || accumulatedText.isBlank()) {
                    repository.updateChatMessage(
                        initialModelMsg.copy(
                            id = modelMsgId,
                            content = "I didn't receive content for this query. Please try again.",
                            isError = true
                        )
                    )
                }
            } catch (e: CancellationException) {
                repository.updateChatMessage(
                    initialModelMsg.copy(
                        id = modelMsgId,
                        content = if (accumulatedText.isNotBlank()) accumulatedText else "[Response generation cancelled]",
                        isError = false
                    )
                )
            } catch (e: Exception) {
                val errorMsg = e.localizedMessage ?: "AI unavailable offline or key missing."
                repository.updateChatMessage(
                    initialModelMsg.copy(
                        id = modelMsgId,
                        content = if (accumulatedText.isNotBlank()) accumulatedText else "⚠️ $errorMsg\n\nTap Retry or check your Gemini configuration in Settings.",
                        isError = true
                    )
                )
            } finally {
                _aiProgressStage.value = AIProgressStage.Idle
            }
        }
    }

    fun deleteChatMessage(messageId: Long) {
        viewModelScope.launch {
            repository.deleteChatMessage(messageId)
        }
    }

    fun regenerateResponse(failedOrOldMessage: ChatMessageEntity) {
        val previousUserMessage = _chatMessages.value
            .filter { it.role == "user" && it.id < failedOrOldMessage.id }
            .lastOrNull() ?: _chatMessages.value.lastOrNull { it.role == "user" }

        val prompt = previousUserMessage?.content ?: return
        val mode = try {
            AIMode.valueOf(failedOrOldMessage.aiMode)
        } catch (_: Exception) {
            AIMode.AUTO
        }

        viewModelScope.launch {
            repository.deleteChatMessage(failedOrOldMessage.id)
            sendChatMessage(
                prompt = prompt,
                aiMode = mode,
                attachmentName = previousUserMessage.attachmentName,
                attachmentUri = previousUserMessage.attachmentUri
            )
        }
    }

    fun retryChatMessage(failedMessage: ChatMessageEntity) {
        regenerateResponse(failedMessage)
    }

    fun exportBackup(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.exportBackupJson()
            onResult(json)
        }
    }

    fun validateAndPreviewBackup(jsonString: String, onResult: (Result<BackupPreview>) -> Unit) {
        viewModelScope.launch {
            val res = repository.validateAndPreviewBackup(jsonString)
            onResult(res)
        }
    }

    fun importBackup(jsonString: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            val res = repository.importBackupJson(jsonString)
            if (res.isSuccess) {
                onResult(true, null)
            } else {
                onResult(false, res.exceptionOrNull()?.localizedMessage ?: "Import failed")
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
            _activeChatId.value = null
            _chatMessages.value = emptyList()
        }
    }
}
