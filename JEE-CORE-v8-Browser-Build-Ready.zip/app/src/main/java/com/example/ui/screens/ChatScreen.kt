package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.report.model.GeneratedReportFile
import com.example.report.model.ReportFormat
import com.example.report.model.ReportType
import com.example.report.ui.ReportActionCard
import java.io.File
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ai.AIMode
import com.example.ai.AIProgressStage
import com.example.data.model.ChatEntity
import com.example.data.model.ChatMessageEntity
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.DarkSlateCardHover
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.components.MarkdownRenderer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class DraftAttachment(
    val name: String,
    val uri: String,
    val text: String?,
    val base64: String? = null,
    val mimeType: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chats: List<ChatEntity>,
    activeChatId: Long?,
    messages: List<ChatMessageEntity>,
    aiProgressStage: AIProgressStage,
    onSelectChat: (Long) -> Unit,
    onBackToList: () -> Unit,
    onCreateChat: (String) -> Unit,
    onRenameChat: (Long, String) -> Unit,
    onDeleteChat: (Long) -> Unit,
    onSendMessage: (prompt: String, aiMode: AIMode, attachmentName: String?, attachmentUri: String?, attachmentText: String?, attachmentBase64: String?, attachmentMimeType: String?) -> Unit,
    onRetryMessage: (ChatMessageEntity) -> Unit = {},
    onRegenerateMessage: (ChatMessageEntity) -> Unit = {},
    onDeleteMessage: (Long) -> Unit = {},
    onCancelGeneration: () -> Unit = {},
    onSwitchReportFormat: ((ReportType, ReportFormat) -> Unit)? = null,
    onStartHeavyAnalysis: ((String) -> Unit)? = null
) {
    var showNewChatDialog by remember { mutableStateOf(false) }
    var renameChatTarget by remember { mutableStateOf<ChatEntity?>(null) }

    if (activeChatId == null) {
        // Multi-chat list screen
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("AI JEE COMMAND CHATS", fontSize = 16.sp, fontWeight = FontWeight.Black) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkSlateBackground,
                        titleContentColor = TextPrimary
                    )
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showNewChatDialog = true },
                    containerColor = ElectricCyanPrimary,
                    contentColor = Color(0xFF00363D),
                    modifier = Modifier.testTag("fab_new_chat")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "New Chat")
                }
            },
            containerColor = DarkSlateBackground
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                if (chats.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                Icons.Default.ChatBubbleOutline,
                                contentDescription = null,
                                tint = TextSecondary,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No chats yet", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Start a conversation with your JEE coach", color = TextSecondary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { onCreateChat("Tactical Strategy Session") },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                            ) {
                                Text("+ Start New Chat", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(chats, key = { it.id }) { chat ->
                            ChatListItem(
                                chat = chat,
                                onClick = { onSelectChat(chat.id) },
                                onRename = { renameChatTarget = chat },
                                onDelete = { onDeleteChat(chat.id) }
                            )
                        }
                    }
                }
            }
        }
    } else {
        // In-Conversation screen
        val activeChat = chats.find { it.id == activeChatId }
        val title = activeChat?.title ?: "Chat"
        var inputPrompt by remember { mutableStateOf("") }
        var selectedMode by remember { mutableStateOf(AIMode.AUTO) }
        var draftAttachment by remember { mutableStateOf<DraftAttachment?>(null) }
        val listState = rememberLazyListState()
        val context = LocalContext.current

        val filePickerLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri: Uri? ->
            uri?.let {
                var fileName = "Attached Note"
                try {
                    context.contentResolver.query(it, null, null, null, null)?.use { cursor ->
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (cursor.moveToFirst() && nameIndex >= 0) {
                            fileName = cursor.getString(nameIndex) ?: "Attached Note"
                        }
                    }
                } catch (_: Exception) {}

                val mime = context.contentResolver.getType(it) ?: when {
                    fileName.endsWith(".pdf", ignoreCase = true) -> "application/pdf"
                    fileName.endsWith(".jpg", ignoreCase = true) || fileName.endsWith(".jpeg", ignoreCase = true) -> "image/jpeg"
                    fileName.endsWith(".png", ignoreCase = true) -> "image/png"
                    fileName.endsWith(".webp", ignoreCase = true) -> "image/webp"
                    fileName.endsWith(".json", ignoreCase = true) -> "application/json"
                    else -> "text/plain"
                }

                var base64Data: String? = null
                var fileText: String? = null

                if (mime.startsWith("image/") || mime == "application/pdf") {
                    try {
                        val bytes = context.contentResolver.openInputStream(it)?.use { s -> s.readBytes() }
                        if (bytes != null) {
                            base64Data = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
                        }
                    } catch (_: Exception) {}
                } else {
                    fileText = try {
                        context.contentResolver.openInputStream(it)?.bufferedReader()?.use { reader ->
                            reader.readText().take(6000)
                        }
                    } catch (_: Exception) { null }
                }

                draftAttachment = DraftAttachment(
                    name = fileName,
                    uri = it.toString(),
                    text = fileText,
                    base64 = base64Data,
                    mimeType = mime
                )
            }
        }

        LaunchedEffect(messages.size) {
            if (messages.isNotEmpty()) {
                listState.animateScrollToItem(messages.size - 1)
            }
        }

        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            Text("JEE Core Executive Coach • ${selectedMode.displayName}", fontSize = 11.sp, color = ElectricCyanPrimary)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onBackToList) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = DarkSlateCard,
                        titleContentColor = TextPrimary,
                        navigationIconContentColor = TextPrimary
                    )
                )
            },
            containerColor = DarkSlateBackground
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .imePadding()
            ) {
                // Messages List
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (messages.isEmpty()) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = DarkSlateCard,
                                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("Command Center Active", color = ElectricCyanPrimary, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        "Ask anything regarding your JEE prep: current priorities, weak chapters, question selection, or request a customized problem-solving plan.",
                                        color = TextSecondary,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }
                    }

                    items(messages, key = { it.id }) { msg ->
                        ChatMessageBubble(
                            message = msg,
                            onRetry = onRetryMessage,
                            onRegenerate = onRegenerateMessage,
                            onDelete = onDeleteMessage,
                            onEdit = { text -> inputPrompt = text },
                            onSwitchReportFormat = onSwitchReportFormat
                        )
                    }

                    // Progress indicator if loading
                    if (aiProgressStage !is AIProgressStage.Idle && aiProgressStage !is AIProgressStage.Complete) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = DarkSlateCard,
                                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyanPrimary.copy(alpha = 0.5f)),
                                modifier = Modifier.padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = ElectricCyanPrimary,
                                        strokeWidth = 2.dp
                                    )
                                    Text(
                                        text = aiProgressStage.description,
                                        color = ElectricCyanPrimary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.weight(1f))
                                    OutlinedButton(
                                        onClick = onCancelGeneration,
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444)),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(30.dp)
                                    ) {
                                        Text("Stop", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                // AI Mode Selector Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(DarkSlateCard.copy(alpha = 0.6f))
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AIMode.values().forEach { mode ->
                        val isSelected = selectedMode == mode
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) ElectricCyanPrimary else DarkSlateCard,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) ElectricCyanPrimary else DarkSlateBorder
                            ),
                            modifier = Modifier
                                .clickable { selectedMode = mode }
                                .testTag("ai_mode_${mode.name.lowercase()}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) Color(0xFF00363D) else ElectricCyanPrimary.copy(alpha = 0.6f))
                                )
                                Text(
                                    text = mode.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isSelected) Color(0xFF00363D) else TextSecondary
                                )
                            }
                        }
                    }
                }

                // Attachment Preview if attached
                draftAttachment?.let { draft ->
                    Surface(
                        color = DarkSlateCardHover,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyanPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    Icons.Default.AttachFile,
                                    contentDescription = null,
                                    tint = ElectricCyanPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = draft.name,
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    modifier = Modifier.weight(1f, fill = false)
                                )

                                if (onStartHeavyAnalysis != null) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(ElectricCyanPrimary)
                                            .clickable { onStartHeavyAnalysis(draft.name) }
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "HEAVY AUDIT",
                                            color = Color(0xFF00363D),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }
                            IconButton(
                                onClick = { draftAttachment = null },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = "Remove attachment",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Input Bar
                Surface(
                    color = DarkSlateCard,
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        IconButton(
                            onClick = {
                                filePickerLauncher.launch("*/*")
                            },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                Icons.Default.AttachFile,
                                contentDescription = "Attach file",
                                tint = if (draftAttachment != null) ElectricCyanPrimary else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        OutlinedTextField(
                            value = inputPrompt,
                            onValueChange = { inputPrompt = it },
                            placeholder = { Text("Ask Coach [${selectedMode.displayName}]...", fontSize = 13.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_field"),
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricCyanPrimary,
                                unfocusedBorderColor = DarkSlateBorder
                            )
                        )

                        val isGenerating = aiProgressStage !is AIProgressStage.Idle && aiProgressStage !is AIProgressStage.Complete
                        if (isGenerating) {
                            IconButton(
                                onClick = onCancelGeneration,
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFEF4444))
                                    .testTag("cancel_generation_button")
                            ) {
                                Icon(
                                    Icons.Default.Stop,
                                    contentDescription = "Stop generation",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    if (inputPrompt.isNotBlank() || draftAttachment != null) {
                                        val text = inputPrompt
                                        val currentAttachment = draftAttachment
                                        inputPrompt = ""
                                        draftAttachment = null
                                        onSendMessage(
                                            text,
                                            selectedMode,
                                            currentAttachment?.name,
                                            currentAttachment?.uri,
                                            currentAttachment?.text,
                                            currentAttachment?.base64,
                                            currentAttachment?.mimeType
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(ElectricCyanPrimary)
                                    .testTag("send_chat_button")
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "Send",
                                    tint = Color(0xFF00363D),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // New Chat Dialog
    if (showNewChatDialog) {
        var chatTitle by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showNewChatDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("New Chat Conversation", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = chatTitle,
                        onValueChange = { chatTitle = it },
                        label = { Text("Chat Title") },
                        placeholder = { Text("e.g. Physics Revision Strategy") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showNewChatDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                onCreateChat(chatTitle.ifBlank { "JEE Prep Strategy" })
                                showNewChatDialog = false
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                        ) {
                            Text("CREATE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Rename Chat Dialog
    renameChatTarget?.let { chat ->
        var newTitle by remember { mutableStateOf(chat.title) }
        Dialog(onDismissRequest = { renameChatTarget = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = DarkSlateCard,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
                modifier = Modifier.padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Rename Conversation", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("New Title") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { renameChatTarget = null }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                onRenameChat(chat.id, newTitle.ifBlank { chat.title })
                                renameChatTarget = null
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                        ) {
                            Text("RENAME", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatListItem(
    chat: ChatEntity,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }
    val dateStr = remember(chat.updatedAtEpochMs) {
        SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(chat.updatedAtEpochMs))
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSlateCard,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("chat_item_${chat.id}")
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = chat.title,
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "$dateStr • ${chat.messageCount} messages",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            Box {
                IconButton(onClick = { menuExpanded = true }) {
                    Icon(Icons.Default.MoreVert, contentDescription = "Menu", tint = TextSecondary)
                }
                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier.background(DarkSlateCard)
                ) {
                    DropdownMenuItem(
                        text = { Text("Rename", color = TextPrimary) },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = ElectricCyanPrimary) },
                        onClick = {
                            menuExpanded = false
                            onRename()
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Delete", color = Color(0xFFEF4444)) },
                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFEF4444)) },
                        onClick = {
                            menuExpanded = false
                            onDelete()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ChatMessageBubble(
    message: ChatMessageEntity,
    onRetry: (ChatMessageEntity) -> Unit = {},
    onRegenerate: (ChatMessageEntity) -> Unit = {},
    onDelete: (Long) -> Unit = {},
    onEdit: (String) -> Unit = {},
    onSwitchReportFormat: ((ReportType, ReportFormat) -> Unit)? = null
) {
    val isUser = message.role == "user"
    val isError = message.isError
    val context = LocalContext.current

    val mode = try {
        AIMode.valueOf(message.aiMode)
    } catch (_: Exception) {
        null
    }

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 14.dp,
                topEnd = 14.dp,
                bottomStart = if (isUser) 14.dp else 2.dp,
                bottomEnd = if (isUser) 2.dp else 14.dp
            ),
            color = when {
                isError -> Color(0xFF2E1517)
                isUser -> ElectricCyanPrimary.copy(alpha = 0.14f)
                else -> Color.Transparent
            },
            border = if (isError) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444).copy(alpha = 0.8f))
            else if (isUser) androidx.compose.foundation.BorderStroke(1.dp, ElectricCyanPrimary.copy(alpha = 0.28f))
            else null,
            modifier = Modifier.widthIn(max = 390.dp)
        ) {
            SelectionContainer {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Header Row: Role & Mode indicator & Error tag
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isUser) "YOU" else "JEE CORE",
                            color = if (isUser) ElectricCyanPrimary else TextSecondary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (mode != null && mode != AIMode.AUTO) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = ElectricCyanPrimary.copy(alpha = 0.15f),
                                    border = androidx.compose.foundation.BorderStroke(0.5.dp, ElectricCyanPrimary.copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = mode.displayName.uppercase(),
                                        color = ElectricCyanPrimary,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            if (isError) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFEF4444).copy(alpha = 0.2f),
                                    border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0xFFEF4444))
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = Color(0xFFEF4444),
                                            modifier = Modifier.size(10.dp)
                                        )
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(
                                            text = "ERROR",
                                            color = Color(0xFFEF4444),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Attachment / Report Card Preview inside bubble
                    if (message.attachmentType?.startsWith("report:") == true) {
                        Spacer(modifier = Modifier.height(10.dp))
                        val parts = message.attachmentType.split(":")
                        val format = try { ReportFormat.valueOf(parts.getOrElse(1) { "PDF" }) } catch (_: Exception) { ReportFormat.PDF }
                        val reportType = try { ReportType.valueOf(parts.getOrElse(2) { "TEST_ANALYSIS" }) } catch (_: Exception) { ReportType.TEST_ANALYSIS }
                        val pageCount = parts.getOrElse(3) { "1" }.toIntOrNull() ?: 1
                        val sizeBytes = parts.getOrElse(4) { "1024" }.toLongOrNull() ?: 1024L
                        val uri = try { Uri.parse(message.attachmentUri ?: "") } catch (_: Exception) { Uri.EMPTY }
                        val file = File(context.cacheDir, "reports/${message.attachmentName ?: "report.${format.extension}"}")
                        val repFile = GeneratedReportFile(
                            file = file,
                            uri = uri,
                            reportType = reportType,
                            format = format,
                            title = reportType.displayName,
                            filename = message.attachmentName ?: "JEE_CORE_Report.${format.extension}",
                            pageOrSheetCount = pageCount,
                            sizeBytes = sizeBytes
                        )
                        ReportActionCard(
                            reportFile = repFile,
                            onSwitchFormat = onSwitchReportFormat
                        )
                    } else if (!message.attachmentName.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = DarkSlateBackground.copy(alpha = 0.5f),
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, DarkSlateBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    Icons.Default.AttachFile,
                                    contentDescription = null,
                                    tint = ElectricCyanPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = message.attachmentName,
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (message.content.isBlank() && !isError) {
                        // Streaming placeholder
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                color = ElectricCyanPrimary,
                                strokeWidth = 1.5.dp
                            )
                            Text(
                                text = "Thinking & calculating...",
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        MarkdownRenderer(
                            markdown = message.content,
                            textColor = if (isError) Color(0xFFFCA5A5) else TextPrimary,
                            isStreaming = false
                        )
                    }

                    // Quick action bar for copy, share, edit, regenerate, delete
                    if (message.content.isNotBlank() && !isError) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Copy
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("JEE CORE Message", message.content))
                                    Toast.makeText(context, "Copied to clipboard", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    Icons.Default.ContentCopy,
                                    contentDescription = "Copy",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(13.dp)
                                )
                            }

                            // Share
                            IconButton(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_TEXT, message.content)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "Share JEE Advice"))
                                },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    Icons.Default.Share,
                                    contentDescription = "Share",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(13.dp)
                                )
                            }

                            if (isUser) {
                                // Edit & reload into input
                                IconButton(
                                    onClick = { onEdit(message.content) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = "Edit",
                                        tint = TextSecondary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            } else {
                                // Regenerate
                                IconButton(
                                    onClick = { onRegenerate(message) },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Refresh,
                                        contentDescription = "Regenerate",
                                        tint = ElectricCyanPrimary,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }

                            // Delete
                            IconButton(
                                onClick = { onDelete(message.id) },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = TextSecondary.copy(alpha = 0.6f),
                                    modifier = Modifier.size(13.dp)
                                )
                            }
                        }
                    }

                    // Retry button for errors
                    if (isError) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { onRetry(message) },
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = Color(0xFFEF4444)
                                ),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEF4444)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("retry_message_button")
                            ) {
                                Icon(
                                    Icons.Default.Refresh,
                                    contentDescription = "Retry",
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Retry", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            IconButton(
                                onClick = { onDelete(message.id) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete error message",
                                    tint = Color(0xFFEF4444).copy(alpha = 0.7f),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
