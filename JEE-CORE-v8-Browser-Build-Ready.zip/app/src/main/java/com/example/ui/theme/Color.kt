package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkSlateBackground = Color(0xFF0B0F19)
val DarkSlateSurface = Color(0xFF131B2E)
val DarkSlateCard = Color(0xFF1E293B)
val DarkSlateCardHover = Color(0xFF26354D)
val DarkSlateBorder = Color(0xFF334155)

val ElectricCyanPrimary = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF00B4D8)
val ElectricCyanGlow = Color(0x3300E5FF)

val SecondaryIndigo = Color(0xFF818CF8)
val SecondaryPurple = Color(0xFFA855F7)

val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

val PhysicsAccent = Color(0xFF38BDF8)
val ChemistryAccent = Color(0xFFF472B6)
val MathsAccent = Color(0xFFFBBF24)
