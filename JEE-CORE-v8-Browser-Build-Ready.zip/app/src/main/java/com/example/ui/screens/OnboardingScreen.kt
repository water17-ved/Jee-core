package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AIBehaviour
import com.example.data.model.ExamType
import com.example.data.model.JeeMemory
import com.example.data.model.SubjectLevel
import com.example.data.model.UserProfile
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    currentProfile: UserProfile,
    currentAIBehaviour: AIBehaviour,
    currentMemory: JeeMemory,
    onComplete: (UserProfile, AIBehaviour, JeeMemory, String) -> Unit
) {
    var step by remember { mutableIntStateOf(1) }
    val totalSteps = 9

    // Form states
    var targetExam by remember { mutableStateOf(currentProfile.targetExam) }
    var targetYear by remember { mutableIntStateOf(currentProfile.targetYear) }
    var targetRank by remember { mutableStateOf(currentProfile.targetRank) }

    var physicsLevel by remember { mutableStateOf(currentProfile.physicsLevel) }
    var chemLevel by remember { mutableStateOf(currentProfile.chemistryLevel) }
    var mathsLevel by remember { mutableStateOf(currentProfile.mathsLevel) }

    var weekdayHours by remember { mutableFloatStateOf(currentProfile.weekdayAvailableHours) }
    var weekendHours by remember { mutableFloatStateOf(currentProfile.weekendAvailableHours) }

    var coachingSchedule by remember { mutableStateOf(currentMemory.coachingSchedule) }
    var mealsSchedule by remember { mutableStateOf(currentProfile.mealsSchedule) }
    var fixedCommitments by remember { mutableStateOf(currentProfile.fixedCommitments) }

    var weakAreas by remember { mutableStateOf(currentMemory.weaknesses) }
    var recurringProblems by remember { mutableStateOf(currentMemory.recurringProblems) }

    var strictness by remember { mutableFloatStateOf(currentAIBehaviour.strictness) }
    var conciseness by remember { mutableFloatStateOf(currentAIBehaviour.conciseness) }
    var directness by remember { mutableFloatStateOf(currentAIBehaviour.directness) }
    var customInstructions by remember { mutableStateOf(currentAIBehaviour.customInstructions) }

    var geminiApiKey by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("COMMAND CENTER SETUP ($step/$totalSteps)", fontSize = 14.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    if (step > 1) {
                        IconButton(onClick = { step-- }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    }
                },
                actions = {
                    TextButton(
                        onClick = {
                            onComplete(
                                currentProfile.copy(isOnboardingComplete = true),
                                currentAIBehaviour,
                                currentMemory,
                                geminiApiKey
                            )
                        }
                    ) {
                        Text("SKIP TO DASHBOARD", color = ElectricCyanPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkSlateBackground,
                    titleContentColor = ElectricCyanPrimary,
                    navigationIconContentColor = TextPrimary
                )
            )
        },
        containerColor = DarkSlateBackground
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
        ) {
            LinearProgressIndicator(
                progress = { step.toFloat() / totalSteps.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = ElectricCyanPrimary,
                trackColor = DarkSlateBorder
            )

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
            ) {
                when (step) {
                    1 -> StepWelcome()
                    2 -> StepTargetExam(targetExam, { targetExam = it }, targetYear, { targetYear = it }, targetRank, { targetRank = it })
                    3 -> StepSubjectLevels(physicsLevel, { physicsLevel = it }, chemLevel, { chemLevel = it }, mathsLevel, { mathsLevel = it })
                    4 -> StepDailyTime(weekdayHours, { weekdayHours = it }, weekendHours, { weekendHours = it })
                    5 -> StepCoachingCommitments(coachingSchedule, { coachingSchedule = it }, mealsSchedule, { mealsSchedule = it }, fixedCommitments, { fixedCommitments = it })
                    6 -> StepWeaknesses(weakAreas, { weakAreas = it }, recurringProblems, { recurringProblems = it })
                    7 -> StepAIBehaviour(strictness, { strictness = it }, conciseness, { conciseness = it }, directness, { directness = it }, customInstructions, { customInstructions = it })
                    8 -> StepGeminiKey(geminiApiKey, { geminiApiKey = it })
                    9 -> StepReadySummary(targetExam, targetYear, weekdayHours, weekendHours)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (step > 1) {
                    OutlinedButton(
                        onClick = { step-- },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary)
                    ) {
                        Text("BACK")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                }

                Button(
                    onClick = {
                        if (step < totalSteps) {
                            step++
                        } else {
                            val newProfile = currentProfile.copy(
                                targetExam = targetExam,
                                targetYear = targetYear,
                                targetRank = targetRank,
                                physicsLevel = physicsLevel,
                                chemistryLevel = chemLevel,
                                mathsLevel = mathsLevel,
                                weekdayAvailableHours = weekdayHours,
                                weekendAvailableHours = weekendHours,
                                mealsSchedule = mealsSchedule,
                                fixedCommitments = fixedCommitments,
                                weakAreasNotes = weakAreas,
                                isOnboardingComplete = true
                            )
                            val newAI = currentAIBehaviour.copy(
                                strictness = strictness,
                                conciseness = conciseness,
                                directness = directness,
                                customInstructions = customInstructions
                            )
                            val newMemory = currentMemory.copy(
                                targetSummary = "Target: $targetRank in ${targetExam.displayName} $targetYear",
                                coachingSchedule = coachingSchedule,
                                weaknesses = weakAreas,
                                recurringProblems = recurringProblems
                            )
                            onComplete(newProfile, newAI, newMemory, geminiApiKey)
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("onboarding_next_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                ) {
                    Text(
                        text = if (step == totalSteps) "ACTIVATE CORE" else "CONTINUE",
                        color = Color(0xFF00363D),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun StepWelcome() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(30.dp))
        Text("JEE CORE", color = ElectricCyanPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("Your JEE Preparation Command Center", color = TextSecondary, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(28.dp))

        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    "Execution > Information",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    "This is not a generic chatbot, habit tracker, or static timetable. JEE CORE continuously understands your actual preparation state and tells you:\n\n• What to do NOW\n• What comes NEXT\n• What happens AFTER THAT",
                    color = TextSecondary,
                    lineHeight = 22.sp,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
private fun StepTargetExam(
    targetExam: ExamType,
    onExamChange: (ExamType) -> Unit,
    targetYear: Int,
    onYearChange: (Int) -> Unit,
    targetRank: String,
    onRankChange: (String) -> Unit
) {
    Column {
        Text("Target Examination", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Specify your primary exam goal and timeline", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(20.dp))

        ExamType.values().forEach { exam ->
            val isSelected = targetExam == exam
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.15f) else DarkSlateCard)
                    .border(1.dp, if (isSelected) ElectricCyanPrimary else DarkSlateBorder, RoundedCornerShape(12.dp))
                    .clickable { onExamChange(exam) }
                    .padding(16.dp)
            ) {
                Text(exam.displayName, color = if (isSelected) ElectricCyanPrimary else TextPrimary, fontWeight = FontWeight.SemiBold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Target Year", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(2025, 2026, 2027).forEach { yr ->
                val isSelected = targetYear == yr
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateCard)
                        .border(1.dp, if (isSelected) ElectricCyanPrimary else DarkSlateBorder, RoundedCornerShape(8.dp))
                        .clickable { onYearChange(yr) }
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(yr.toString(), color = if (isSelected) ElectricCyanPrimary else TextSecondary, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = targetRank,
            onValueChange = onRankChange,
            label = { Text("Target Rank or Percentile") },
            placeholder = { Text("e.g. Under 1000 / 99.5+ percentile") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = ElectricCyanPrimary,
                unfocusedBorderColor = DarkSlateBorder
            )
        )
    }
}

@Composable
private fun StepSubjectLevels(
    pLevel: SubjectLevel,
    onPChange: (SubjectLevel) -> Unit,
    cLevel: SubjectLevel,
    onCChange: (SubjectLevel) -> Unit,
    mLevel: SubjectLevel,
    onMChange: (SubjectLevel) -> Unit
) {
    Column {
        Text("Current Baseline Levels", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Honest baseline allows accurate priority planning", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(20.dp))

        SubjectLevelRow("Physics", pLevel, onPChange)
        Spacer(modifier = Modifier.height(16.dp))
        SubjectLevelRow("Chemistry", cLevel, onCChange)
        Spacer(modifier = Modifier.height(16.dp))
        SubjectLevelRow("Mathematics", mLevel, onMChange)
    }
}

@Composable
private fun SubjectLevelRow(
    subjectName: String,
    selected: SubjectLevel,
    onSelect: (SubjectLevel) -> Unit
) {
    Column {
        Text(subjectName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SubjectLevel.values().forEach { lvl ->
                val isSelected = selected == lvl
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateCard)
                        .border(1.dp, if (isSelected) ElectricCyanPrimary else DarkSlateBorder, RoundedCornerShape(6.dp))
                        .clickable { onSelect(lvl) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(lvl.displayName, color = if (isSelected) ElectricCyanPrimary else TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun StepDailyTime(
    weekday: Float,
    onWeekdayChange: (Float) -> Unit,
    weekend: Float,
    onWeekendChange: (Float) -> Unit
) {
    Column {
        Text("Daily Available Self-Study Hours", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Exclude coaching and school classes. Only pure problem-solving time.", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(24.dp))

        Text("Weekday Self-Study: ${weekday.toInt()} hours", color = ElectricCyanPrimary, fontWeight = FontWeight.Bold)
        Slider(
            value = weekday,
            onValueChange = onWeekdayChange,
            valueRange = 2f..14f,
            steps = 11,
            colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text("Weekend / Holiday Self-Study: ${weekend.toInt()} hours", color = ElectricCyanPrimary, fontWeight = FontWeight.Bold)
        Slider(
            value = weekend,
            onValueChange = onWeekendChange,
            valueRange = 4f..16f,
            steps = 11,
            colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary)
        )
    }
}

@Composable
private fun StepCoachingCommitments(
    coaching: String,
    onCoachingChange: (String) -> Unit,
    meals: String,
    onMealsChange: (String) -> Unit,
    fixed: String,
    onFixedChange: (String) -> Unit
) {
    Column {
        Text("Fixed Schedule & Commitments", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Ensures recommendations don't clash with classes or sleep", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = coaching,
            onValueChange = onCoachingChange,
            label = { Text("Coaching Schedule") },
            placeholder = { Text("e.g. Allen Morning Batch 08:00 - 13:00") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = meals,
            onValueChange = onMealsChange,
            label = { Text("Lunch / Dinner Times") },
            placeholder = { Text("13:30, 20:30") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = fixed,
            onValueChange = onFixedChange,
            label = { Text("Other Fixed Commitments") },
            placeholder = { Text("School 3 days a week, commute 1 hr") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
    }
}

@Composable
private fun StepWeaknesses(
    weakAreas: String,
    onWeakChange: (String) -> Unit,
    recurringProblems: String,
    onProblemsChange: (String) -> Unit
) {
    Column {
        Text("Weak Areas & Recurring Traps", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("The system uses these to seed initial missions and revision triggers", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = weakAreas,
            onValueChange = onWeakChange,
            label = { Text("Known Difficult Chapters / Topics") },
            placeholder = { Text("e.g. Rotational Motion, Organic Mechanisms, Complex Numbers") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = recurringProblems,
            onValueChange = onProblemsChange,
            label = { Text("Recurring Test / Execution Traps") },
            placeholder = { Text("e.g. Calculation errors under time pressure, getting stuck on question 1") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
    }
}

@Composable
private fun StepAIBehaviour(
    strictness: Float,
    onStrictnessChange: (Float) -> Unit,
    conciseness: Float,
    onConcisenessChange: (Float) -> Unit,
    directness: Float,
    onDirectnessChange: (Float) -> Unit,
    instructions: String,
    onInstructionsChange: (String) -> Unit
) {
    Column {
        Text("AI Coach Personality Tuning", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Control how the AI speaks to you throughout your preparation", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(20.dp))

        Text("Strictness: ${if (strictness > 0.6f) "Uncompromising" else "Encouraging"}", color = TextPrimary, fontSize = 13.sp)
        Slider(value = strictness, onValueChange = onStrictnessChange, colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary))

        Text("Brevity: ${if (conciseness > 0.6f) "Bullet-points only" else "Detailed"}", color = TextPrimary, fontSize = 13.sp)
        Slider(value = conciseness, onValueChange = onConcisenessChange, colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary))

        Text("Directness: ${if (directness > 0.6f) "Direct Commands" else "Explanatory"}", color = TextPrimary, fontSize = 13.sp)
        Slider(value = directness, onValueChange = onDirectnessChange, colors = SliderDefaults.colors(thumbColor = ElectricCyanPrimary, activeTrackColor = ElectricCyanPrimary))

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
            value = instructions,
            onValueChange = onInstructionsChange,
            label = { Text("Custom Directives for AI") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )
    }
}

@Composable
private fun StepGeminiKey(
    key: String,
    onKeyChange: (String) -> Unit
) {
    Column {
        Text("Gemini API Setup", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("JEE CORE uses Google Gemini for deep tactical analysis. Built-in environment key will be used if left blank.", color = TextSecondary, fontSize = 13.sp)
        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = key,
            onValueChange = onKeyChange,
            label = { Text("Custom Gemini API Key (Optional)") },
            placeholder = { Text("AIzaSy...") },
            modifier = Modifier.fillMaxWidth().testTag("onboarding_gemini_key"),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = ElectricCyanPrimary, unfocusedBorderColor = DarkSlateBorder)
        )

        Spacer(modifier = Modifier.height(16.dp))
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Offline & Deterministic Guarantee", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "All core priority scoring, timers, syllabus tracking, and test analytics run 100% locally on your device without sending your data anywhere.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun StepReadySummary(
    targetExam: ExamType,
    targetYear: Int,
    weekdayHours: Float,
    weekendHours: Float
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(modifier = Modifier.height(20.dp))
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.height(64.dp).width(64.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("Command Center Activated", color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Your JEE execution system is calibrated.", color = TextSecondary, fontSize = 14.sp)
        Spacer(modifier = Modifier.height(24.dp))

        Surface(
            shape = RoundedCornerShape(14.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Target", color = TextSecondary, fontSize = 13.sp)
                    Text("${targetExam.displayName} $targetYear", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Weekday Self-Study", color = TextSecondary, fontSize = 13.sp)
                    Text("${weekdayHours.toInt()} Hours / day", color = ElectricCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Weekend Self-Study", color = TextSecondary, fontSize = 13.sp)
                    Text("${weekendHours.toInt()} Hours / day", color = ElectricCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}
