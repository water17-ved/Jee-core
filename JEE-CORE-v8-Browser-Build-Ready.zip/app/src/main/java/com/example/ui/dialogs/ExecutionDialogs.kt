package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.ExamType
import com.example.data.model.MissionCreator
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.PriorityLevel
import com.example.data.model.ScheduleSlot
import com.example.data.model.Subject
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.TopicState
import com.example.data.model.WorkLogEntity
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults

@Composable
fun LogWorkDialog(
    onDismiss: () -> Unit,
    onSave: (WorkLogEntity) -> Unit
) {
    var subject by remember { mutableStateOf(Subject.PHYSICS) }
    var chapter by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var whatDidYouDo by remember { mutableStateOf("PYQ Problem Solving") }
    var durationMinutes by remember { mutableStateOf("45") }
    var attempted by remember { mutableStateOf("15") }
    var correct by remember { mutableStateOf("12") }
    var incorrect by remember { mutableStateOf("3") }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Log Study Work",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Subject", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Subject.values().forEach { sub ->
                        val isSelected = subject == sub
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateBackground)
                                .border(
                                    1.dp,
                                    if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { subject = sub }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = sub.displayName.take(4),
                                color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = chapter,
                    onValueChange = { chapter = it },
                    label = { Text("Chapter") },
                    placeholder = { Text("e.g. Electrostatics") },
                    modifier = Modifier.fillMaxWidth().testTag("log_chapter_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("Topic (Optional)") },
                    placeholder = { Text("e.g. Capacitors with dielectrics") },
                    modifier = Modifier.fillMaxWidth().testTag("log_topic_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = whatDidYouDo,
                    onValueChange = { whatDidYouDo = it },
                    label = { Text("Task Completed") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = durationMinutes,
                        onValueChange = { durationMinutes = it },
                        label = { Text("Time (min)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )

                    OutlinedTextField(
                        value = attempted,
                        onValueChange = { attempted = it },
                        label = { Text("Attempted") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = correct,
                        onValueChange = { correct = it },
                        label = { Text("Correct") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )

                    OutlinedTextField(
                        value = incorrect,
                        onValueChange = { incorrect = it },
                        label = { Text("Incorrect") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Observations") },
                    placeholder = { Text("Mistake in calculation; revise formula") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val duration = durationMinutes.toIntOrNull() ?: 45
                        val att = attempted.toIntOrNull() ?: 0
                        val corr = correct.toIntOrNull() ?: 0
                        val incorr = incorrect.toIntOrNull() ?: 0
                        onSave(
                            WorkLogEntity(
                                subject = subject,
                                chapter = chapter.ifBlank { "General ${subject.displayName}" },
                                topic = topic.ifBlank { "Problem Set" },
                                whatDidYouDo = whatDidYouDo.ifBlank { "Study Session" },
                                durationMinutes = duration,
                                questionsAttempted = att,
                                questionsCorrect = corr,
                                questionsIncorrect = incorr,
                                notes = notes
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_log_work"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                ) {
                    Text("SAVE TO DATABASE", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CreateMissionDialog(
    onDismiss: () -> Unit,
    onSave: (MissionEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf(Subject.PHYSICS) }
    var chapter by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var plannedDuration by remember { mutableStateOf("45") }
    var targetQuestions by remember { mutableStateOf("15") }
    var priority by remember { mutableStateOf(PriorityLevel.HIGH) }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "New Tactical Mission",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Mission Title") },
                    placeholder = { Text("e.g. 20 PYQs Electrostatics 2024") },
                    modifier = Modifier.fillMaxWidth().testTag("mission_title_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Subject", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Subject.values().forEach { sub ->
                        val isSelected = subject == sub
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateBackground)
                                .border(
                                    1.dp,
                                    if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { subject = sub }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = sub.displayName.take(4),
                                color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = chapter,
                        onValueChange = { chapter = it },
                        label = { Text("Chapter") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = topic,
                        onValueChange = { topic = it },
                        label = { Text("Topic") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = plannedDuration,
                        onValueChange = { plannedDuration = it },
                        label = { Text("Duration (min)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = targetQuestions,
                        onValueChange = { targetQuestions = it },
                        label = { Text("Target PYQs") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Priority", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PriorityLevel.values().forEach { prio ->
                        val isSelected = priority == prio
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateBackground)
                                .border(
                                    1.dp,
                                    if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { priority = prio }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = prio.displayName.uppercase(),
                                color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Tactical Notes") },
                    placeholder = { Text("Focus on multi-correct and numerical types") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val duration = plannedDuration.toIntOrNull() ?: 45
                        val target = targetQuestions.toIntOrNull() ?: 15
                        val finalTitle = title.ifBlank { "$target PYQs ${chapter.ifBlank { subject.displayName }}" }
                        onSave(
                            MissionEntity(
                                title = finalTitle,
                                subject = subject,
                                chapter = chapter.ifBlank { "General ${subject.displayName}" },
                                topic = topic.ifBlank { "Problem Solving" },
                                plannedDurationMinutes = duration,
                                targetQuantity = target,
                                priority = priority,
                                status = MissionStatus.NOT_STARTED,
                                notes = notes,
                                createdBy = MissionCreator.USER
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_create_mission"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                ) {
                    Text("CREATE MISSION", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun TestRecordDialog(
    onDismiss: () -> Unit,
    onSave: (TestRecordEntity) -> Unit
) {
    var testName by remember { mutableStateOf("") }
    var examType by remember { mutableStateOf(ExamType.JEE_MAIN) }
    var totalMarks by remember { mutableStateOf("300") }
    var userScore by remember { mutableStateOf("") }
    var physicsScore by remember { mutableStateOf("") }
    var chemistryScore by remember { mutableStateOf("") }
    var mathsScore by remember { mutableStateOf("") }
    var attempted by remember { mutableStateOf("60") }
    var correct by remember { mutableStateOf("45") }
    var incorrect by remember { mutableStateOf("15") }
    var conceptualErrors by remember { mutableStateOf("4") }
    var calculationErrors by remember { mutableStateOf("5") }
    var sillyMistakes by remember { mutableStateOf("3") }
    var timePressureErrors by remember { mutableStateOf("3") }
    var weakChapters by remember { mutableStateOf("Electrostatics, Complex Numbers") }
    var analysisNotes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Record Mock Test",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = testName,
                    onValueChange = { testName = it },
                    label = { Text("Test Name / Code") },
                    placeholder = { Text("e.g. Allen Minor Test 5 (Full Syllabus)") },
                    modifier = Modifier.fillMaxWidth().testTag("test_name_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ExamType.values().take(2).forEach { et ->
                        val isSelected = examType == et
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateBackground)
                                .border(
                                    1.dp,
                                    if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { examType = et }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = et.displayName,
                                color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = totalMarks,
                        onValueChange = { totalMarks = it },
                        label = { Text("Total Marks") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = userScore,
                        onValueChange = { userScore = it },
                        label = { Text("Total Score") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("Subject Breakdown", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = physicsScore,
                        onValueChange = { physicsScore = it },
                        label = { Text("P Score") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = chemistryScore,
                        onValueChange = { chemistryScore = it },
                        label = { Text("C Score") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = mathsScore,
                        onValueChange = { mathsScore = it },
                        label = { Text("M Score") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Error Breakdown (Crucial for Coach)", color = ElectricCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedTextField(
                        value = conceptualErrors,
                        onValueChange = { conceptualErrors = it },
                        label = { Text("Concept") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = calculationErrors,
                        onValueChange = { calculationErrors = it },
                        label = { Text("Calculation") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = sillyMistakes,
                        onValueChange = { sillyMistakes = it },
                        label = { Text("Silly") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = weakChapters,
                    onValueChange = { weakChapters = it },
                    label = { Text("Weak Chapters Detected (comma separated)") },
                    placeholder = { Text("Electrostatics, Reaction Mechanisms") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = analysisNotes,
                    onValueChange = { analysisNotes = it },
                    label = { Text("Post-Test Strategic Notes") },
                    placeholder = { Text("Rushed in Maths; spent 10 mins on single 3D geometry question") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val tot = totalMarks.toIntOrNull() ?: 300
                        val score = userScore.toIntOrNull() ?: (physicsScore.toIntOrNull() ?: 0) + (chemistryScore.toIntOrNull() ?: 0) + (mathsScore.toIntOrNull() ?: 0)
                        val att = attempted.toIntOrNull() ?: 0
                        val corr = correct.toIntOrNull() ?: 0
                        val acc = if (att > 0) (corr.toFloat() / att.toFloat()) * 100f else 0f
                        onSave(
                            TestRecordEntity(
                                testName = testName.ifBlank { "Mock Test" },
                                examType = examType,
                                totalMarks = tot,
                                userScore = score,
                                physicsScore = physicsScore.toIntOrNull() ?: 0,
                                chemistryScore = chemistryScore.toIntOrNull() ?: 0,
                                mathsScore = mathsScore.toIntOrNull() ?: 0,
                                attempted = att,
                                correct = corr,
                                incorrect = incorrect.toIntOrNull() ?: 0,
                                accuracy = acc,
                                conceptualErrors = conceptualErrors.toIntOrNull() ?: 0,
                                calculationErrors = calculationErrors.toIntOrNull() ?: 0,
                                sillyMistakes = sillyMistakes.toIntOrNull() ?: 0,
                                timePressureErrors = timePressureErrors.toIntOrNull() ?: 0,
                                weakChaptersIdentified = weakChapters,
                                analysisNotes = analysisNotes
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_test_record"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                ) {
                    Text("RECORD TEST ANALYSIS", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EditTopicDialog(
    topic: SyllabusTopicEntity,
    onDismiss: () -> Unit,
    onSave: (SyllabusTopicEntity) -> Unit
) {
    var selectedState by remember { mutableStateOf(topic.state) }
    var confidenceScore by remember { mutableStateOf(topic.confidenceScore.toFloat()) }
    var pyqsAttempted by remember { mutableStateOf(topic.pyqsAttempted.toString()) }
    var pyqsCorrect by remember { mutableStateOf(topic.pyqsCorrect.toString()) }
    var isWeakArea by remember { mutableStateOf(topic.isWeakArea) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = topic.topicName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "${topic.subject.displayName} • ${topic.chapter}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("MASTERY STATUS", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    val statesList = TopicState.values().toList()
                    val rows = listOf(statesList.take(3), statesList.drop(3))
                    for (rowStates in rows) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (st in rowStates) {
                                val isSelected = selectedState == st
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.25f) else DarkSlateBackground)
                                        .border(
                                            1.dp,
                                            if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { selectedState = st }
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = st.displayName,
                                        color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CONFIDENCE SCORE", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text("${confidenceScore.toInt()}%", color = ElectricCyanPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                    value = confidenceScore,
                    onValueChange = { confidenceScore = it },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = ElectricCyanPrimary,
                        activeTrackColor = ElectricCyanPrimary,
                        inactiveTrackColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = pyqsAttempted,
                        onValueChange = { pyqsAttempted = it },
                        label = { Text("PYQs Solved") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = pyqsCorrect,
                        onValueChange = { pyqsCorrect = it },
                        label = { Text("PYQs Correct") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Flag as Priority Weak Area", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Highlights in coach plan & review lists", color = TextSecondary, fontSize = 11.sp)
                    }
                    Switch(
                        checked = isWeakArea,
                        onCheckedChange = { isWeakArea = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ElectricCyanPrimary,
                            checkedTrackColor = ElectricCyanPrimary.copy(alpha = 0.3f),
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val att = pyqsAttempted.toIntOrNull() ?: topic.pyqsAttempted
                        val corr = pyqsCorrect.toIntOrNull() ?: topic.pyqsCorrect
                        val acc = if (att > 0) ((corr.toFloat() / att.toFloat()) * 100).toInt() else topic.testAccuracyPercent
                        onSave(
                            topic.copy(
                                state = selectedState,
                                confidenceScore = confidenceScore.toInt(),
                                pyqsAttempted = att,
                                pyqsCorrect = corr,
                                testAccuracyPercent = acc,
                                isWeakArea = isWeakArea,
                                lastStudiedEpochMs = System.currentTimeMillis()
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_edit_topic"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                ) {
                    Text("UPDATE SYLLABUS TOPIC", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AddScheduleSlotDialog(
    onDismiss: () -> Unit,
    onSave: (ScheduleSlot) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var timeRange by remember { mutableStateOf("07:00 - 09:30") }
    var selectedSubject by remember { mutableStateOf(Subject.PHYSICS) }
    var chapterOrTask by remember { mutableStateOf("") }
    var targetMinutes by remember { mutableStateOf("150") }
    var slotPeriod by remember { mutableStateOf("Morning") }

    val periods = listOf("Morning", "Afternoon", "Evening", "Night")

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = DarkSlateCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSlateBorder),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Add Study Slot",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Slot Name") },
                    placeholder = { Text("e.g. Physics High-Yield Problems") },
                    modifier = Modifier.fillMaxWidth().testTag("schedule_title_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("SUBJECT", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Subject.values().forEach { sub ->
                        val isSelected = selectedSubject == sub
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateBackground)
                                .border(
                                    1.dp,
                                    if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedSubject = sub }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = sub.displayName,
                                color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = chapterOrTask,
                    onValueChange = { chapterOrTask = it },
                    label = { Text("Chapter / Task") },
                    placeholder = { Text("e.g. Rotational Motion & Torque PYQs") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ElectricCyanPrimary,
                        unfocusedBorderColor = DarkSlateBorder
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = timeRange,
                        onValueChange = { timeRange = it },
                        label = { Text("Time Window") },
                        placeholder = { Text("06:00 - 08:30") },
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                    OutlinedTextField(
                        value = targetMinutes,
                        onValueChange = { targetMinutes = it },
                        label = { Text("Minutes") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyanPrimary,
                            unfocusedBorderColor = DarkSlateBorder
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text("PERIOD", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    periods.forEach { p ->
                        val isSelected = slotPeriod == p
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) ElectricCyanPrimary.copy(alpha = 0.2f) else DarkSlateBackground)
                                .border(
                                    1.dp,
                                    if (isSelected) ElectricCyanPrimary else DarkSlateBorder,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { slotPeriod = p }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = p,
                                color = if (isSelected) ElectricCyanPrimary else TextSecondary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        val mins = targetMinutes.toIntOrNull() ?: 120
                        onSave(
                            ScheduleSlot(
                                title = title.ifBlank { "Study Slot" },
                                timeRange = timeRange.ifBlank { "09:00 - 11:00" },
                                subject = selectedSubject,
                                chapterOrTask = chapterOrTask.ifBlank { "Self Study" },
                                targetMinutes = mins,
                                isCompleted = false,
                                slotPeriod = slotPeriod
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("submit_schedule_slot"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyanPrimary)
                ) {
                    Text("ADD SCHEDULE SLOT", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
