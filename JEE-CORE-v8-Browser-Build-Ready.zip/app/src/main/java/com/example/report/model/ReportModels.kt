package com.example.report.model

import android.net.Uri
import java.io.File

enum class ReportType(
    val displayName: String,
    val defaultFilenamePrefix: String,
    val description: String
) {
    TEST_ANALYSIS(
        displayName = "Test Analysis Report",
        defaultFilenamePrefix = "JEE_CORE_Test_Analysis",
        description = "Detailed breakdown of test scores, accuracy, time, error taxonomy, and leakage."
    ),
    MULTI_TEST_SUMMARY(
        displayName = "Multi-Test Performance Benchmark",
        defaultFilenamePrefix = "JEE_CORE_Multi_Test_Report",
        description = "Trends across recent mock tests, score trajectory, and recurring error patterns."
    ),
    SYLLABUS_MASTERY(
        displayName = "Syllabus Mastery & Chapter Audit",
        defaultFilenamePrefix = "JEE_CORE_Syllabus_Report",
        description = "Subject and chapter completion, confidence metrics, and PYQ coverage."
    ),
    WEAKNESS_AUDIT(
        displayName = "Weakness & Error Diagnostics",
        defaultFilenamePrefix = "JEE_CORE_Weakness_Analysis",
        description = "Identified weak chapters, error frequency breakdown, and critical improvement zones."
    ),
    REVISION_PRIORITIES(
        displayName = "Tactical Revision & Backlog Plan",
        defaultFilenamePrefix = "JEE_CORE_Revision_Plan",
        description = "Prioritized revision agenda, spaced repetition schedule, and target exercises."
    ),
    COMPLETE_PERFORMANCE(
        displayName = "Comprehensive JEE Performance Report",
        defaultFilenamePrefix = "JEE_CORE_Complete_Performance_Report",
        description = "Full 360-degree dossier covering syllabus, tests, errors, study hours, and strategy."
    ),
    STUDY_HOURS_LOG(
        displayName = "Study Tracker & Time Analysis",
        defaultFilenamePrefix = "JEE_CORE_Study_Hours_Log",
        description = "Focus sessions, daily schedule adherence, and subject time distribution."
    )
}

enum class ReportFormat(
    val extension: String,
    val mimeType: String,
    val displayName: String
) {
    PDF("pdf", "application/pdf", "PDF Document"),
    XLSX("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Excel Workbook")
}

data class ReportMetadata(
    val title: String,
    val subtitle: String,
    val generatedAtEpochMs: Long = System.currentTimeMillis(),
    val studentName: String = "JEE Aspirant",
    val targetExam: String,
    val targetYear: Int,
    val targetRank: String,
    val totalTestsLogged: Int,
    val syllabusProgressPercent: Int,
    val totalStudyHoursLogged: Float
)

data class ReportSummaryCard(
    val title: String,
    val value: String,
    val subtitle: String = "",
    val badge: String? = null,
    val colorHex: String = "#00E5FF" // Default cyan accent
)

enum class ReportChartType {
    BAR_COMPARISON,
    HORIZONTAL_PROGRESS,
    BREAKDOWN_DONUT,
    ERROR_DISTRIBUTION
}

data class ReportChartData(
    val title: String,
    val type: ReportChartType,
    val labels: List<String>,
    val values: List<Float>,
    val secondaryValues: List<Float> = emptyList(),
    val maxValue: Float = 100f,
    val unit: String = ""
)

data class ReportTable(
    val title: String,
    val headers: List<String>,
    val rows: List<List<String>>,
    val columnWeights: List<Float> = emptyList(),
    val summaryFooterRow: List<String>? = null
)

data class ReportSection(
    val sectionNumber: Int,
    val title: String,
    val subtitle: String? = null,
    val summaryCards: List<ReportSummaryCard> = emptyList(),
    val charts: List<ReportChartData> = emptyList(),
    val tables: List<ReportTable> = emptyList(),
    val observations: List<String> = emptyList(),
    val recommendations: List<String> = emptyList()
)

data class ReportDocument(
    val metadata: ReportMetadata,
    val reportType: ReportType,
    val format: ReportFormat,
    val executiveSummary: String,
    val sections: List<ReportSection>,
    val actionPlan: List<String> = emptyList()
)

data class GeneratedReportFile(
    val file: File,
    val uri: Uri,
    val reportType: ReportType,
    val format: ReportFormat,
    val title: String,
    val filename: String,
    val pageOrSheetCount: Int,
    val sizeBytes: Long,
    val timestampEpochMs: Long = System.currentTimeMillis()
)

data class ReportProgress(
    val percentage: Int,
    val stageDescription: String,
    val isFinished: Boolean = false,
    val error: String? = null,
    val generatedFile: GeneratedReportFile? = null
)
