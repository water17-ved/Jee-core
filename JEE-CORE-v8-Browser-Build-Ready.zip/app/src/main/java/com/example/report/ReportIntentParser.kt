package com.example.report

import com.example.report.model.ReportFormat
import com.example.report.model.ReportType

data class ReportRequest(
    val reportType: ReportType,
    val format: ReportFormat,
    val specificTestId: Long? = null,
    val rawPrompt: String
)

object ReportIntentParser {

    /**
     * Checks if the given user prompt is requesting document/report generation.
     * Returns a valid [ReportRequest] if detected, or null otherwise.
     */
    fun parse(prompt: String): ReportRequest? {
        val clean = prompt.trim().lowercase()

        // Fast rejection if prompt does not contain document/export keywords
        val hasDocumentKeyword = clean.contains("report") ||
                clean.contains("pdf") ||
                clean.contains("excel") ||
                clean.contains("xlsx") ||
                clean.contains("spreadsheet") ||
                clean.contains("export") ||
                clean.contains("document") ||
                clean.contains("printable") ||
                clean.contains("download") ||
                clean.contains("sheet")

        if (!hasDocumentKeyword) return null

        // Format detection
        val format = when {
            clean.contains("excel") || clean.contains("xlsx") || clean.contains("spreadsheet") || clean.contains(".xlsx") -> ReportFormat.XLSX
            clean.contains("pdf") || clean.contains("printable") || clean.contains("document") -> ReportFormat.PDF
            else -> ReportFormat.PDF // Default to PDF for generic "report"
        }

        // Report Type detection
        val reportType = when {
            // 1. Weakness & Error Analysis
            clean.contains("weakness") || clean.contains("weak") || clean.contains("error analysis") || clean.contains("mistake") -> {
                ReportType.WEAKNESS_AUDIT
            }
            // 2. Multi-test / last N tests
            clean.contains("last") && (clean.contains("test") || clean.contains("mock")) ||
                    clean.contains("multi-test") || clean.contains("all tests") ||
                    clean.contains("all my tests") || clean.contains("test history") || clean.contains("mock tests") -> {
                ReportType.MULTI_TEST_SUMMARY
            }
            // 3. Single / Latest Test Analysis
            clean.contains("test") || clean.contains("mock") || clean.contains("marks") || clean.contains("score") -> {
                ReportType.TEST_ANALYSIS
            }
            // 4. Syllabus / Chapter-wise
            clean.contains("syllabus") || clean.contains("chapter") || clean.contains("topic") || clean.contains("coverage") -> {
                ReportType.SYLLABUS_MASTERY
            }
            // 5. Revision Plan
            clean.contains("revision") || clean.contains("backlog") -> {
                ReportType.REVISION_PRIORITIES
            }
            // 6. Study hours / Time / Tracker
            clean.contains("study hour") || clean.contains("hours") || clean.contains("timesheet") || clean.contains("schedule") || clean.contains("time spent") -> {
                ReportType.STUDY_HOURS_LOG
            }
            // 7. Complete / Comprehensive JEE Performance Report
            clean.contains("complete") || clean.contains("full") || clean.contains("comprehensive") || clean.contains("dossier") || clean.contains("jee performance") -> {
                ReportType.COMPLETE_PERFORMANCE
            }
            // Generic fallback
            clean.contains("report") -> {
                ReportType.COMPLETE_PERFORMANCE
            }
            else -> null
        } ?: return null

        return ReportRequest(
            reportType = reportType,
            format = format,
            rawPrompt = prompt
        )
    }
}
