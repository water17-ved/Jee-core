package com.example.report

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionEntity
import com.example.data.model.ScheduleSlot
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.UserProfile
import com.example.data.model.WorkLogEntity
import com.example.report.model.GeneratedReportFile
import com.example.report.model.ReportDocument
import com.example.report.model.ReportFormat
import com.example.report.model.ReportProgress
import com.example.report.model.ReportType
import com.example.report.pdf.PdfReportGenerator
import com.example.report.xlsx.XlsxReportGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportManager(private val context: Context) {

    private val pdfGenerator = PdfReportGenerator()
    private val xlsxGenerator = XlsxReportGenerator()

    fun generateReportFlow(
        reportType: ReportType,
        format: ReportFormat,
        userProfile: UserProfile,
        tests: List<TestRecordEntity>,
        syllabusTopics: List<SyllabusTopicEntity>,
        missions: List<MissionEntity>,
        focusSessions: List<FocusSessionEntity>,
        workLogs: List<WorkLogEntity>,
        scheduleSlots: List<ScheduleSlot>,
        specificTestId: Long? = null
    ): Flow<ReportProgress> = flow {
        emit(ReportProgress(15, "Retrieving verified test and tracker data from local database..."))
        delay(120) // Smooth progress UX

        val collector = ReportDataCollector(
            userProfile = userProfile,
            tests = tests,
            syllabusTopics = syllabusTopics,
            missions = missions,
            focusSessions = focusSessions,
            workLogs = workLogs,
            scheduleSlots = scheduleSlots
        )

        emit(ReportProgress(40, "Synthesizing diagnostics, score leakage, and syllabus status..."))
        delay(150)

        val document: ReportDocument = collector.buildReport(reportType, format, specificTestId)

        emit(ReportProgress(65, "Rendering structured layout, metric cards, and charts..."))
        delay(120)

        val timestampStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val filename = "${reportType.defaultFilenamePrefix}_$timestampStr.${format.extension}"
        val reportsDir = File(context.cacheDir, "reports").apply { mkdirs() }
        val targetFile = File(reportsDir, filename)

        emit(ReportProgress(85, "Encoding native ${format.displayName} binary..."))

        val pageOrSheetCount = when (format) {
            ReportFormat.PDF -> pdfGenerator.generate(document, targetFile)
            ReportFormat.XLSX -> xlsxGenerator.generate(document, targetFile)
        }

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            targetFile
        )

        val generated = GeneratedReportFile(
            file = targetFile,
            uri = uri,
            reportType = reportType,
            format = format,
            title = document.metadata.title,
            filename = filename,
            pageOrSheetCount = pageOrSheetCount,
            sizeBytes = targetFile.length(),
            timestampEpochMs = System.currentTimeMillis()
        )

        emit(ReportProgress(100, "Report generated successfully!", isFinished = true, generatedFile = generated))
    }.flowOn(Dispatchers.IO)

    fun openReport(reportFile: GeneratedReportFile) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(reportFile.uri, reportFile.format.mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Open ${reportFile.title}"))
        } catch (e: Exception) {
            Toast.makeText(context, "No app found to open ${reportFile.format.extension.uppercase()} files.", Toast.LENGTH_LONG).show()
        }
    }

    fun shareReport(reportFile: GeneratedReportFile) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = reportFile.format.mimeType
                putExtra(Intent.EXTRA_STREAM, reportFile.uri)
                putExtra(Intent.EXTRA_SUBJECT, reportFile.title)
                putExtra(Intent.EXTRA_TEXT, "JEE Core Academic Report: ${reportFile.title}\nGenerated on ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(reportFile.timestampEpochMs))}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Share ${reportFile.title}").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "Error sharing report: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    suspend fun saveToDownloads(reportFile: GeneratedReportFile): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, reportFile.filename)
                    put(MediaStore.MediaColumns.MIME_TYPE, reportFile.format.mimeType)
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/JEECore")
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return@withContext Result.failure(Exception("Failed to create download entry."))

                resolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(reportFile.file).use { input ->
                        input.copyTo(out)
                    }
                }
                Result.success("Saved to Downloads/JEECore/${reportFile.filename}")
            } else {
                @Suppress("DEPRECATION")
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(downloadsDir, "JEECore").apply { mkdirs() }
                val destFile = File(targetDir, reportFile.filename)
                FileInputStream(reportFile.file).use { input ->
                    FileOutputStream(destFile).use { out ->
                        input.copyTo(out)
                    }
                }
                Result.success("Saved to ${destFile.absolutePath}")
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
