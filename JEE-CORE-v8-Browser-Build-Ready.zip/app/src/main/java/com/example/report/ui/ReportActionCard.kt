package com.example.report.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.report.ReportManager
import com.example.report.model.GeneratedReportFile
import com.example.report.model.ReportFormat
import com.example.report.model.ReportType
import com.example.ui.theme.DarkSlateBackground
import com.example.ui.theme.DarkSlateBorder
import com.example.ui.theme.DarkSlateCard
import com.example.ui.theme.ElectricCyanPrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@Composable
fun ReportActionCard(
    reportFile: GeneratedReportFile,
    modifier: Modifier = Modifier,
    onSwitchFormat: ((ReportType, ReportFormat) -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val reportManager = ReportManager(context)

    val isPdf = reportFile.format == ReportFormat.PDF
    val badgeColor = if (isPdf) Color(0xFFEF4444) else SuccessGreen
    val icon = if (isPdf) Icons.Default.Description else Icons.Default.TableChart
    val formatLabel = if (isPdf) "PDF REPORT" else "EXCEL SPREADSHEET"
    val countLabel = if (isPdf) "${reportFile.pageOrSheetCount} Pages" else "${reportFile.pageOrSheetCount} Sheets"
    val sizeKb = (reportFile.sizeBytes / 1024).coerceAtLeast(1)

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = DarkSlateBackground.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, if (isPdf) ElectricCyanPrimary.copy(alpha = 0.4f) else SuccessGreen.copy(alpha = 0.4f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("report_action_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Format Badge & Size
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(badgeColor.copy(alpha = 0.15f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = formatLabel,
                            color = badgeColor,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "•  $countLabel  •  ${sizeKb} KB",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(DarkSlateCard)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "VERIFIED DATA",
                        color = ElectricCyanPrimary,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // File Info
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(badgeColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = badgeColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = reportFile.title,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = reportFile.filename,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Open
                Button(
                    onClick = { reportManager.openReport(reportFile) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPdf) ElectricCyanPrimary else SuccessGreen
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(36.dp)
                        .testTag("btn_open_report")
                ) {
                    Icon(
                        Icons.Default.OpenInNew,
                        contentDescription = "Open",
                        modifier = Modifier.size(15.dp),
                        tint = Color(0xFF00363D)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Open",
                        color = Color(0xFF00363D),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Share
                OutlinedButton(
                    onClick = { reportManager.shareReport(reportFile) },
                    border = BorderStroke(1.dp, DarkSlateBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("btn_share_report")
                ) {
                    Icon(
                        Icons.Default.Share,
                        contentDescription = "Share",
                        tint = TextPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share", color = TextPrimary, fontSize = 11.sp)
                }

                // Save to Downloads
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            val res = reportManager.saveToDownloads(reportFile)
                            res.onSuccess { path ->
                                Toast.makeText(context, path, Toast.LENGTH_LONG).show()
                            }.onFailure { err ->
                                Toast.makeText(context, "Save failed: ${err.localizedMessage}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    border = BorderStroke(1.dp, DarkSlateBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("btn_save_report")
                ) {
                    Icon(
                        Icons.Default.Download,
                        contentDescription = "Save",
                        tint = TextPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Save", color = TextPrimary, fontSize = 11.sp)
                }
            }

            // Switch to Excel / Switch to PDF button if alternate format requested
            if (onSwitchFormat != null) {
                Spacer(modifier = Modifier.height(8.dp))
                val targetFormat = if (isPdf) ReportFormat.XLSX else ReportFormat.PDF
                val switchLabel = if (isPdf) "Generate as Excel (.xlsx)" else "Generate as PDF (.pdf)"

                OutlinedButton(
                    onClick = { onSwitchFormat(reportFile.reportType, targetFormat) },
                    border = BorderStroke(0.8.dp, DarkSlateBorder),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .testTag("btn_switch_report_format")
                ) {
                    Icon(
                        Icons.Default.SwapHoriz,
                        contentDescription = null,
                        tint = ElectricCyanPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = switchLabel,
                        color = ElectricCyanPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}
