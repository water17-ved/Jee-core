package com.example.report.xlsx

import com.example.report.model.ReportDocument
import com.example.report.model.ReportTable
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class XlsxReportGenerator {

    data class XlsxSheet(
        val name: String,
        val title: String,
        val tables: List<ReportTable>,
        val notes: List<String> = emptyList()
    )

    fun generate(document: ReportDocument, outputFile: File): Int {
        val sheets = buildSheets(document)

        outputFile.parentFile?.mkdirs()
        ZipOutputStream(FileOutputStream(outputFile)).use { zip ->
            // 1. [Content_Types].xml
            zip.putNextEntry(ZipEntry("[Content_Types].xml"))
            zip.write(buildContentTypesXml(sheets.size).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // 2. _rels/.rels
            zip.putNextEntry(ZipEntry("_rels/.rels"))
            zip.write(buildRootRelsXml().toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // 3. xl/workbook.xml
            zip.putNextEntry(ZipEntry("xl/workbook.xml"))
            zip.write(buildWorkbookXml(sheets).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // 4. xl/_rels/workbook.xml.rels
            zip.putNextEntry(ZipEntry("xl/_rels/workbook.xml.rels"))
            zip.write(buildWorkbookRelsXml(sheets.size).toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // 5. xl/styles.xml
            zip.putNextEntry(ZipEntry("xl/styles.xml"))
            zip.write(buildStylesXml().toByteArray(Charsets.UTF_8))
            zip.closeEntry()

            // 6. xl/worksheets/sheetN.xml
            for ((idx, sheet) in sheets.withIndex()) {
                zip.putNextEntry(ZipEntry("xl/worksheets/sheet${idx + 1}.xml"))
                zip.write(buildWorksheetXml(sheet, document).toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
        }

        return sheets.size
    }

    private fun buildSheets(doc: ReportDocument): List<XlsxSheet> {
        val list = mutableListOf<XlsxSheet>()

        // Sheet 1: Executive Overview & Summary
        val summaryRows = mutableListOf<List<String>>()
        summaryRows.add(listOf("Target Exam", doc.metadata.targetExam))
        summaryRows.add(listOf("Target Year", "${doc.metadata.targetYear}"))
        summaryRows.add(listOf("Target AIR / Goal", doc.metadata.targetRank))
        summaryRows.add(listOf("Syllabus Coverage", "${doc.metadata.syllabusProgressPercent}%"))
        summaryRows.add(listOf("Total Tests Logged", "${doc.metadata.totalTestsLogged}"))
        summaryRows.add(listOf("Total Study Hours", "${String.format(Locale.US, "%.1f", doc.metadata.totalStudyHoursLogged)} Hrs"))

        val overviewTable = ReportTable(
            title = "Academic Dashboard Overview",
            headers = listOf("Metric Parameter", "Verified System Value"),
            rows = summaryRows
        )

        val cardsRows = doc.sections.flatMap { it.summaryCards }.map { card ->
            listOf(card.title, card.value, card.subtitle)
        }
        val cardsTable = if (cardsRows.isNotEmpty()) {
            ReportTable(
                title = "Key Benchmark Indicators",
                headers = listOf("Indicator", "Primary Value", "Context / Note"),
                rows = cardsRows
            )
        } else null

        list.add(
            XlsxSheet(
                name = "Overview",
                title = doc.metadata.title,
                tables = listOfNotNull(overviewTable, cardsTable),
                notes = listOf(
                    "Executive Summary: ${doc.executiveSummary}",
                    "Generated on: ${SimpleDateFormat("dd MMMM yyyy, HH:mm:ss", Locale.getDefault()).format(Date(doc.metadata.generatedAtEpochMs))}",
                    "Notice: This spreadsheet contains real verified data from the local JEE Core database."
                )
            )
        )

        // Add section-specific sheets
        for (section in doc.sections) {
            if (section.tables.isNotEmpty()) {
                val cleanName = section.title
                    .replace(Regex("[^a-zA-Z0-9 ]"), "")
                    .trim()
                    .take(28)
                    .ifBlank { "Section ${section.sectionNumber}" }

                list.add(
                    XlsxSheet(
                        name = cleanName,
                        title = "${section.sectionNumber}. ${section.title}",
                        tables = section.tables,
                        notes = section.observations
                    )
                )
            }
        }

        // Action Plan Sheet
        if (doc.actionPlan.isNotEmpty()) {
            val actionRows = doc.actionPlan.mapIndexed { i, action ->
                listOf("#${i + 1}", action, "High Priority", "Pending Execution")
            }
            list.add(
                XlsxSheet(
                    name = "Action Plan",
                    title = "Strategic Action Plan & Tactics",
                    tables = listOf(
                        ReportTable(
                            title = "Prioritized Action Queue",
                            headers = listOf("Step", "Tactical Recommendation", "Priority", "Status"),
                            rows = actionRows
                        )
                    ),
                    notes = listOf("Execute each intervention sequentially to eliminate score leakage.")
                )
            )
        }

        return list
    }

    private fun buildContentTypesXml(sheetCount: Int): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">""")
        sb.append("""<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>""")
        sb.append("""<Default Extension="xml" ContentType="application/xml"/>""")
        sb.append("""<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>""")
        sb.append("""<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>""")
        for (i in 1..sheetCount) {
            sb.append("""<Override PartName="/xl/worksheets/sheet$i.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>""")
        }
        sb.append("""</Types>""")
        return sb.toString()
    }

    private fun buildRootRelsXml(): String {
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
    <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""
    }

    private fun buildWorkbookXml(sheets: List<XlsxSheet>): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""")
        sb.append("""<sheets>""")
        for ((idx, sheet) in sheets.withIndex()) {
            val sId = idx + 1
            sb.append("""<sheet name="${escapeXml(sheet.name)}" sheetId="$sId" r:id="rId$sId"/>""")
        }
        sb.append("""</sheets>""")
        sb.append("""</workbook>""")
        return sb.toString()
    }

    private fun buildWorkbookRelsXml(sheetCount: Int): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
        for (i in 1..sheetCount) {
            sb.append("""<Relationship Id="rId$i" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet$i.xml"/>""")
        }
        sb.append("""<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>""")
        sb.append("""</Relationships>""")
        return sb.toString()
    }

    private fun buildStylesXml(): String {
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
    <numFmts count="2">
        <numFmt numFmtId="164" formatCode="#,##0"/>
        <numFmt numFmtId="165" formatCode="0.0%"/>
    </numFmts>
    <fonts count="4">
        <font><sz val="11"/><name val="Calibri"/><color rgb="FF0F172A"/></font>
        <font><b/><sz val="11"/><name val="Calibri"/><color rgb="FFFFFFFF"/></font>
        <font><b/><sz val="14"/><name val="Calibri"/><color rgb="FF0F172A"/></font>
        <font><b/><sz val="11"/><name val="Calibri"/><color rgb="FF0891B2"/></font>
    </fonts>
    <fills count="5">
        <fill><patternFill patternType="none"/></fill>
        <fill><patternFill patternType="gray125"/></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FF0F172A"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFF1F5F9"/></patternFill></fill>
        <fill><patternFill patternType="solid"><fgColor rgb="FFE0F2FE"/></patternFill></fill>
    </fills>
    <borders count="2">
        <border><left/><right/><top/><bottom/></border>
        <border>
            <left style="thin"><color rgb="FFCBD5E1"/></left>
            <right style="thin"><color rgb="FFCBD5E1"/></right>
            <top style="thin"><color rgb="FFCBD5E1"/></top>
            <bottom style="thin"><color rgb="FFCBD5E1"/></bottom>
        </border>
    </borders>
    <cellStyleXfs count="1">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="0"/>
    </cellStyleXfs>
    <cellXfs count="6">
        <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyBorder="1"/>
        <xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">
            <alignment horizontal="center" vertical="center"/>
        </xf>
        <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
        <xf numFmtId="0" fontId="0" fillId="3" borderId="1" xfId="0" applyFill="1" applyBorder="1"/>
        <xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1" applyBorder="1">
            <alignment horizontal="right"/>
        </xf>
        <xf numFmtId="0" fontId="3" fillId="4" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"/>
    </cellXfs>
</styleSheet>"""
    }

    private fun buildWorksheetXml(sheet: XlsxSheet, doc: ReportDocument): String {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")

        // Frozen Header Pane
        sb.append("""<sheetViews><sheetView tabSelected="1" workbookViewId="0">""")
        sb.append("""<pane ySplit="2" topLeftCell="A3" activePane="bottomLeft" state="frozen"/>""")
        sb.append("""</sheetView></sheetViews>""")

        // Column Widths
        sb.append("""<cols>""")
        sb.append("""<col min="1" max="1" width="28" customWidth="1"/>""")
        sb.append("""<col min="2" max="2" width="24" customWidth="1"/>""")
        sb.append("""<col min="3" max="3" width="20" customWidth="1"/>""")
        sb.append("""<col min="4" max="4" width="22" customWidth="1"/>""")
        sb.append("""<col min="5" max="8" width="18" customWidth="1"/>""")
        sb.append("""</cols>""")

        sb.append("""<sheetData>""")

        var rowIdx = 1

        // Row 1: Sheet Title (Style 2 = 14pt bold)
        sb.append("""<row r="$rowIdx" ht="28" customHeight="1">""")
        sb.append("""<c r="A$rowIdx" s="2" t="inlineStr"><is><t>${escapeXml(sheet.title)}</t></is></c>""")
        sb.append("""</row>""")
        rowIdx++

        // Tables
        for (table in sheet.tables) {
            // Space before table
            if (rowIdx > 2) {
                rowIdx++
            }

            if (table.title.isNotBlank()) {
                sb.append("""<row r="$rowIdx" ht="20" customHeight="1">""")
                sb.append("""<c r="A$rowIdx" s="5" t="inlineStr"><is><t>${escapeXml(table.title)}</t></is></c>""")
                sb.append("""</row>""")
                rowIdx++
            }

            // Table Header Row (Style 1 = dark slate fill, bold white text)
            sb.append("""<row r="$rowIdx" ht="22" customHeight="1">""")
            for ((colIdx, header) in table.headers.withIndex()) {
                val colLetter = getColumnLetter(colIdx)
                sb.append("""<c r="$colLetter$rowIdx" s="1" t="inlineStr"><is><t>${escapeXml(header)}</t></is></c>""")
            }
            sb.append("""</row>""")
            rowIdx++

            // Table Data Rows
            for ((rIdx, row) in table.rows.withIndex()) {
                val styleId = if (rIdx % 2 == 1) 3 else 0 // 3 is zebra fill, 0 is white
                sb.append("""<row r="$rowIdx" ht="18" customHeight="1">""")
                for ((colIdx, cell) in row.withIndex()) {
                    val colLetter = getColumnLetter(colIdx)
                    val numericVal = cell.toLongOrNull()
                    if (numericVal != null) {
                        sb.append("""<c r="$colLetter$rowIdx" s="4" t="n"><v>$numericVal</v></c>""")
                    } else {
                        sb.append("""<c r="$colLetter$rowIdx" s="$styleId" t="inlineStr"><is><t>${escapeXml(cell)}</t></is></c>""")
                    }
                }
                sb.append("""</row>""")
                rowIdx++
            }

            // Summary Footer Row
            table.summaryFooterRow?.let { footer ->
                sb.append("""<row r="$rowIdx" ht="20" customHeight="1">""")
                for ((colIdx, cell) in footer.withIndex()) {
                    val colLetter = getColumnLetter(colIdx)
                    sb.append("""<c r="$colLetter$rowIdx" s="5" t="inlineStr"><is><t>${escapeXml(cell)}</t></is></c>""")
                }
                sb.append("""</row>""")
                rowIdx++
            }
        }

        // Notes / Observations at bottom
        if (sheet.notes.isNotEmpty()) {
            rowIdx += 2
            sb.append("""<row r="$rowIdx" ht="20" customHeight="1">""")
            sb.append("""<c r="A$rowIdx" s="5" t="inlineStr"><is><t>NOTES &amp; AUDIT EVIDENCE</t></is></c>""")
            sb.append("""</row>""")
            rowIdx++

            for (note in sheet.notes) {
                sb.append("""<row r="$rowIdx">""")
                sb.append("""<c r="A$rowIdx" s="0" t="inlineStr"><is><t>• ${escapeXml(note)}</t></is></c>""")
                sb.append("""</row>""")
                rowIdx++
            }
        }

        sb.append("""</sheetData>""")
        sb.append("""</worksheet>""")
        return sb.toString()
    }

    private fun getColumnLetter(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n >= 0) {
            sb.append(('A'.code + (n % 26)).toChar())
            n = (n / 26) - 1
        }
        return sb.reverse().toString()
    }

    private fun escapeXml(str: String): String {
        return str
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }
}
