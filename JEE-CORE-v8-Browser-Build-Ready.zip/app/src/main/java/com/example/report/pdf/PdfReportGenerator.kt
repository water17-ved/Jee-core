package com.example.report.pdf

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.example.report.model.ReportChartData
import com.example.report.model.ReportChartType
import com.example.report.model.ReportDocument
import com.example.report.model.ReportSection
import com.example.report.model.ReportSummaryCard
import com.example.report.model.ReportTable
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PdfReportGenerator {

    private val pageWidth = 595 // A4 standard width in points (72 dpi)
    private val pageHeight = 842 // A4 standard height in points (72 dpi)
    private val marginLeft = 36f
    private val marginRight = 36f
    private val marginTop = 50f
    private val marginBottom = 50f
    private val contentWidth = pageWidth - marginLeft - marginRight

    // Brand Palette
    private val colorPrimary = Color.parseColor("#0891B2") // Rich Cyan
    private val colorDarkHeader = Color.parseColor("#0F172A") // Deep Slate
    private val colorCardBg = Color.parseColor("#F8FAFC") // Off-white / light slate
    private val colorCardBorder = Color.parseColor("#CBD5E1") // Soft border
    private val colorTextPrimary = Color.parseColor("#0F172A")
    private val colorTextSecondary = Color.parseColor("#475569")
    private val colorSuccess = Color.parseColor("#059669")
    private val colorDanger = Color.parseColor("#DC2626")
    private val colorWarning = Color.parseColor("#D97706")
    private val colorZebra = Color.parseColor("#F1F5F9")

    fun generate(document: ReportDocument, outputFile: File): Int {
        val pdfDocument = PdfDocument()
        var pageNumber = 1
        var currentPage: PdfDocument.Page? = null
        var canvas: Canvas? = null
        var currentY = marginTop

        fun startNewPage() {
            currentPage?.let {
                drawPageFooter(canvas!!, pageNumber)
                pdfDocument.finishPage(it)
                pageNumber++
            }
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            currentPage = pdfDocument.startPage(pageInfo)
            canvas = currentPage!!.canvas
            currentY = marginTop
            drawPageHeader(canvas!!, document, pageNumber)
            currentY += 24f
        }

        fun ensureSpace(neededHeight: Float) {
            if (currentY + neededHeight > pageHeight - marginBottom) {
                startNewPage()
            }
        }

        // Start Page 1
        val firstPageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        currentPage = pdfDocument.startPage(firstPageInfo)
        canvas = currentPage!!.canvas
        drawPageHeader(canvas!!, document, 1)
        currentY = marginTop + 24f

        // 1. Title Banner
        currentY = drawTitleBanner(canvas!!, document, currentY)

        // 2. Executive Summary Box
        ensureSpace(90f)
        currentY = drawExecutiveSummary(canvas!!, document.executiveSummary, currentY)

        // 3. Render Sections
        for (section in document.sections) {
            ensureSpace(40f)
            currentY = drawSectionHeader(canvas!!, section, currentY)

            // Summary Cards
            if (section.summaryCards.isNotEmpty()) {
                val cardHeight = 58f
                ensureSpace(cardHeight + 10f)
                currentY = drawSummaryCards(canvas!!, section.summaryCards, currentY)
            }

            // Charts
            for (chart in section.charts) {
                val chartHeight = when (chart.type) {
                    ReportChartType.BAR_COMPARISON -> 130f
                    ReportChartType.HORIZONTAL_PROGRESS -> 110f
                    ReportChartType.BREAKDOWN_DONUT -> 120f
                    ReportChartType.ERROR_DISTRIBUTION -> 115f
                }
                ensureSpace(chartHeight + 16f)
                currentY = drawChart(canvas!!, chart, currentY, chartHeight)
            }

            // Tables
            for (table in section.tables) {
                currentY = drawTableWithPagination(
                    table = table,
                    startCanvas = canvas!!,
                    startY = currentY,
                    onRequestNewPage = {
                        startNewPage()
                        canvas!!
                    },
                    getCanvas = { canvas!! }
                )
            }

            // Observations & Bullet Notes
            if (section.observations.isNotEmpty()) {
                ensureSpace(40f)
                currentY = drawBulletList(canvas!!, "Key Observations:", section.observations, currentY, colorPrimary)
            }
        }

        // 4. Concrete Action Plan
        if (document.actionPlan.isNotEmpty()) {
            ensureSpace(70f)
            currentY = drawActionPlan(canvas!!, document.actionPlan, currentY)
        }

        // Finish last page
        currentPage?.let {
            drawPageFooter(canvas!!, pageNumber)
            pdfDocument.finishPage(it)
        }

        // Save to file
        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        return pageNumber
    }

    private fun drawPageHeader(canvas: Canvas, document: ReportDocument, pageNumber: Int) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorPrimary
        }

        canvas.drawText("JEE CORE COMMAND ENGINE", marginLeft, 24f, paint)

        paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        paint.color = colorTextSecondary
        val rightText = "ACADEMIC AUDIT • ${document.metadata.targetExam}"
        val rightWidth = paint.measureText(rightText)
        canvas.drawText(rightText, pageWidth - marginRight - rightWidth, 24f, paint)

        // Subtle Header Line
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 1f
        }
        canvas.drawLine(marginLeft, 30f, pageWidth - marginRight, 30f, linePaint)
    }

    private fun drawPageFooter(canvas: Canvas, pageNumber: Int) {
        val lineY = pageHeight - 34f
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 1f
        }
        canvas.drawLine(marginLeft, lineY, pageWidth - marginRight, lineY, linePaint)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            color = colorTextSecondary
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }

        canvas.drawText("CONFIDENTIAL • Generated from local verified data • Never fabricated", marginLeft, pageHeight - 20f, paint)

        val pageText = "Page $pageNumber"
        val pageTextWidth = paint.measureText(pageText)
        canvas.drawText(pageText, pageWidth - marginRight - pageTextWidth, pageHeight - 20f, paint)
    }

    private fun drawTitleBanner(canvas: Canvas, doc: ReportDocument, startY: Float): Float {
        var y = startY

        // Background banner card
        val bannerHeight = 64f
        val bgRect = RectF(marginLeft, y, pageWidth - marginRight, y + bannerHeight)
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorDarkHeader
        }
        canvas.drawRoundRect(bgRect, 8f, 8f, bgPaint)

        // Decorative Cyan accent stripe on left
        val stripeRect = RectF(marginLeft, y, marginLeft + 5f, y + bannerHeight)
        val stripePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorPrimary
        }
        canvas.drawRoundRect(stripeRect, 4f, 4f, stripePaint)

        // Title text
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 15f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = Color.WHITE
        }
        canvas.drawText(doc.metadata.title, marginLeft + 16f, y + 24f, titlePaint)

        // Subtitle text
        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            color = Color.parseColor("#94A3B8")
        }
        canvas.drawText(doc.metadata.subtitle, marginLeft + 16f, y + 40f, subPaint)

        // Metadata Pills on the right
        val metaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            color = colorPrimary
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        }
        val dateFormat = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        val dateStr = dateFormat.format(Date(doc.metadata.generatedAtEpochMs))
        val rightInfo = "${doc.metadata.targetExam} ${doc.metadata.targetYear} • $dateStr"
        val textWidth = metaPaint.measureText(rightInfo)
        canvas.drawText(rightInfo, pageWidth - marginRight - 14f - textWidth, y + 36f, metaPaint)

        y += bannerHeight + 14f
        return y
    }

    private fun drawExecutiveSummary(canvas: Canvas, summary: String, startY: Float): Float {
        var y = startY

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            color = colorTextPrimary
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        }

        val lines = wrapText(summary, contentWidth - 24f, paint)
        val boxHeight = (lines.size * 13f) + 30f

        val boxRect = RectF(marginLeft, y, pageWidth - marginRight, y + boxHeight)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F0FDF4") // soft green-tinted executive card
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#BBF7D0")
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(boxRect, 6f, 6f, fillPaint)
        canvas.drawRoundRect(boxRect, 6f, 6f, borderPaint)

        // Header inside card
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorSuccess
        }
        canvas.drawText("EXECUTIVE PERFORMANCE SUMMARY", marginLeft + 12f, y + 16f, headerPaint)

        var lineY = y + 30f
        for (line in lines) {
            canvas.drawText(line, marginLeft + 12f, lineY, paint)
            lineY += 13f
        }

        return y + boxHeight + 14f
    }

    private fun drawSectionHeader(canvas: Canvas, section: ReportSection, startY: Float): Float {
        var y = startY

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorDarkHeader
        }
        canvas.drawText("${section.sectionNumber}. ${section.title}", marginLeft, y + 12f, titlePaint)

        if (!section.subtitle.isNullOrBlank()) {
            val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 8.5f
                color = colorTextSecondary
            }
            canvas.drawText(section.subtitle, marginLeft, y + 24f, subPaint)
            y += 12f
        }

        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 1f
        }
        canvas.drawLine(marginLeft, y + 16f, pageWidth - marginRight, y + 16f, linePaint)

        return y + 24f
    }

    private fun drawSummaryCards(canvas: Canvas, cards: List<ReportSummaryCard>, startY: Float): Float {
        val count = minOf(cards.size, 4)
        if (count == 0) return startY

        val cardSpacing = 8f
        val totalSpacing = cardSpacing * (count - 1)
        val cardWidth = (contentWidth - totalSpacing) / count
        val cardHeight = 54f

        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorCardBg }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorCardBorder
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }

        for (i in 0 until count) {
            val card = cards[i]
            val cardLeft = marginLeft + i * (cardWidth + cardSpacing)
            val rect = RectF(cardLeft, startY, cardLeft + cardWidth, startY + cardHeight)
            canvas.drawRoundRect(rect, 6f, 6f, fillPaint)
            canvas.drawRoundRect(rect, 6f, 6f, borderPaint)

            // Accent bar on top of card
            val accentColor = try {
                Color.parseColor(card.colorHex)
            } catch (_: Exception) {
                colorPrimary
            }
            val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }
            val accentRect = RectF(cardLeft, startY, cardLeft + cardWidth, startY + 3f)
            canvas.drawRoundRect(accentRect, 3f, 3f, accentPaint)

            // Title
            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 7.5f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                color = colorTextSecondary
            }
            canvas.drawText(card.title, cardLeft + 8f, startY + 16f, titlePaint)

            // Value
            val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 14f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                color = colorDarkHeader
            }
            canvas.drawText(card.value, cardLeft + 8f, startY + 34f, valPaint)

            // Subtitle
            if (card.subtitle.isNotBlank()) {
                val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textSize = 7.5f
                    color = colorTextSecondary
                }
                canvas.drawText(card.subtitle, cardLeft + 8f, startY + 46f, subPaint)
            }
        }

        return startY + cardHeight + 12f
    }

    private fun drawChart(canvas: Canvas, chart: ReportChartData, startY: Float, height: Float): Float {
        val chartRect = RectF(marginLeft, startY, pageWidth - marginRight, startY + height)
        val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorCardBg }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorCardBorder
            style = Paint.Style.STROKE
            strokeWidth = 1f
        }
        canvas.drawRoundRect(chartRect, 6f, 6f, fillPaint)
        canvas.drawRoundRect(chartRect, 6f, 6f, borderPaint)

        // Chart Title
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorDarkHeader
        }
        canvas.drawText(chart.title, marginLeft + 12f, startY + 16f, titlePaint)

        when (chart.type) {
            ReportChartType.BAR_COMPARISON -> drawBarChart(canvas, chart, startY + 22f, height - 28f)
            ReportChartType.HORIZONTAL_PROGRESS -> drawHorizontalProgressBarChart(canvas, chart, startY + 24f, height - 30f)
            ReportChartType.BREAKDOWN_DONUT -> drawBreakdownDonutChart(canvas, chart, startY + 20f, height - 26f)
            ReportChartType.ERROR_DISTRIBUTION -> drawErrorDistributionChart(canvas, chart, startY + 24f, height - 30f)
        }

        return startY + height + 12f
    }

    private fun drawBarChart(canvas: Canvas, chart: ReportChartData, plotY: Float, plotHeight: Float) {
        val count = chart.labels.size
        if (count == 0) return

        val plotWidth = contentWidth - 40f
        val barWidth = (plotWidth / count) * 0.45f
        val step = plotWidth / count
        val maxVal = maxOf(10f, chart.maxValue)

        val barColors = listOf(
            Color.parseColor("#0284C7"), // Sky Blue
            Color.parseColor("#059669"), // Emerald
            Color.parseColor("#7C3AED"), // Violet
            Color.parseColor("#D97706")  // Amber
        )

        val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 0.8f
        }
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            color = colorTextSecondary
            textAlign = Paint.Align.CENTER
        }
        val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorDarkHeader
            textAlign = Paint.Align.CENTER
        }

        // Base axis line
        val baseLineY = plotY + plotHeight - 16f
        canvas.drawLine(marginLeft + 20f, baseLineY, pageWidth - marginRight - 10f, baseLineY, gridPaint)

        for (i in 0 until count) {
            val label = chart.labels[i]
            val value = chart.values.getOrNull(i) ?: 0f
            val barHeight = ((value / maxVal) * (plotHeight - 34f)).coerceIn(2f, plotHeight - 34f)
            val barLeft = marginLeft + 24f + (i * step) + (step - barWidth) / 2f
            val barTop = baseLineY - barHeight

            val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = barColors[i % barColors.size]
            }
            val barRect = RectF(barLeft, barTop, barLeft + barWidth, baseLineY)
            canvas.drawRoundRect(barRect, 3f, 3f, barPaint)

            // Value text on top of bar
            canvas.drawText("${value.toInt()} ${chart.unit}".trim(), barLeft + barWidth / 2f, barTop - 4f, valPaint)

            // Label under axis
            canvas.drawText(label, barLeft + barWidth / 2f, baseLineY + 12f, textPaint)
        }
    }

    private fun drawHorizontalProgressBarChart(canvas: Canvas, chart: ReportChartData, plotY: Float, plotHeight: Float) {
        val count = chart.labels.size
        if (count == 0) return

        val barHeight = 12f
        val rowHeight = (plotHeight - 10f) / count
        val maxVal = maxOf(10f, chart.maxValue)
        val barMaxWidth = contentWidth - 140f

        val bgBarPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E2E8F0") }
        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorTextPrimary
        }
        val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8.5f
            color = colorTextSecondary
        }

        val barColors = listOf(
            Color.parseColor("#0284C7"),
            Color.parseColor("#10B981"),
            Color.parseColor("#8B5CF6")
        )

        for (i in 0 until count) {
            val curY = plotY + (i * rowHeight)
            val label = chart.labels[i]
            val value = chart.values.getOrNull(i) ?: 0f

            // Subject label
            canvas.drawText(label, marginLeft + 14f, curY + 10f, labelPaint)

            // Background bar
            val barLeft = marginLeft + 85f
            val bgRect = RectF(barLeft, curY, barLeft + barMaxWidth, curY + barHeight)
            canvas.drawRoundRect(bgRect, 4f, 4f, bgBarPaint)

            // Fill bar
            val fillWidth = ((value / maxVal) * barMaxWidth).coerceIn(0f, barMaxWidth)
            val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = barColors[i % barColors.size] }
            val fillRect = RectF(barLeft, curY, barLeft + fillWidth, curY + barHeight)
            canvas.drawRoundRect(fillRect, 4f, 4f, fillPaint)

            // Value text
            canvas.drawText("${value.toInt()}%", barLeft + barMaxWidth + 8f, curY + 10f, valPaint)
        }
    }

    private fun drawBreakdownDonutChart(canvas: Canvas, chart: ReportChartData, plotY: Float, plotHeight: Float) {
        val total = chart.values.sum().coerceAtLeast(1f)
        val colors = listOf(
            Color.parseColor("#10B981"), // Correct
            Color.parseColor("#EF4444"), // Incorrect
            Color.parseColor("#94A3B8")  // Skipped
        )

        val centerX = marginLeft + 75f
        val centerY = plotY + (plotHeight / 2f)
        val radius = 34f
        val stroke = 12f

        val arcRect = RectF(centerX - radius, centerY - radius, centerX + radius, centerY + radius)
        val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = stroke
        }

        var startAngle = -90f
        for (i in chart.values.indices) {
            val sweep = (chart.values[i] / total) * 360f
            if (sweep > 0.1f) {
                arcPaint.color = colors[i % colors.size]
                canvas.drawArc(arcRect, startAngle, sweep, false, arcPaint)
                startAngle += sweep
            }
        }

        // Center text: total attempted or correct %
        val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 10f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorDarkHeader
            textAlign = Paint.Align.CENTER
        }
        val correctCount = chart.values.firstOrNull()?.toInt() ?: 0
        val attemptedCount = (chart.values.getOrNull(0) ?: 0f) + (chart.values.getOrNull(1) ?: 0f)
        val acc = if (attemptedCount > 0) ((correctCount / attemptedCount) * 100).toInt() else 0
        canvas.drawText("$acc%", centerX, centerY + 3.5f, centerPaint)

        // Legend on right
        val legendLeft = marginLeft + 140f
        val legendPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8.5f
            color = colorTextPrimary
        }

        for (i in chart.labels.indices) {
            val legY = plotY + 12f + (i * 18f)
            val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = colors[i % colors.size]
            }
            canvas.drawCircle(legendLeft, legY - 3f, 4f, dotPaint)

            val valText = chart.values.getOrNull(i)?.toInt() ?: 0
            val pctText = ((chart.values.getOrNull(i) ?: 0f) / total * 100).toInt()
            canvas.drawText("${chart.labels[i]}: $valText ($pctText%)", legendLeft + 10f, legY, legendPaint)
        }
    }

    private fun drawErrorDistributionChart(canvas: Canvas, chart: ReportChartData, plotY: Float, plotHeight: Float) {
        val count = chart.labels.size
        if (count == 0) return

        val totalErrors = chart.values.sum().coerceAtLeast(1f)
        val barMaxWidth = contentWidth - 170f
        val rowHeight = (plotHeight - 10f) / count

        val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            color = colorTextPrimary
        }
        val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F59E0B")
        }
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#F1F5F9")
        }
        val valPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorDanger
        }

        for (i in 0 until count) {
            val curY = plotY + (i * rowHeight)
            val label = chart.labels[i]
            val value = chart.values.getOrNull(i) ?: 0f

            canvas.drawText(label, marginLeft + 14f, curY + 9f, labelPaint)

            val barLeft = marginLeft + 95f
            val bgRect = RectF(barLeft, curY, barLeft + barMaxWidth, curY + 10f)
            canvas.drawRoundRect(bgRect, 3f, 3f, bgPaint)

            val fillWidth = ((value / totalErrors) * barMaxWidth).coerceIn(0f, barMaxWidth)
            val fillRect = RectF(barLeft, curY, barLeft + fillWidth, curY + 10f)
            canvas.drawRoundRect(fillRect, 3f, 3f, barPaint)

            canvas.drawText("${value.toInt()} slips (-${value.toInt() * 5}M)", barLeft + barMaxWidth + 6f, curY + 9f, valPaint)
        }
    }

    private fun drawTableWithPagination(
        table: ReportTable,
        startCanvas: Canvas,
        startY: Float,
        onRequestNewPage: () -> Canvas,
        getCanvas: () -> Canvas
    ): Float {
        var canvas = startCanvas
        var currentY = startY

        val colCount = table.headers.size
        val weights = if (table.columnWeights.size == colCount) {
            table.columnWeights
        } else {
            List(colCount) { 1f }
        }
        val totalWeight = weights.sum()
        val colWidths = weights.map { (it / totalWeight) * contentWidth }

        fun drawTableHeader(c: Canvas, y: Float): Float {
            val headerHeight = 22f
            val bgRect = RectF(marginLeft, y, pageWidth - marginRight, y + headerHeight)
            val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorDarkHeader }
            c.drawRect(bgRect, bgPaint)

            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 8f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                color = Color.WHITE
            }

            var x = marginLeft
            for (i in 0 until colCount) {
                c.drawText(table.headers[i], x + 6f, y + 14f, textPaint)
                x += colWidths[i]
            }

            return y + headerHeight
        }

        // Table Title
        if (table.title.isNotBlank()) {
            val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 9.5f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                color = colorDarkHeader
            }
            canvas.drawText(table.title, marginLeft, currentY + 10f, titlePaint)
            currentY += 16f
        }

        // Draw First Header
        currentY = drawTableHeader(canvas, currentY)

        val rowTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8f
            color = colorTextPrimary
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 0.7f
        }
        val zebraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = colorZebra }

        for ((rIdx, row) in table.rows.withIndex()) {
            val maxLinesInRow = row.mapIndexed { cIdx, cellText ->
                wrapText(cellText, colWidths.getOrElse(cIdx) { 60f } - 10f, rowTextPaint).size
            }.maxOrNull() ?: 1

            val rowHeight = maxOf(18f, (maxLinesInRow * 11f) + 6f)

            if (currentY + rowHeight > pageHeight - marginBottom) {
                canvas = onRequestNewPage()
                currentY = drawTableHeader(canvas, marginTop + 24f)
            }

            if (rIdx % 2 == 1) {
                val zRect = RectF(marginLeft, currentY, pageWidth - marginRight, currentY + rowHeight)
                canvas.drawRect(zRect, zebraPaint)
            }

            // Cell text
            var x = marginLeft
            for (cIdx in 0 until colCount) {
                val cellText = row.getOrElse(cIdx) { "" }
                val lines = wrapText(cellText, colWidths[cIdx] - 10f, rowTextPaint)
                var lineY = currentY + 12f
                for (l in lines) {
                    canvas.drawText(l, x + 6f, lineY, rowTextPaint)
                    lineY += 10.5f
                }
                x += colWidths[cIdx]
            }

            canvas.drawLine(marginLeft, currentY + rowHeight, pageWidth - marginRight, currentY + rowHeight, borderPaint)
            currentY += rowHeight
        }

        // Footer row if present
        table.summaryFooterRow?.let { footer ->
            val footerHeight = 20f
            if (currentY + footerHeight > pageHeight - marginBottom) {
                canvas = onRequestNewPage()
                currentY = drawTableHeader(canvas, marginTop + 24f)
            }
            val footRect = RectF(marginLeft, currentY, pageWidth - marginRight, currentY + footerHeight)
            val footBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E2E8F0") }
            canvas.drawRect(footRect, footBg)

            val footPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 8f
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                color = colorDarkHeader
            }

            var x = marginLeft
            for (cIdx in 0 until colCount) {
                val txt = footer.getOrElse(cIdx) { "" }
                canvas.drawText(txt, x + 6f, currentY + 14f, footPaint)
                x += colWidths[cIdx]
            }
            currentY += footerHeight
        }

        return currentY + 12f
    }

    private fun drawBulletList(canvas: Canvas, heading: String, items: List<String>, startY: Float, bulletColor: Int): Float {
        var y = startY

        val headPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 9f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorDarkHeader
        }
        canvas.drawText(heading, marginLeft, y + 10f, headPaint)
        y += 16f

        val itemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8.5f
            color = colorTextSecondary
        }
        val bulletPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = bulletColor }

        for (item in items) {
            val lines = wrapText(item, contentWidth - 18f, itemPaint)
            canvas.drawCircle(marginLeft + 4f, y + 5f, 2.5f, bulletPaint)
            for (line in lines) {
                canvas.drawText(line, marginLeft + 12f, y + 8f, itemPaint)
                y += 11f
            }
            y += 3f
        }

        return y + 6f
    }

    private fun drawActionPlan(canvas: Canvas, actionItems: List<String>, startY: Float): Float {
        var y = startY

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 12f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorDarkHeader
        }
        canvas.drawText("Strategic Action Plan & Next Steps", marginLeft, y + 12f, titlePaint)
        y += 20f

        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E2E8F0")
            strokeWidth = 1f
        }
        canvas.drawLine(marginLeft, y, pageWidth - marginRight, y, linePaint)
        y += 10f

        val itemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8.5f
            color = colorTextPrimary
        }
        val numberPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 8.5f
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            color = colorPrimary
        }

        for ((idx, item) in actionItems.withIndex()) {
            val lines = wrapText(item, contentWidth - 24f, itemPaint)
            canvas.drawText("[${idx + 1}]", marginLeft, y + 9f, numberPaint)
            for (line in lines) {
                canvas.drawText(line, marginLeft + 20f, y + 9f, itemPaint)
                y += 12f
            }
            y += 4f
        }

        return y + 10f
    }

    private fun wrapText(text: String, maxWidth: Float, paint: Paint): List<String> {
        if (text.isBlank()) return emptyList()
        val words = text.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            if (paint.measureText(testLine) <= maxWidth) {
                currentLine = testLine
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine)
                }
                currentLine = word
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine)
        }
        return lines
    }
}
