package com.example.report.model

import com.example.data.model.Subject

enum class AnalysisPhase(
    val stepNumber: Int,
    val title: String,
    val shortDescription: String
) {
    FILE_READING(
        stepNumber = 1,
        title = "File Ingestion & Stream Reader",
        shortDescription = "Reading binary stream, verifying checksum, and allocating memory buffers"
    ),
    OCR_PARSING(
        stepNumber = 2,
        title = "Academic OCR & Question Extraction",
        shortDescription = "Extracting question stems, equations, diagrams, and MCQ option arrays"
    ),
    TAXONOMY_CLASSIFICATION(
        stepNumber = 3,
        title = "Taxonomy & Subject Classification",
        shortDescription = "Categorizing by Subject, Chapter, Topic, and Difficulty (Easy/Medium/Hard)"
    ),
    DEEP_DIAGNOSTICS(
        stepNumber = 4,
        title = "Diagnostic & Leakage Analysis",
        shortDescription = "Analyzing error patterns, conceptual gaps, and negative marking traps"
    ),
    REPORT_GENERATION(
        stepNumber = 5,
        title = "Document & Report Compilation",
        shortDescription = "Rendering vector charts, paginating tables, and compiling native PDF/XLSX"
    ),
    COMPLETED(
        stepNumber = 6,
        title = "Analysis Finalized",
        shortDescription = "Complete academic taxonomy and structured report ready for audit"
    ),
    FAILED(
        stepNumber = -1,
        title = "Analysis Interrupted",
        shortDescription = "An error occurred during the analysis pipeline"
    )
}

enum class PhaseStatus {
    PENDING,
    ACTIVE,
    COMPLETED,
    FAILED
}

data class PhaseProgressItem(
    val phase: AnalysisPhase,
    val status: PhaseStatus = PhaseStatus.PENDING,
    val progress: Float = 0f,
    val subtaskText: String = "",
    val details: String = "",
    val itemsProcessed: Int = 0,
    val totalItems: Int = 0,
    val durationMs: Long = 0L
)

enum class TelemetryLogLevel {
    INFO,
    SUCCESS,
    WARNING,
    METRIC
}

data class TelemetryLogEntry(
    val timestampMillis: Long = System.currentTimeMillis(),
    val level: TelemetryLogLevel = TelemetryLogLevel.INFO,
    val tag: String = "ENGINE",
    val message: String
)

data class ExtractedQuestionItem(
    val questionNumber: Int,
    val subject: Subject,
    val chapter: String,
    val topic: String,
    val difficulty: String, // "Easy", "Medium", "Hard"
    val type: String = "MCQ", // "MCQ", "Numerical", "Matrix Match"
    val optionsCount: Int = 4,
    val hasAnswerKey: Boolean = true,
    val identifiedConceptualTrap: String? = null
)

data class AnalysisResultSummary(
    val fileName: String,
    val fileSizeBytes: Long,
    val durationSeconds: Int,
    val totalQuestionsExtracted: Int,
    val physicsCount: Int,
    val chemistryCount: Int,
    val mathsCount: Int,
    val difficultyDistribution: Map<String, Int>,
    val weakTopicsIdentified: List<String>,
    val estimatedScoreLeakageMarks: Int,
    val generatedReportFile: GeneratedReportFile? = null
)

data class AnalysisProgressState(
    val id: String,
    val title: String,
    val sourceFileName: String,
    val sourceFileSizeFormatted: String,
    val currentPhase: AnalysisPhase = AnalysisPhase.FILE_READING,
    val phaseItems: List<PhaseProgressItem> = emptyList(),
    val overallProgress: Float = 0f,
    val elapsedSeconds: Int = 0,
    val estimatedSecondsRemaining: Int = 15,
    val currentSubtaskHeadline: String = "Initializing analysis pipeline...",
    val telemetryLogs: List<TelemetryLogEntry> = emptyList(),
    val extractedQuestionsPreview: List<ExtractedQuestionItem> = emptyList(),
    val isCancelled: Boolean = false,
    val isCompleted: Boolean = false,
    val isMinimized: Boolean = false,
    val errorMessage: String? = null,
    val resultSummary: AnalysisResultSummary? = null
)
