package com.example.report

import com.example.data.model.FocusSessionEntity
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.ScheduleSlot
import com.example.data.model.Subject
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.TopicState
import com.example.data.model.UserProfile
import com.example.data.model.WorkLogEntity
import com.example.report.model.ReportChartData
import com.example.report.model.ReportChartType
import com.example.report.model.ReportDocument
import com.example.report.model.ReportFormat
import com.example.report.model.ReportMetadata
import com.example.report.model.ReportSection
import com.example.report.model.ReportSummaryCard
import com.example.report.model.ReportTable
import com.example.report.model.ReportType
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportDataCollector(
    private val userProfile: UserProfile,
    private val tests: List<TestRecordEntity>,
    private val syllabusTopics: List<SyllabusTopicEntity>,
    private val missions: List<MissionEntity>,
    private val focusSessions: List<FocusSessionEntity>,
    private val workLogs: List<WorkLogEntity>,
    private val scheduleSlots: List<ScheduleSlot>
) {

    fun buildReport(
        reportType: ReportType,
        format: ReportFormat,
        specificTestId: Long? = null
    ): ReportDocument {
        val totalTests = tests.size
        val completedTopics = syllabusTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE }
        val syllabusProgress = if (syllabusTopics.isNotEmpty()) (completedTopics * 100) / syllabusTopics.size else 0
        val totalSessionMinutes = focusSessions.sumOf { it.actualDurationMinutes } + workLogs.sumOf { it.durationMinutes }
        val totalStudyHours = totalSessionMinutes / 60.0f

        val metadata = ReportMetadata(
            title = reportType.displayName.uppercase(),
            subtitle = "Verified Academic Audit • JEE Preparation Command Engine",
            targetExam = userProfile.targetExam.displayName,
            targetYear = userProfile.targetYear,
            targetRank = if (userProfile.targetRank.isNotBlank()) "AIR ${userProfile.targetRank}" else "Top 5000",
            totalTestsLogged = totalTests,
            syllabusProgressPercent = syllabusProgress,
            totalStudyHoursLogged = totalStudyHours
        )

        return when (reportType) {
            ReportType.TEST_ANALYSIS -> buildTestAnalysisReport(metadata, format, specificTestId)
            ReportType.MULTI_TEST_SUMMARY -> buildMultiTestReport(metadata, format)
            ReportType.SYLLABUS_MASTERY -> buildSyllabusReport(metadata, format)
            ReportType.WEAKNESS_AUDIT -> buildWeaknessReport(metadata, format)
            ReportType.REVISION_PRIORITIES -> buildRevisionReport(metadata, format)
            ReportType.COMPLETE_PERFORMANCE -> buildCompletePerformanceReport(metadata, format)
            ReportType.STUDY_HOURS_LOG -> buildStudyHoursReport(metadata, format)
        }
    }

    private fun buildTestAnalysisReport(
        metadata: ReportMetadata,
        format: ReportFormat,
        specificTestId: Long?
    ): ReportDocument {
        val targetTest = if (specificTestId != null) {
            tests.find { it.id == specificTestId } ?: tests.maxByOrNull { it.testDateEpochMs }
        } else {
            tests.maxByOrNull { it.testDateEpochMs }
        }

        if (targetTest == null) {
            return buildEmptyTestAnalysisReport(metadata, format)
        }

        val dateFormat = SimpleDateFormat("dd MMMM yyyy, HH:mm", Locale.getDefault())
        val testDateStr = dateFormat.format(Date(targetTest.testDateEpochMs))
        val marksLostIncorrect = targetTest.incorrect * 5 // 4 marks lost + 1 negative mark in JEE
        val marksLostSkipped = targetTest.skipped * 4
        val totalLeakage = marksLostIncorrect + marksLostSkipped

        val sections = mutableListOf<ReportSection>()

        // 1. Executive Test Overview
        sections.add(
            ReportSection(
                sectionNumber = 1,
                title = "Test Overview & Score Benchmark",
                subtitle = "${targetTest.testName} (${targetTest.examType.displayName}) • $testDateStr",
                summaryCards = listOf(
                    ReportSummaryCard(
                        title = "TOTAL SCORE",
                        value = "${targetTest.userScore} / ${targetTest.totalMarks}",
                        subtitle = "${((targetTest.userScore.toFloat() / targetTest.totalMarks) * 100).toInt()}% Marks",
                        colorHex = "#00E5FF"
                    ),
                    ReportSummaryCard(
                        title = "PERCENTILE",
                        value = "${String.format(Locale.US, "%.1f", targetTest.percentile)} %ile",
                        subtitle = "Projected Standing",
                        colorHex = "#10B981"
                    ),
                    ReportSummaryCard(
                        title = "ACCURACY",
                        value = "${targetTest.accuracy.toInt()}%",
                        subtitle = "${targetTest.correct} of ${targetTest.attempted} attempted",
                        colorHex = if (targetTest.accuracy >= 80) "#10B981" else "#F59E0B"
                    ),
                    ReportSummaryCard(
                        title = "SCORE LEAKAGE",
                        value = "-$marksLostIncorrect M",
                        subtitle = "Lost from ${targetTest.incorrect} negatives",
                        colorHex = "#EF4444"
                    )
                ),
                charts = listOf(
                    ReportChartData(
                        title = "Subject Score Distribution",
                        type = ReportChartType.BAR_COMPARISON,
                        labels = listOf("Physics", "Chemistry", "Mathematics"),
                        values = listOf(targetTest.physicsScore.toFloat(), targetTest.chemistryScore.toFloat(), targetTest.mathsScore.toFloat()),
                        maxValue = 100f,
                        unit = "Marks"
                    )
                ),
                tables = listOf(
                    ReportTable(
                        title = "Score & Subject Metrics",
                        headers = listOf("Subject", "Marks Obtained", "Max Marks", "Contribution %", "Status"),
                        rows = listOf(
                            listOf("Physics", "${targetTest.physicsScore}", "100", "${if (targetTest.userScore > 0) (targetTest.physicsScore * 100) / targetTest.userScore else 0}%", if (targetTest.physicsScore >= 60) "Strong" else "Needs Work"),
                            listOf("Chemistry", "${targetTest.chemistryScore}", "100", "${if (targetTest.userScore > 0) (targetTest.chemistryScore * 100) / targetTest.userScore else 0}%", if (targetTest.chemistryScore >= 60) "Strong" else "Needs Work"),
                            listOf("Mathematics", "${targetTest.mathsScore}", "100", "${if (targetTest.userScore > 0) (targetTest.mathsScore * 100) / targetTest.userScore else 0}%", if (targetTest.mathsScore >= 60) "Strong" else "Needs Work"),
                            listOf("Total / Aggregate", "${targetTest.userScore}", "${targetTest.totalMarks}", "100%", if (targetTest.userScore >= 180) "Competitive" else "Below Target")
                        ),
                        columnWeights = listOf(2f, 1.2f, 1.2f, 1.2f, 1.4f)
                    )
                ),
                observations = listOf(
                    "Total examination duration logged: ${targetTest.timeSpentMinutes} minutes.",
                    "Average time per attempted question: ${if (targetTest.attempted > 0) targetTest.timeSpentMinutes / targetTest.attempted else 0} minutes.",
                    "Potential marks if negatives were eliminated: ${targetTest.userScore + targetTest.incorrect} / ${targetTest.totalMarks}."
                )
            )
        )

        // 2. Question Attempt & Accuracy Breakdown
        sections.add(
            ReportSection(
                sectionNumber = 2,
                title = "Attempt & Accuracy Analysis",
                subtitle = "Categorization of Question Handling",
                summaryCards = listOf(
                    ReportSummaryCard(title = "ATTEMPTED", value = "${targetTest.attempted}", subtitle = "Questions handled", colorHex = "#38BDF8"),
                    ReportSummaryCard(title = "CORRECT", value = "${targetTest.correct}", subtitle = "+${targetTest.correct * 4} Marks", colorHex = "#10B981"),
                    ReportSummaryCard(title = "INCORRECT", value = "${targetTest.incorrect}", subtitle = "-${targetTest.incorrect} Negative", colorHex = "#EF4444"),
                    ReportSummaryCard(title = "SKIPPED", value = "${targetTest.skipped}", subtitle = "Unattempted items", colorHex = "#94A3B8")
                ),
                charts = listOf(
                    ReportChartData(
                        title = "Question Attempt Breakdown",
                        type = ReportChartType.BREAKDOWN_DONUT,
                        labels = listOf("Correct", "Incorrect", "Skipped"),
                        values = listOf(targetTest.correct.toFloat(), targetTest.incorrect.toFloat(), targetTest.skipped.toFloat()),
                        unit = "Q"
                    )
                ),
                tables = listOf(
                    ReportTable(
                        title = "Attempt Diagnostics",
                        headers = listOf("Metric", "Count", "Percentage of Paper", "Score Impact"),
                        rows = listOf(
                            listOf("Correct Answers", "${targetTest.correct}", "${if (targetTest.attempted + targetTest.skipped > 0) (targetTest.correct * 100) / (targetTest.attempted + targetTest.skipped) else 0}%", "+${targetTest.correct * 4} Marks"),
                            listOf("Incorrect Answers (Negatives)", "${targetTest.incorrect}", "${if (targetTest.attempted + targetTest.skipped > 0) (targetTest.incorrect * 100) / (targetTest.attempted + targetTest.skipped) else 0}%", "-${marksLostIncorrect} Marks Lost (Inc. Negatives)"),
                            listOf("Skipped / Left Unattempted", "${targetTest.skipped}", "${if (targetTest.attempted + targetTest.skipped > 0) (targetTest.skipped * 100) / (targetTest.attempted + targetTest.skipped) else 0}%", "0 Impact (${marksLostSkipped} Untapped Potential)")
                        )
                    )
                )
            )
        )

        // 3. Error Classification & Score Leakage
        val hasErrorTaxonomy = targetTest.conceptualErrors > 0 || targetTest.calculationErrors > 0 ||
                targetTest.sillyMistakes > 0 || targetTest.formulaRecallErrors > 0 ||
                targetTest.timePressureErrors > 0 || targetTest.guessErrors > 0 || targetTest.knewButMissedErrors > 0

        val errorRows = mutableListOf<List<String>>()
        if (targetTest.conceptualErrors > 0) errorRows.add(listOf("Conceptual Error", "${targetTest.conceptualErrors}", "-${targetTest.conceptualErrors * 5}", "Theory gap / unmastered fundamental definition"))
        if (targetTest.calculationErrors > 0) errorRows.add(listOf("Calculation Error", "${targetTest.calculationErrors}", "-${targetTest.calculationErrors * 5}", "Arithmetic slip, algebra transposition, unit conversion"))
        if (targetTest.sillyMistakes > 0) errorRows.add(listOf("Silly Mistake", "${targetTest.sillyMistakes}", "-${targetTest.sillyMistakes * 5}", "Misread question stem / sign flip / bubble marking"))
        if (targetTest.formulaRecallErrors > 0) errorRows.add(listOf("Formula Recall Error", "${targetTest.formulaRecallErrors}", "-${targetTest.formulaRecallErrors * 5}", "Forgot formula or applied incorrect variant"))
        if (targetTest.timePressureErrors > 0) errorRows.add(listOf("Time Pressure Slip", "${targetTest.timePressureErrors}", "-${targetTest.timePressureErrors * 5}", "Rushed execution in final minutes of slot"))
        if (targetTest.guessErrors > 0) errorRows.add(listOf("Unjustified Guess", "${targetTest.guessErrors}", "-${targetTest.guessErrors * 5}", "Wild speculation with low statistical confidence"))
        if (targetTest.knewButMissedErrors > 0) errorRows.add(listOf("Knew But Missed", "${targetTest.knewButMissedErrors}", "-${targetTest.knewButMissedErrors * 5}", "Hesitation or abandoned solvable problem"))

        if (errorRows.isEmpty()) {
            errorRows.add(listOf("Uncategorized Negatives", "${targetTest.incorrect}", "-${targetTest.incorrect * 5}", "Review each incorrect problem individually"))
        }

        sections.add(
            ReportSection(
                sectionNumber = 3,
                title = "Error Taxonomy & Score Leakage",
                subtitle = "Where Marks Were Left on the Table",
                charts = if (hasErrorTaxonomy) listOf(
                    ReportChartData(
                        title = "Mistake Category Distribution",
                        type = ReportChartType.ERROR_DISTRIBUTION,
                        labels = listOf("Conceptual", "Calculation", "Silly", "Formula", "Time Pressure"),
                        values = listOf(
                            targetTest.conceptualErrors.toFloat(),
                            targetTest.calculationErrors.toFloat(),
                            targetTest.sillyMistakes.toFloat(),
                            targetTest.formulaRecallErrors.toFloat(),
                            targetTest.timePressureErrors.toFloat()
                        ),
                        unit = "Mistakes"
                    )
                ) else emptyList(),
                tables = listOf(
                    ReportTable(
                        title = "Granular Error Audit",
                        headers = listOf("Error Type", "Frequency", "Marks Lost", "Diagnostic Cause"),
                        rows = errorRows,
                        summaryFooterRow = listOf("Total Leakage", "${targetTest.incorrect}", "-$marksLostIncorrect Marks", "Negatives & preventable slips")
                    )
                ),
                observations = listOf(
                    "Score leakage accounted for $marksLostIncorrect marks directly lost from wrong choices.",
                    if (targetTest.calculationErrors + targetTest.sillyMistakes > 0) "Immediate actionable gain: Recovering silly & calculation slips adds +${(targetTest.calculationErrors + targetTest.sillyMistakes) * 5} marks instantly." else "Negatives were predominantly conceptual."
                )
            )
        )

        // 4. Weak Chapters & Evidence
        val weakChaptersList = if (targetTest.weakChaptersIdentified.isNotBlank()) {
            targetTest.weakChaptersIdentified.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            syllabusTopics.filter { it.isWeakArea || it.state == TopicState.WEAK }.map { it.chapter }.distinct()
        }

        val chapterTableRows = weakChaptersList.mapIndexed { idx, chap ->
            val matchingTopics = syllabusTopics.filter { it.chapter.equals(chap, ignoreCase = true) }
            val avgAcc = if (matchingTopics.isNotEmpty()) matchingTopics.map { it.testAccuracyPercent }.average().toInt() else targetTest.accuracy.toInt()
            val pyqs = matchingTopics.sumOf { it.pyqsAttempted }
            listOf("${idx + 1}", chap, "$avgAcc%", "$pyqs PYQs", "High Priority Weakness")
        }

        if (chapterTableRows.isNotEmpty()) {
            sections.add(
                ReportSection(
                    sectionNumber = 4,
                    title = "Weak Chapters & Evidence",
                    subtitle = "Identified Deficits from Test Execution",
                    tables = listOf(
                        ReportTable(
                            title = "High Risk Chapters from This Test",
                            headers = listOf("#", "Chapter Name", "Topic Accuracy", "Logged PYQs", "Urgency"),
                            rows = chapterTableRows
                        )
                    )
                )
            )
        }

        // 5. Tactical Recommendations & Next Actions
        val actionItems = mutableListOf<String>()
        if (targetTest.sillyMistakes > 0 || targetTest.calculationErrors > 0) {
            actionItems.add("Implement scratchpad rough-work discipline: Box final answers and write steps vertically to eliminate ${(targetTest.sillyMistakes + targetTest.calculationErrors) * 5} marks of silly errors.")
        }
        if (targetTest.conceptualErrors > 0) {
            actionItems.add("Schedule high-intensity review on ${weakChaptersList.take(2).joinToString(", ").ifBlank { "flagged conceptual gaps" }} within 48 hours.")
        }
        if (targetTest.accuracy < 75) {
            actionItems.add("Enforce negative-marking filter: Never guess on 50/50 questions unless you can definitively eliminate 2 options with mathematical proof.")
        }
        actionItems.add("Solve 30 PYQs under timed 45-minute sprint for each identified weak chapter.")
        actionItems.add("Re-test the same error set in 7 days to verify zero-recurrence.")

        return ReportDocument(
            metadata = metadata,
            reportType = ReportType.TEST_ANALYSIS,
            format = format,
            executiveSummary = "Performance audit for ${targetTest.testName} reveals an overall score of ${targetTest.userScore}/${targetTest.totalMarks} (${targetTest.accuracy.toInt()}% accuracy). Total preventable score leakage from wrong answers is -$marksLostIncorrect marks. Addressing calculation precision and conceptual review in ${weakChaptersList.take(2).joinToString(", ").ifBlank { "flagged chapters" }} represents the highest ROI leverage for the next mock.",
            sections = sections,
            actionPlan = actionItems
        )
    }

    private fun buildMultiTestReport(
        metadata: ReportMetadata,
        format: ReportFormat
    ): ReportDocument {
        if (tests.isEmpty()) {
            return buildEmptyTestAnalysisReport(metadata, format)
        }

        val sortedTests = tests.sortedBy { it.testDateEpochMs }
        val avgScore = sortedTests.map { it.userScore }.average().toInt()
        val peakScore = sortedTests.maxOf { it.userScore }
        val avgAccuracy = sortedTests.map { it.accuracy }.average().toInt()
        val totalErrors = sortedTests.sumOf { it.incorrect }

        val sections = mutableListOf<ReportSection>()

        // 1. Benchmark Trends
        sections.add(
            ReportSection(
                sectionNumber = 1,
                title = "Multi-Test Performance Benchmark",
                subtitle = "Aggregated Analysis Across ${sortedTests.size} Mock Tests",
                summaryCards = listOf(
                    ReportSummaryCard(title = "AVERAGE SCORE", value = "$avgScore / 300", subtitle = "Across ${sortedTests.size} tests", colorHex = "#00E5FF"),
                    ReportSummaryCard(title = "PEAK SCORE", value = "$peakScore / 300", subtitle = "Personal record", colorHex = "#10B981"),
                    ReportSummaryCard(title = "AVG ACCURACY", value = "$avgAccuracy%", subtitle = "Attempt precision", colorHex = "#38BDF8"),
                    ReportSummaryCard(title = "TOTAL ERRORS", value = "$totalErrors", subtitle = "Logged negatives", colorHex = "#EF4444")
                ),
                charts = listOf(
                    ReportChartData(
                        title = "Score Trajectory Across Mock Tests",
                        type = ReportChartType.BAR_COMPARISON,
                        labels = sortedTests.takeLast(6).map { it.testName.take(12) },
                        values = sortedTests.takeLast(6).map { it.userScore.toFloat() },
                        maxValue = 300f,
                        unit = "Marks"
                    )
                ),
                tables = listOf(
                    ReportTable(
                        title = "Historical Mock Test Records",
                        headers = listOf("Test Name", "Exam", "Score / 300", "Accuracy", "P", "C", "M", "Percentile"),
                        rows = sortedTests.map { t ->
                            listOf(
                                t.testName,
                                t.examType.displayName,
                                "${t.userScore}",
                                "${t.accuracy.toInt()}%",
                                "${t.physicsScore}",
                                "${t.chemistryScore}",
                                "${t.mathsScore}",
                                "${String.format(Locale.US, "%.1f", t.percentile)}%"
                            )
                        }
                    )
                )
            )
        )

        // 2. Aggregated Error Patterns
        val totalConcept = sortedTests.sumOf { it.conceptualErrors }
        val totalCalc = sortedTests.sumOf { it.calculationErrors }
        val totalSilly = sortedTests.sumOf { it.sillyMistakes }
        val totalFormula = sortedTests.sumOf { it.formulaRecallErrors }
        val totalTime = sortedTests.sumOf { it.timePressureErrors }

        sections.add(
            ReportSection(
                sectionNumber = 2,
                title = "Cumulative Error Diagnostics",
                subtitle = "Longitudinal Mistake Distribution",
                charts = listOf(
                    ReportChartData(
                        title = "Cumulative Mistake Distribution",
                        type = ReportChartType.ERROR_DISTRIBUTION,
                        labels = listOf("Conceptual", "Calculation", "Silly", "Formula", "Time Pressure"),
                        values = listOf(totalConcept.toFloat(), totalCalc.toFloat(), totalSilly.toFloat(), totalFormula.toFloat(), totalTime.toFloat()),
                        unit = "Mistakes"
                    )
                ),
                tables = listOf(
                    ReportTable(
                        title = "Multi-Test Error Frequency",
                        headers = listOf("Mistake Category", "Total Count", "Est. Score Loss", "Intervention Priority"),
                        rows = listOf(
                            listOf("Conceptual Gaps", "$totalConcept", "-${totalConcept * 5} M", if (totalConcept >= 5) "High Priority" else "Normal"),
                            listOf("Calculation Errors", "$totalCalc", "-${totalCalc * 5} M", if (totalCalc >= 5) "High Priority" else "Normal"),
                            listOf("Silly Mistakes / Reading", "$totalSilly", "-${totalSilly * 5} M", if (totalSilly >= 5) "High Priority" else "Normal"),
                            listOf("Formula Recall Failures", "$totalFormula", "-${totalFormula * 5} M", if (totalFormula >= 3) "Medium Priority" else "Low"),
                            listOf("Time Pressure Slips", "$totalTime", "-${totalTime * 5} M", if (totalTime >= 3) "Medium Priority" else "Low")
                        )
                    )
                )
            )
        )

        return ReportDocument(
            metadata = metadata,
            reportType = ReportType.MULTI_TEST_SUMMARY,
            format = format,
            executiveSummary = "Across ${sortedTests.size} recorded mock exams, test scores averaged $avgScore/300 with an apex of $peakScore/300. Overall attempt accuracy stands at $avgAccuracy%. Cumulative score leakage across tests stands at approximately -${totalErrors * 5} marks, dominated by ${if (totalConcept >= totalCalc) "conceptual deficits" else "calculation slips"}.",
            sections = sections,
            actionPlan = listOf(
                "Maintain score trend stability above $avgScore in the next 3 consecutive mock tests.",
                "Dedicate 1 weekly review session exclusively to recalculating all past test negative questions without solution references.",
                "Target a reduction of silly & calculation errors below 3 per test."
            )
        )
    }

    private fun buildSyllabusReport(
        metadata: ReportMetadata,
        format: ReportFormat
    ): ReportDocument {
        val total = syllabusTopics.size
        val strong = syllabusTopics.count { it.state == TopicState.STRONG }
        val learning = syllabusTopics.count { it.state == TopicState.LEARNING }
        val needsRevision = syllabusTopics.count { it.state == TopicState.NEEDS_REVISION }
        val weak = syllabusTopics.count { it.state == TopicState.WEAK || it.isWeakArea }
        val notStarted = syllabusTopics.count { it.state == TopicState.NOT_STARTED }

        val physicsTopics = syllabusTopics.filter { it.subject == Subject.PHYSICS }
        val chemistryTopics = syllabusTopics.filter { it.subject == Subject.CHEMISTRY }
        val mathsTopics = syllabusTopics.filter { it.subject == Subject.MATHEMATICS }

        val pCompleted = physicsTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE }
        val cCompleted = chemistryTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE }
        val mCompleted = mathsTopics.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE }

        val pPct = if (physicsTopics.isNotEmpty()) (pCompleted * 100) / physicsTopics.size else 0
        val cPct = if (chemistryTopics.isNotEmpty()) (cCompleted * 100) / chemistryTopics.size else 0
        val mPct = if (mathsTopics.isNotEmpty()) (mCompleted * 100) / mathsTopics.size else 0

        val sections = mutableListOf<ReportSection>()

        // 1. Mastery Overview
        sections.add(
            ReportSection(
                sectionNumber = 1,
                title = "Syllabus Progression & Completion",
                subtitle = "Status Audit for ${userProfile.targetExam.displayName} (${userProfile.targetYear})",
                summaryCards = listOf(
                    ReportSummaryCard(title = "OVERALL PROGRESS", value = "${metadata.syllabusProgressPercent}%", subtitle = "$strong strong of $total topics", colorHex = "#00E5FF"),
                    ReportSummaryCard(title = "PHYSICS", value = "$pPct%", subtitle = "$pCompleted / ${physicsTopics.size} topics", colorHex = "#38BDF8"),
                    ReportSummaryCard(title = "CHEMISTRY", value = "$cPct%", subtitle = "$cCompleted / ${chemistryTopics.size} topics", colorHex = "#34D399"),
                    ReportSummaryCard(title = "MATHEMATICS", value = "$mPct%", subtitle = "$mCompleted / ${mathsTopics.size} topics", colorHex = "#A78BFA")
                ),
                charts = listOf(
                    ReportChartData(
                        title = "Subject Syllabus Coverage (%)",
                        type = ReportChartType.HORIZONTAL_PROGRESS,
                        labels = listOf("Physics", "Chemistry", "Mathematics"),
                        values = listOf(pPct.toFloat(), cPct.toFloat(), mPct.toFloat()),
                        maxValue = 100f,
                        unit = "%"
                    ),
                    ReportChartData(
                        title = "Topic State Breakdown",
                        type = ReportChartType.BREAKDOWN_DONUT,
                        labels = listOf("Strong", "Learning", "Needs Revision", "Weak", "Not Started"),
                        values = listOf(strong.toFloat(), learning.toFloat(), needsRevision.toFloat(), weak.toFloat(), notStarted.toFloat()),
                        unit = "Topics"
                    )
                ),
                tables = listOf(
                    ReportTable(
                        title = "Syllabus Topic State Registry",
                        headers = listOf("State Category", "Topic Count", "Proportion %", "Action Required"),
                        rows = listOf(
                            listOf("Strong (Exam Ready)", "$strong", "${if (total > 0) (strong * 100) / total else 0}%", "Light spaced repetition only"),
                            listOf("Learning (In Progress)", "$learning", "${if (total > 0) (learning * 100) / total else 0}%", "Complete PYQs and concept notes"),
                            listOf("Needs Revision", "$needsRevision", "${if (total > 0) (needsRevision * 100) / total else 0}%", "Formula sheets and high-yield problems"),
                            listOf("Weak / High Risk", "$weak", "${if (total > 0) (weak * 100) / total else 0}%", "Root-cause diagnostics & theory rework"),
                            listOf("Not Started (Backlog)", "$notStarted", "${if (total > 0) (notStarted * 100) / total else 0}%", "Time-block in upcoming weekly cycles")
                        )
                    )
                )
            )
        )

        // 2. Chapter-wise Detailed Breakdown
        val chaptersGrouped = syllabusTopics.groupBy { "${it.subject.displayName} - ${it.chapter}" }
        val chapterRows = chaptersGrouped.map { (chapKey, tList) ->
            val done = tList.count { it.state == TopicState.STRONG || it.state == TopicState.COMPLETED_ONCE }
            val pct = (done * 100) / tList.size
            val avgConf = tList.map { it.confidenceScore }.average().toInt()
            val pyqs = tList.sumOf { it.pyqsAttempted }
            listOf(chapKey, "${tList.size}", "$pct%", "$avgConf%", "$pyqs PYQs", if (pct >= 80) "Ready" else if (pct >= 50) "Moderate" else "Deficit")
        }

        sections.add(
            ReportSection(
                sectionNumber = 2,
                title = "Chapter-Wise Mastery Breakdown",
                subtitle = "Granular Status Across High Yield Units",
                tables = listOf(
                    ReportTable(
                        title = "Chapter Coverage & PYQ Volume",
                        headers = listOf("Subject - Chapter", "Topics", "Completion", "Confidence", "PYQs Solved", "Readiness"),
                        rows = chapterRows.take(35) // Ensure clean pagination
                    )
                )
            )
        )

        return ReportDocument(
            metadata = metadata,
            reportType = ReportType.SYLLABUS_MASTERY,
            format = format,
            executiveSummary = "Syllabus readiness currently stands at ${metadata.syllabusProgressPercent}% overall (Physics: $pPct%, Chemistry: $cPct%, Mathematics: $mPct%). $strong topics are verified as Strong, with $weak topics requiring immediate remediation.",
            sections = sections,
            actionPlan = listOf(
                "Prioritize closing chapters with < 50% completion before commencing full-syllabus mock tests.",
                "Target at least 25 PYQs per chapter for all units in 'Learning' state.",
                "Schedule a 2-hour revision block for all $needsRevision topics marked as 'Needs Revision'."
            )
        )
    }

    private fun buildWeaknessReport(
        metadata: ReportMetadata,
        format: ReportFormat
    ): ReportDocument {
        val weakTopics = syllabusTopics.filter { it.isWeakArea || it.state == TopicState.WEAK || it.state == TopicState.NEEDS_REVISION }
        val weakChaptersFromTests = tests.flatMap { it.weakChaptersIdentified.split(",") }
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .groupingBy { it }
            .eachCount()

        val sections = mutableListOf<ReportSection>()

        sections.add(
            ReportSection(
                sectionNumber = 1,
                title = "Weakness & Error Diagnostics",
                subtitle = "Consolidated Critical Risk Areas",
                summaryCards = listOf(
                    ReportSummaryCard(title = "CRITICAL TOPICS", value = "${weakTopics.size}", subtitle = "Flagged in syllabus", colorHex = "#EF4444"),
                    ReportSummaryCard(title = "TEST WEAK CHAPTERS", value = "${weakChaptersFromTests.size}", subtitle = "Failed under timed pressure", colorHex = "#F59E0B"),
                    ReportSummaryCard(title = "AVERAGE CONFIDENCE", value = "${if (weakTopics.isNotEmpty()) weakTopics.map { it.confidenceScore }.average().toInt() else 0}%", subtitle = "On weak topics", colorHex = "#38BDF8"),
                    ReportSummaryCard(title = "PYQ DEFICIT", value = "${weakTopics.sumOf { it.pyqsAttempted }}", subtitle = "PYQs completed", colorHex = "#A78BFA")
                ),
                tables = listOf(
                    ReportTable(
                        title = "Weak Topics Priority Register",
                        headers = listOf("Subject", "Chapter", "Topic Name", "State", "Confidence", "Test Accuracy"),
                        rows = weakTopics.map { t ->
                            listOf(t.subject.displayName, t.chapter, t.topicName, t.state.displayName, "${t.confidenceScore}%", "${t.testAccuracyPercent}%")
                        }.ifEmpty {
                            listOf(listOf("None", "No weak topics explicitly flagged", "All topics are currently at passing status", "-", "-", "-"))
                        }
                    ),
                    ReportTable(
                        title = "Chapters Repeatedly Identified in Test Failures",
                        headers = listOf("Chapter", "Test Appearance Frequency", "Impact Severity", "Recommended Intervention"),
                        rows = weakChaptersFromTests.map { (chap, count) ->
                            listOf(chap, "$count tests", if (count >= 2) "Severe (Recurring)" else "Moderate", "Theory recap + 20 standard PYQs")
                        }.ifEmpty {
                            listOf(listOf("No test weaknesses recorded", "0", "Low", "Log mock tests to surface real-time pressure weaknesses"))
                        }
                    )
                )
            )
        )

        return ReportDocument(
            metadata = metadata,
            reportType = ReportType.WEAKNESS_AUDIT,
            format = format,
            executiveSummary = "Diagnostic audit identified ${weakTopics.size} critical topics and ${weakChaptersFromTests.size} test-evidenced weak chapters. Addressing these focal points represents the fastest route to recovering leaked marks.",
            sections = sections,
            actionPlan = listOf(
                "Execute surgical 45-minute revision sprints on the top 3 recurring weak chapters.",
                "Review foundational lecture notes for topics with < 40% confidence.",
                "Solve 15 moderate-level PYQs per weak chapter with untimed focus before re-attempting in mocks."
            )
        )
    }

    private fun buildRevisionReport(
        metadata: ReportMetadata,
        format: ReportFormat
    ): ReportDocument {
        val revisionCandidates = syllabusTopics.filter {
            it.state == TopicState.NEEDS_REVISION ||
                    it.state == TopicState.COMPLETED_ONCE ||
                    it.isWeakArea ||
                    (it.lastStudiedEpochMs != null && System.currentTimeMillis() - it.lastStudiedEpochMs > 14 * 86400000L)
        }

        val sections = mutableListOf<ReportSection>()

        sections.add(
            ReportSection(
                sectionNumber = 1,
                title = "Tactical Revision & Spaced Repetition Queue",
                subtitle = "High-Yield Topics Requiring Immediate Retention Refresh",
                summaryCards = listOf(
                    ReportSummaryCard(title = "QUEUE SIZE", value = "${revisionCandidates.size}", subtitle = "Topics due for revision", colorHex = "#00E5FF"),
                    ReportSummaryCard(title = "HIGH WEIGHTAGE", value = "${revisionCandidates.count { it.subject == Subject.PHYSICS }}", subtitle = "Physics units", colorHex = "#38BDF8"),
                    ReportSummaryCard(title = "CHEMISTRY", value = "${revisionCandidates.count { it.subject == Subject.CHEMISTRY }}", subtitle = "Inorganic/Organic units", colorHex = "#34D399"),
                    ReportSummaryCard(title = "MATHEMATICS", value = "${revisionCandidates.count { it.subject == Subject.MATHEMATICS }}", subtitle = "Calculus/Algebra units", colorHex = "#A78BFA")
                ),
                tables = listOf(
                    ReportTable(
                        title = "Prioritized Revision Schedule",
                        headers = listOf("Priority", "Subject", "Chapter", "Topic", "Confidence", "Action"),
                        rows = revisionCandidates.take(30).mapIndexed { idx, t ->
                            listOf(
                                "#${idx + 1}",
                                t.subject.displayName,
                                t.chapter,
                                t.topicName,
                                "${t.confidenceScore}%",
                                "Formula Sheet + 10 PYQs"
                            )
                        }.ifEmpty {
                            listOf(listOf("#1", "All Subjects", "Syllabus Up to Date", "No pending revision backlogs", "100%", "Maintain regular mock test cycle"))
                        }
                    )
                )
            )
        )

        return ReportDocument(
            metadata = metadata,
            reportType = ReportType.REVISION_PRIORITIES,
            format = format,
            executiveSummary = "Revision queue contains ${revisionCandidates.size} topics due for spaced repetition. Regular active recall and formula rehearsal on these topics prevents knowledge decay before final examinations.",
            sections = sections,
            actionPlan = listOf(
                "Allocate the first 60 minutes of daily study solely to the Revision Queue.",
                "Use blank-sheet recall for organic chemistry reactions and physics formulas.",
                "Update topic status to 'Strong' only after scoring >= 80% on a 15-question mini-quiz."
            )
        )
    }

    private fun buildCompletePerformanceReport(
        metadata: ReportMetadata,
        format: ReportFormat
    ): ReportDocument {
        // Full 360-degree synthesis
        val testSection = buildTestAnalysisReport(metadata, format, null).sections.firstOrNull()
        val syllabusSection = buildSyllabusReport(metadata, format).sections.firstOrNull()
        val weaknessSection = buildWeaknessReport(metadata, format).sections.firstOrNull()
        val studySection = buildStudyHoursReport(metadata, format).sections.firstOrNull()

        val allSections = listOfNotNull(testSection, syllabusSection, weaknessSection, studySection)
            .mapIndexed { idx, sec -> sec.copy(sectionNumber = idx + 1) }

        return ReportDocument(
            metadata = metadata,
            reportType = ReportType.COMPLETE_PERFORMANCE,
            format = format,
            executiveSummary = "Complete JEE Core Performance Dossier: Syllabus coverage is ${metadata.syllabusProgressPercent}%, with ${metadata.totalTestsLogged} mock tests logged and ${String.format(Locale.US, "%.1f", metadata.totalStudyHoursLogged)} total focused study hours. Strategic alignment targets peak execution for ${metadata.targetExam} (${metadata.targetYear}).",
            sections = allSections,
            actionPlan = listOf(
                "Consistently adhere to scheduled study blocks with minimum 5 hours on weekdays and 9 hours on weekends.",
                "Keep score leakage in mock tests below 15 marks by eliminating calculation and reading slips.",
                "Target full completion of syllabus topics currently in 'Learning' state within the next 4 weeks."
            )
        )
    }

    private fun buildStudyHoursReport(
        metadata: ReportMetadata,
        format: ReportFormat
    ): ReportDocument {
        val totalSessionMinutes = focusSessions.sumOf { it.actualDurationMinutes }
        val totalWorkLogMinutes = workLogs.sumOf { it.durationMinutes }
        val totalMins = totalSessionMinutes + totalWorkLogMinutes
        val totalHours = totalMins / 60.0f
        val completedMissions = missions.count { it.status == MissionStatus.COMPLETED }

        val subjectMinutes = mutableMapOf<Subject, Int>()
        focusSessions.forEach { s ->
            subjectMinutes[s.subject] = (subjectMinutes[s.subject] ?: 0) + s.actualDurationMinutes
        }
        workLogs.forEach { w ->
            subjectMinutes[w.subject] = (subjectMinutes[w.subject] ?: 0) + w.durationMinutes
        }

        val pMins = subjectMinutes[Subject.PHYSICS] ?: 0
        val cMins = subjectMinutes[Subject.CHEMISTRY] ?: 0
        val mMins = subjectMinutes[Subject.MATHEMATICS] ?: 0

        val sections = mutableListOf<ReportSection>()

        sections.add(
            ReportSection(
                sectionNumber = 1,
                title = "Study Hours & Focus Analytics",
                subtitle = "Detailed Timesheet and Task Adherence",
                summaryCards = listOf(
                    ReportSummaryCard(title = "TOTAL STUDY TIME", value = "${String.format(Locale.US, "%.1f", totalHours)} Hrs", subtitle = "$totalMins minutes logged", colorHex = "#00E5FF"),
                    ReportSummaryCard(title = "FOCUS SESSIONS", value = "${focusSessions.size}", subtitle = "Timed Pomodoro blocks", colorHex = "#38BDF8"),
                    ReportSummaryCard(title = "TASKS COMPLETED", value = "$completedMissions", subtitle = "Missions finalized", colorHex = "#10B981"),
                    ReportSummaryCard(title = "SCHEDULE SLOTS", value = "${scheduleSlots.count { it.isCompleted }} / ${scheduleSlots.size}", subtitle = "Daily routine adherence", colorHex = "#F59E0B")
                ),
                charts = listOf(
                    ReportChartData(
                        title = "Study Time by Subject (Hours)",
                        type = ReportChartType.BAR_COMPARISON,
                        labels = listOf("Physics", "Chemistry", "Mathematics"),
                        values = listOf(pMins / 60.0f, cMins / 60.0f, mMins / 60.0f),
                        maxValue = maxOf(10f, (totalHours + 2)),
                        unit = "Hrs"
                    )
                ),
                tables = listOf(
                    ReportTable(
                        title = "Recent Focus & Work Log History",
                        headers = listOf("Date", "Subject", "Chapter / Task", "Duration", "Questions"),
                        rows = focusSessions.take(15).map { s ->
                            val dateStr = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(s.startTimeEpochMs))
                            listOf(dateStr, s.subject.displayName, s.chapter.ifBlank { s.topic }, "${s.actualDurationMinutes} mins", "${s.questionsCompleted} Qs")
                        }.ifEmpty {
                            listOf(listOf("No sessions yet", "-", "-", "0 mins", "0 Qs"))
                        }
                    ),
                    ReportTable(
                        title = "Daily Routine Schedule Blueprint",
                        headers = listOf("Slot Period", "Time Window", "Subject", "Target Task", "Status"),
                        rows = scheduleSlots.map { slot ->
                            listOf(slot.slotPeriod, slot.timeRange, slot.subject.displayName, slot.title, if (slot.isCompleted) "Completed" else "Pending")
                        }
                    )
                )
            )
        )

        return ReportDocument(
            metadata = metadata,
            reportType = ReportType.STUDY_HOURS_LOG,
            format = format,
            executiveSummary = "Total verified study time logged in JEE Core is ${String.format(Locale.US, "%.1f", totalHours)} hours across ${focusSessions.size} focus sessions and ${workLogs.size} work logs. Daily schedule slot completion is currently ${scheduleSlots.count { it.isCompleted }} out of ${scheduleSlots.size} slots.",
            sections = sections,
            actionPlan = listOf(
                "Maintain minimum 5 hours of deep study on weekdays, structured in 90-minute blocks.",
                "Ensure balanced subject distribution: allocate equal attention to Physics, Chemistry, and Maths.",
                "Log question counts diligently after every study session to track solving velocity."
            )
        )
    }

    private fun buildEmptyTestAnalysisReport(
        metadata: ReportMetadata,
        format: ReportFormat
    ): ReportDocument {
        return ReportDocument(
            metadata = metadata,
            reportType = ReportType.TEST_ANALYSIS,
            format = format,
            executiveSummary = "No mock test records found in the database. Log your test scores in the Tests Tracker or via Chat to unlock automated score leakage analysis, percentile projections, and error taxonomy diagnostics.",
            sections = listOf(
                ReportSection(
                    sectionNumber = 1,
                    title = "Test Diagnostics Readiness",
                    subtitle = "Awaiting First Mock Exam Record",
                    summaryCards = listOf(
                        ReportSummaryCard(title = "TESTS LOGGED", value = "0", subtitle = "No data available", colorHex = "#94A3B8"),
                        ReportSummaryCard(title = "BENCHMARK", value = "-- / 300", subtitle = "Pending first test", colorHex = "#94A3B8"),
                        ReportSummaryCard(title = "ACCURACY", value = "--%", subtitle = "Pending first test", colorHex = "#94A3B8"),
                        ReportSummaryCard(title = "LEAKAGE", value = "-- M", subtitle = "Pending first test", colorHex = "#94A3B8")
                    ),
                    observations = listOf(
                        "Test analysis requires at least one recorded mock exam.",
                        "Use the '+ Record Test' button in the History tab or tell Coach 'I scored 185 in JEE Main mock test' to record your performance."
                    )
                )
            ),
            actionPlan = listOf(
                "Attempt a 3-hour timed JEE Main mock test under realistic exam conditions.",
                "Record your total marks, subject scores, and error classification into JEE Core.",
                "Regenerate this report to view your complete error taxonomy and score leakage breakdown."
            )
        )
    }
}
