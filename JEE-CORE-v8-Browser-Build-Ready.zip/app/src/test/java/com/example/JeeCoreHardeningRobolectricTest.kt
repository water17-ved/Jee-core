package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.ai.AIMode
import com.example.ai.GeminiService
import com.example.data.local.AppDatabase
import com.example.data.model.AIBehaviour
import com.example.data.model.BackupData
import com.example.data.model.ChatEntity
import com.example.data.model.ChatMessageEntity
import com.example.data.model.ExamType
import com.example.data.model.FocusSessionEntity
import com.example.data.model.JeeMemory
import com.example.data.model.MissionEntity
import com.example.data.model.MissionStatus
import com.example.data.model.NotificationSettings
import com.example.data.model.PriorityLevel
import com.example.data.model.Subject
import com.example.data.model.SubjectLevel
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TopicState
import com.example.data.model.UserProfile
import com.example.data.preference.UserPreferencesManager
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class JeeCoreHardeningRobolectricTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var prefsManager: UserPreferencesManager
    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        prefsManager = UserPreferencesManager(context)
    }

    @After
    fun tearDown() {
        database.close()
    }

    // 1. FRESH INSTALL STATE TEST
    @Test
    fun testFreshInstall_studentStateBeginsEmpty_noFabricatedData() = runBlocking {
        // Fresh database verification
        val missions = database.missionDao().getAllMissionsList()
        val chats = database.chatDao().getAllChatsList()
        val messages = database.chatDao().getAllMessagesList()
        val focusSessions = database.focusSessionDao().getAllFocusSessionsList()
        val testRecords = database.testRecordDao().getAllTestsList()
        val workLogs = database.workLogDao().getAllWorkLogsList()

        assertTrue("Missions must start empty on fresh install", missions.isEmpty())
        assertTrue("Chats must start empty on fresh install", chats.isEmpty())
        assertTrue("Messages must start empty on fresh install", messages.isEmpty())
        assertTrue("Focus sessions must start empty on fresh install", focusSessions.isEmpty())
        assertTrue("Test records must start empty on fresh install (no fake analytics)", testRecords.isEmpty())
        assertTrue("Work logs must start empty on fresh install", workLogs.isEmpty())

        // Preferences verification
        val profile = prefsManager.userProfile.value
        assertFalse("Onboarding must not be completed on fresh install", profile.isOnboardingComplete)
        assertEquals(ExamType.BOTH, profile.targetExam)
    }

    // 2. PROFILE & STUDENT PREFERENCES TEST
    @Test
    fun testUserProfile_persistenceAndFidelity() {
        val customProfile = UserProfile(
            targetExam = ExamType.JEE_ADVANCED,
            targetYear = 2026,
            targetRank = "Top 500",
            physicsLevel = SubjectLevel.STRONG,
            chemistryLevel = SubjectLevel.LEARNING,
            mathsLevel = SubjectLevel.MIXED,
            weekdayAvailableHours = 7.5f,
            weekendAvailableHours = 11.0f,
            coachingStart = "07:30",
            coachingEnd = "13:30",
            mealsSchedule = "14:00, 21:00",
            fixedCommitments = "School Practical on Tuesday",
            weakAreasNotes = "Rotational Mechanics & Organic Mechanisms",
            isOnboardingComplete = true
        )

        prefsManager.saveUserProfile(customProfile)
        val loaded = prefsManager.userProfile.value

        assertEquals(ExamType.JEE_ADVANCED, loaded.targetExam)
        assertEquals(2026, loaded.targetYear)
        assertEquals("Top 500", loaded.targetRank)
        assertEquals(SubjectLevel.STRONG, loaded.physicsLevel)
        assertEquals(7.5f, loaded.weekdayAvailableHours, 0.01f)
        assertEquals("Rotational Mechanics & Organic Mechanisms", loaded.weakAreasNotes)
        assertTrue(loaded.isOnboardingComplete)
    }

    // 3. STUDENT MEMORY TEST
    @Test
    fun testStudentMemory_retention() {
        val memory = JeeMemory(
            targetSummary = "Targeting IIT Bombay CS / Electrical",
            strengths = "Calculus, Kinematics, Thermodynamics",
            weaknesses = "Inorganic Chemistry, Complex Numbers geometry",
            coachingSchedule = "Mon-Sat 8AM - 1PM",
            recurringProblems = "Calculation slip in multi-correct physics questions",
            studyPreferences = "Morning focus blocks, 50-min pomodoros",
            backlogNotes = "Wave Optics PYQs pending",
            revisionStateSummary = "Electrostatics revised 3 days ago"
        )

        prefsManager.saveJeeMemory(memory)
        val loaded = prefsManager.jeeMemory.value

        assertEquals("Targeting IIT Bombay CS / Electrical", loaded.targetSummary)
        assertEquals("Wave Optics PYQs pending", loaded.backlogNotes)
        assertEquals("Calculation slip in multi-correct physics questions", loaded.recurringProblems)
    }

    // 4. AI MODES VALIDATION TEST
    @Test
    fun testAIModes_directivesAndTagParsing() {
        // Verify all 8 modes exist and have rich directives
        val modes = AIMode.values()
        assertEquals(8, modes.size)

        for (mode in modes) {
            assertNotNull(mode.tag)
            assertNotNull(mode.displayName)
            assertTrue("Directive for ${mode.name} must not be blank", mode.systemDirective.isNotBlank())
            assertEquals("Parsing tag should return matching mode", mode, AIMode.fromTag(mode.tag))
            assertEquals("Parsing lowercase tag should return matching mode", mode, AIMode.fromTag(mode.tag.lowercase()))
        }

        // Verify fallback for unknown tag
        assertEquals(AIMode.AUTO, AIMode.fromTag("UNKNOWN_NON_EXISTENT_TAG"))
        assertEquals(AIMode.AUTO, AIMode.fromTag(null))
    }

    // 5. CHAT, ATTACHMENTS & STREAMING / RETRY TEST
    @Test
    fun testChat_messagingAndErrorRetryLifecycle() = runBlocking {
        val chatDao = database.chatDao()

        val chatId = chatDao.insertChat(ChatEntity(title = "Calculus Doubt Session"))
        assertTrue(chatId > 0)

        // User message with attachment and SOLVE mode
        val userMsgId = chatDao.insertMessage(
            ChatMessageEntity(
                chatId = chatId,
                role = "user",
                content = "Evaluate integral from 0 to pi/2 of ln(sin x) dx",
                aiMode = AIMode.SOLVE.name,
                attachmentName = "definite_integration_notes.txt",
                attachmentUri = "content://com.android.providers/notes/12"
            )
        )
        assertTrue(userMsgId > 0)

        // Assistant streaming placeholder
        val placeholderId = chatDao.insertMessage(
            ChatMessageEntity(
                chatId = chatId,
                role = "model",
                content = "",
                aiMode = AIMode.SOLVE.name,
                isError = false
            )
        )

        // Simulated streamed chunk arrival
        chatDao.updateMessage(
            ChatMessageEntity(
                id = placeholderId,
                chatId = chatId,
                role = "model",
                content = "Standard integral result is - (pi/2) * ln(2).",
                aiMode = AIMode.SOLVE.name,
                isError = false
            )
        )

        val updatedMsg = chatDao.getAllMessagesList().find { it.id == placeholderId }
        assertNotNull(updatedMsg)
        assertEquals("Standard integral result is - (pi/2) * ln(2).", updatedMsg!!.content)
        assertFalse(updatedMsg.isError)

        // Simulated network drop error
        chatDao.updateMessage(
            updatedMsg.copy(isError = true, content = "Network error: API call timed out.")
        )
        val errorMsg = chatDao.getAllMessagesList().find { it.id == placeholderId }
        assertTrue(errorMsg!!.isError)

        // Simulated user clicking "Retry"
        val retryMsg = errorMsg.copy(
            isError = false,
            content = "Detailed Step-by-Step Derivation: Using symmetry property I = int ln(cos x) dx..."
        )
        chatDao.updateMessage(retryMsg)

        val finalMsg = chatDao.getAllMessagesList().find { it.id == placeholderId }
        assertFalse(finalMsg!!.isError)
        assertTrue(finalMsg.content.contains("Detailed Step-by-Step Derivation"))
    }

    // 6. MISSIONS & FOCUS SESSIONS TEST
    @Test
    fun testMissionsAndFocus_lifecycle() = runBlocking {
        val missionDao = database.missionDao()
        val focusDao = database.focusSessionDao()

        val missionId = missionDao.insertMission(
            MissionEntity(
                title = "Solve 25 Rotational Dynamics PYQs",
                subject = Subject.PHYSICS,
                chapter = "Rotational Motion",
                topic = "Moment of Inertia & Angular Momentum",
                plannedDurationMinutes = 60,
                priority = PriorityLevel.URGENT,
                targetQuantity = 25
            )
        )

        val retrievedMission = missionDao.getMissionById(missionId)
        assertNotNull(retrievedMission)
        assertEquals(MissionStatus.NOT_STARTED, retrievedMission!!.status)
        assertEquals(PriorityLevel.URGENT, retrievedMission.priority)

        // Toggle to completed
        missionDao.updateMission(retrievedMission.copy(status = MissionStatus.COMPLETED, completedQuantity = 25))
        val completedMission = missionDao.getMissionById(missionId)
        assertEquals(MissionStatus.COMPLETED, completedMission!!.status)

        // Log focus session
        val sessionId = focusDao.insertSession(
            FocusSessionEntity(
                missionId = missionId,
                missionTitle = completedMission.title,
                subject = Subject.PHYSICS,
                chapter = "Rotational Motion",
                topic = "Moment of Inertia",
                plannedDurationMinutes = 60,
                actualDurationMinutes = 55,
                questionsCompleted = 25,
                startTimeEpochMs = 1000000L,
                endTimeEpochMs = 1003300L,
                isCompleted = true,
                notes = "Cracked rolling without slipping questions with good speed."
            )
        )
        assertTrue(sessionId > 0)
        val sessionList = focusDao.getAllFocusSessionsList()
        assertEquals(1, sessionList.size)
        assertEquals(55, sessionList[0].actualDurationMinutes)
    }

    // 7. BACKUP / EXPORT & IMPORT MOSHI ROUND TRIP TEST
    @Test
    fun testBackupData_serializationRoundTripIntegrity() {
        val sampleBackup = BackupData(
            schemaVersion = 2,
            exportedAt = 1770000000000L,
            appVersion = "1.0.0",
            userProfile = UserProfile(
                targetExam = ExamType.JEE_MAIN,
                targetRank = "Top 1000",
                isOnboardingComplete = true
            ),
            jeeMemory = JeeMemory(
                targetSummary = "Target 99.5+ percentile",
                strengths = "Organic Chemistry"
            ),
            aiBehaviour = AIBehaviour(strictness = 0.8f),
            notificationSettings = NotificationSettings(missionReminders = true),
            missions = listOf(
                MissionEntity(
                    id = 1L,
                    title = "Inorganic Salt Analysis Drill",
                    subject = Subject.CHEMISTRY,
                    chapter = "Qualitative Analysis",
                    topic = "Cation Tests",
                    priority = PriorityLevel.HIGH
                )
            ),
            focusSessions = listOf(
                FocusSessionEntity(
                    id = 1L,
                    subject = Subject.CHEMISTRY,
                    chapter = "Qualitative Analysis",
                    topic = "Cations",
                    plannedDurationMinutes = 45,
                    actualDurationMinutes = 45,
                    startTimeEpochMs = 1000L,
                    endTimeEpochMs = 2700L
                )
            ),
            chats = listOf(ChatEntity(id = 1L, title = "Mock Analysis")),
            chatMessages = listOf(
                ChatMessageEntity(
                    id = 1L,
                    chatId = 1L,
                    role = "user",
                    content = "How to improve mock score?",
                    aiMode = "ANALYSE"
                )
            ),
            syllabusTopics = listOf(
                SyllabusTopicEntity(
                    id = 1L,
                    subject = Subject.MATHEMATICS,
                    chapter = "Conic Sections",
                    topicName = "Parabola Normal",
                    state = TopicState.NEEDS_REVISION
                )
            )
        )

        val adapter = moshi.adapter(BackupData::class.java)
        val jsonString = adapter.toJson(sampleBackup)

        assertNotNull(jsonString)
        assertTrue(jsonString.contains("Inorganic Salt Analysis Drill"))
        assertTrue(jsonString.contains("Parabola Normal"))

        // Deserialize
        val deserialized = adapter.fromJson(jsonString)
        assertNotNull(deserialized)
        assertEquals(2, deserialized!!.schemaVersion)
        assertEquals("Top 1000", deserialized.userProfile.targetRank)
        assertEquals(1, deserialized.missions.size)
        assertEquals("Inorganic Salt Analysis Drill", deserialized.missions[0].title)
        assertEquals(1, deserialized.chatMessages.size)
        assertEquals("ANALYSE", deserialized.chatMessages[0].aiMode)
        assertEquals(1, deserialized.syllabusTopics.size)
        assertEquals(TopicState.NEEDS_REVISION, deserialized.syllabusTopics[0].state)
    }

    // 8. GEMINI COACH SYSTEM INSTRUCTION BUILDER TEST
    @Test
    fun testGeminiCoach_systemInstructionDirectives() {
        val geminiService = GeminiService { prefsManager.customGeminiKey.value }

        // AUTO mode instruction
        val autoInstruction = geminiService.buildSystemInstruction(aiMode = AIMode.AUTO)
        assertTrue("Must include JEE CORE identity", autoInstruction.contains("JEE CORE"))
        assertTrue("Must include AUTO mode directives", autoInstruction.contains("MODE: AUTO"))

        // SOLVE mode instruction
        val solveInstruction = geminiService.buildSystemInstruction(aiMode = AIMode.SOLVE)
        assertTrue("Must include SOLVE mode directives", solveInstruction.contains("MODE: SOLVE"))
        assertTrue("Must prioritize mathematical rigor", solveInstruction.contains("mathematical"))

        // PLAN mode instruction
        val planInstruction = geminiService.buildSystemInstruction(aiMode = AIMode.PLAN)
        assertTrue("Must include PLAN mode directives", planInstruction.contains("MODE: PLAN"))

        // Honesty constraint check
        val researchInstruction = geminiService.buildSystemInstruction(aiMode = AIMode.RESEARCH)
        assertTrue("Must emphasize honesty without fabricating live web citations",
            researchInstruction.contains("HONESTY") || researchInstruction.contains("speculation"))
    }

    // 9. BACKUP PREVIEW & TRANSACTIONAL IMPORT TEST
    @Test
    fun testBackupPreviewAndImport_relationshipIntegrity() = runBlocking {
        val repo = com.example.data.repository.JeeCoreRepository(database, prefsManager)

        // Seed initial mission and chat
        val oldMissionId = database.missionDao().insertMission(
            MissionEntity(title = "Initial Mission", subject = Subject.PHYSICS, chapter = "Kinematics", topic = "1D Motion")
        )
        val oldChatId = database.chatDao().insertChat(ChatEntity(title = "Old Chat"))
        database.chatDao().insertMessage(
            ChatMessageEntity(chatId = oldChatId, role = "user", content = "Initial question")
        )

        // Export current data to JSON
        val exportedJson = repo.exportBackupJson()
        assertNotNull(exportedJson)

        // Validate and preview backup JSON
        val previewResult = repo.validateAndPreviewBackup(exportedJson)
        assertTrue("Preview must succeed for valid export", previewResult.isSuccess)
        val preview = previewResult.getOrThrow()
        assertEquals(2, preview.schemaVersion)
        assertEquals(1, preview.missionCount)
        assertEquals(1, preview.chatCount)
        assertEquals(1, preview.messageCount)

        // Corrupt JSON verification
        val corruptResult = repo.validateAndPreviewBackup("{ \"schemaVersion\": 99, \"invalid\": true }")
        assertTrue("Preview must fail or flag unsupported schema version", corruptResult.isFailure)

        // Import backup JSON and verify atomic remapping
        val importResult = repo.importBackupJson(exportedJson)
        assertTrue("Import must succeed", importResult.isSuccess)

        val restoredMissions = database.missionDao().getAllMissionsList()
        assertEquals(1, restoredMissions.size)
        assertEquals("Initial Mission", restoredMissions[0].title)

        val restoredChats = database.chatDao().getAllChatsList()
        assertEquals(1, restoredChats.size)
        assertEquals("Old Chat", restoredChats[0].title)

        val restoredMessages = database.chatDao().getAllMessagesList()
        assertEquals(1, restoredMessages.size)
        assertEquals(restoredChats[0].id, restoredMessages[0].chatId)
    }

    // 10. SYLLABUS TRACKER & WORK LOG INTEGRATION TEST
    @Test
    fun testSyllabusAndWorkLogs_lifecycle() = runBlocking {
        val syllabusDao = database.syllabusDao()
        val workLogDao = database.workLogDao()

        // Insert syllabus topics
        val topics = listOf(
            SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Thermodynamics", topicName = "First Law", state = TopicState.COMPLETED_ONCE),
            SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Thermodynamics", topicName = "Carnot Engine", state = TopicState.NEEDS_REVISION),
            SyllabusTopicEntity(subject = Subject.PHYSICS, chapter = "Thermodynamics", topicName = "Entropy", state = TopicState.NOT_STARTED)
        )
        syllabusDao.insertTopics(topics)

        val retrievedTopics = syllabusDao.getAllTopicsList().filter { it.chapter == "Thermodynamics" }
        assertEquals(3, retrievedTopics.size)

        // Update topic state
        val carnotTopic = retrievedTopics.first { it.topicName == "Carnot Engine" }
        syllabusDao.updateTopic(carnotTopic.copy(state = TopicState.STRONG))

        val updatedCarnot = syllabusDao.getAllTopicsList().first { it.topicName == "Carnot Engine" }
        assertEquals(TopicState.STRONG, updatedCarnot.state)

        // Log daily work
        val logId = workLogDao.insertWorkLog(
            com.example.data.model.WorkLogEntity(
                subject = Subject.PHYSICS,
                chapter = "Thermodynamics",
                topic = "Carnot Engine",
                whatDidYouDo = "Reviewed Carnot cycle efficiency and solved 15 Advanced problems",
                durationMinutes = 75,
                questionsAttempted = 15,
                questionsCorrect = 13
            )
        )
        assertTrue(logId > 0)

        val allLogs = workLogDao.getAllWorkLogsList()
        assertEquals(1, allLogs.size)
        assertEquals(75, allLogs[0].durationMinutes)
        assertEquals(15, allLogs[0].questionsAttempted)
        assertEquals(13, allLogs[0].questionsCorrect)
    }

    // 11. TEST RECORDS (MOCK EXAM TRACKER) TEST
    @Test
    fun testTestRecords_persistenceAndCalculation() = runBlocking {
        val testDao = database.testRecordDao()

        val testId = testDao.insertTest(
            com.example.data.model.TestRecordEntity(
                testName = "All India Open Mock 1",
                examType = ExamType.JEE_MAIN,
                testDateEpochMs = 1770000000000L,
                physicsScore = 80,
                chemistryScore = 75,
                mathsScore = 70,
                userScore = 225,
                totalMarks = 300,
                percentile = 99.4f,
                analysisNotes = "Lost 10 marks in negative marking in Maths conic sections."
            )
        )
        assertTrue(testId > 0)

        val tests = testDao.getAllTestsList()
        assertEquals(1, tests.size)
        assertEquals(225, tests[0].userScore)
        assertEquals(300, tests[0].totalMarks)
        assertEquals(99.4f, tests[0].percentile, 0.01f)
    }
}
