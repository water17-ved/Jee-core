package com.example.report

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AppDatabase
import com.example.data.model.ExamType
import com.example.data.model.FocusSessionEntity
import com.example.data.model.ScheduleSlot
import com.example.data.model.Subject
import com.example.data.model.SubjectLevel
import com.example.data.model.SyllabusTopicEntity
import com.example.data.model.TestRecordEntity
import com.example.data.model.TopicState
import com.example.data.model.UserProfile
import com.example.data.model.WorkLogEntity
import com.example.data.preference.UserPreferencesManager
import com.example.report.model.GeneratedReportFile
import com.example.report.model.ReportFormat
import com.example.report.model.ReportType
import com.example.report.pdf.PdfReportGenerator
import com.example.report.xlsx.XlsxReportGenerator
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.Implementation
import org.robolectric.annotation.Implements
import java.io.File
import java.io.FileInputStream
import java.io.OutputStream

@Implements(PdfDocument::class)
class TestShadowPdfDocument {
    private val pages = mutableListOf<PdfDocument.PageInfo>()
    private var currentPage: PdfDocument.Page? = null

    @Implementation
    fun __constructor__() {
    }

    @Implementation
    fun startPage(pageInfo: PdfDocument.PageInfo): PdfDocument.Page {
        val bitmap = Bitmap.createBitmap(
            pageInfo.pageWidth.coerceAtLeast(1),
            pageInfo.pageHeight.coerceAtLeast(1),
            Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        val ctor = PdfDocument.Page::class.java.getDeclaredConstructor(
            Canvas::class.java,
            PdfDocument.PageInfo::class.java
        )
        ctor.isAccessible = true
        val page = ctor.newInstance(canvas, pageInfo)
        currentPage = page
        return page
    }

    @Implementation
    fun finishPage(page: PdfDocument.Page) {
        currentPage = null
        pages.add(page.info)
    }

    @Implementation
    fun writeTo(out: OutputStream) {
        out.write("%PDF-1.4\n%JEE CORE Academic Audit Document\n1 0 obj\n<<>>\nendobj\ntrailer\n<<>>\n%%EOF\n".toByteArray(Charsets.UTF_8))
        out.flush()
    }

    @Implementation
    fun close() {
    }
}

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], shadows = [TestShadowPdfDocument::class])
class ReportGenerationTest {

    private lateinit var context: Context
    private lateinit var database: AppDatabase
    private lateinit var prefsManager: UserPreferencesManager
    private lateinit var userProfile: UserProfile
    private lateinit var tests: List<TestRecordEntity>
    private lateinit var syllabusTopics: List<SyllabusTopicEntity>
    private lateinit var focusSessions: List<FocusSessionEntity>
    private lateinit var workLogs: List<WorkLogEntity>
    private lateinit var scheduleSlots: List<ScheduleSlot>
    private lateinit var dataCollector: ReportDataCollector
    private lateinit var pdfGenerator: PdfReportGenerator
    private lateinit var xlsxGenerator: XlsxReportGenerator
    private lateinit var reportManager: ReportManager

    @Before
    fun setup() = runBlocking {
        context = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        prefsManager = UserPreferencesManager(context)

        userProfile = UserProfile(
            targetExam = ExamType.JEE_MAIN,
            targetYear = 2026,
            targetRank = "Top 500",
            physicsLevel = SubjectLevel.STRONG,
            chemistryLevel = SubjectLevel.LEARNING,
            mathsLevel = SubjectLevel.MIXED,
            isOnboardingComplete = true
        )
        prefsManager.saveUserProfile(userProfile)

        val test1 = TestRecordEntity(
            testName = "Full Mock 1",
            examType = ExamType.JEE_MAIN,
            userScore = 215,
            totalMarks = 300,
            physicsScore = 75,
            chemistryScore = 70,
            mathsScore = 70,
            accuracy = 82f,
            conceptualErrors = 3,
            calculationErrors = 4,
            sillyMistakes = 2,
            weakChaptersIdentified = "Rotation, Electrochemistry, Indefinite Integration",
            testDateEpochMs = System.currentTimeMillis() - 86400000L
        )
        val test2 = TestRecordEntity(
            testName = "Part Test 2",
            examType = ExamType.JEE_ADVANCED,
            userScore = 145,
            totalMarks = 240,
            physicsScore = 55,
            chemistryScore = 50,
            mathsScore = 40,
            accuracy = 75f,
            conceptualErrors = 5,
            calculationErrors = 3,
            sillyMistakes = 1,
            weakChaptersIdentified = "Complex Numbers, Wave Optics",
            testDateEpochMs = System.currentTimeMillis()
        )
        val id1 = database.testRecordDao().insertTest(test1)
        val id2 = database.testRecordDao().insertTest(test2)
        tests = listOf(test2.copy(id = id2), test1.copy(id = id1))

        val topics = listOf(
            SyllabusTopicEntity(
                subject = Subject.PHYSICS,
                chapter = "Rotational Motion",
                topicName = "Moment of Inertia",
                state = TopicState.WEAK,
                isWeakArea = true,
                notes = "Confusion in parallel axis theorem",
                confidenceScore = 35
            ),
            SyllabusTopicEntity(
                subject = Subject.PHYSICS,
                chapter = "Thermodynamics",
                topicName = "Carnot Engine & Cycles",
                state = TopicState.STRONG,
                isWeakArea = false,
                confidenceScore = 90
            ),
            SyllabusTopicEntity(
                subject = Subject.CHEMISTRY,
                chapter = "Electrochemistry",
                topicName = "Nernst Equation",
                state = TopicState.NEEDS_REVISION,
                isWeakArea = true,
                notes = "Sign convention mistakes in cell potential",
                confidenceScore = 50
            ),
            SyllabusTopicEntity(
                subject = Subject.MATHEMATICS,
                chapter = "Integration",
                topicName = "Integration by Parts",
                state = TopicState.WEAK,
                isWeakArea = true,
                notes = "Difficulty with cancellation substitutions",
                confidenceScore = 40
            )
        )
        database.syllabusDao().insertTopics(topics)
        syllabusTopics = database.syllabusDao().getAllTopicsList()

        val session = FocusSessionEntity(
            subject = Subject.PHYSICS,
            chapter = "Rotational Motion",
            topic = "Moment of Inertia",
            plannedDurationMinutes = 60,
            actualDurationMinutes = 55,
            questionsCompleted = 18,
            startTimeEpochMs = System.currentTimeMillis() - 43200000L,
            endTimeEpochMs = System.currentTimeMillis() - 40000000L,
            isCompleted = true
        )
        database.focusSessionDao().insertSession(session)
        focusSessions = listOf(session)

        val log = WorkLogEntity(
            timestampEpochMs = System.currentTimeMillis() - 40000000L,
            subject = Subject.PHYSICS,
            chapter = "Rotational Motion",
            topic = "Moment of Inertia",
            whatDidYouDo = "Reviewed parallel axis theorem and solved 18 questions",
            durationMinutes = 55,
            questionsAttempted = 18,
            questionsCorrect = 15,
            notes = "Solid question solving session on parallel axis theorem."
        )
        database.workLogDao().insertWorkLog(log)
        workLogs = listOf(log)

        scheduleSlots = listOf(
            ScheduleSlot(
                id = "slot_1",
                timeRange = "06:00 - 08:00 AM",
                title = "Physics Problem Solving",
                subject = Subject.PHYSICS,
                chapterOrTask = "Rotational Motion",
                targetMinutes = 120,
                isCompleted = true
            )
        )

        dataCollector = ReportDataCollector(
            userProfile = userProfile,
            tests = tests,
            syllabusTopics = syllabusTopics,
            missions = emptyList(),
            focusSessions = focusSessions,
            workLogs = workLogs,
            scheduleSlots = scheduleSlots
        )
        pdfGenerator = PdfReportGenerator()
        xlsxGenerator = XlsxReportGenerator()
        reportManager = ReportManager(context)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun testReportIntentParser_detectsAllStandardChatCommands() {
        // "Create a PDF of my latest test analysis."
        val req1 = ReportIntentParser.parse("Create a PDF of my latest test analysis.")
        assertNotNull(req1)
        assertEquals(ReportType.TEST_ANALYSIS, req1!!.reportType)
        assertEquals(ReportFormat.PDF, req1.format)

        // "Make a detailed report of my last 5 tests."
        val req2 = ReportIntentParser.parse("Make a detailed report of my last 5 tests.")
        assertNotNull(req2)
        assertEquals(ReportType.MULTI_TEST_SUMMARY, req2!!.reportType)
        assertEquals(ReportFormat.PDF, req2.format)

        // "Export my weaknesses to Excel."
        val req3 = ReportIntentParser.parse("Export my weaknesses to Excel.")
        assertNotNull(req3)
        assertEquals(ReportType.WEAKNESS_AUDIT, req3!!.reportType)
        assertEquals(ReportFormat.XLSX, req3.format)

        // "Create a chapter-wise performance spreadsheet."
        val req4 = ReportIntentParser.parse("Create a chapter-wise performance spreadsheet.")
        assertNotNull(req4)
        assertEquals(ReportType.SYLLABUS_MASTERY, req4!!.reportType)
        assertEquals(ReportFormat.XLSX, req4.format)

        // "Make a revision report."
        val req5 = ReportIntentParser.parse("Make a revision report.")
        assertNotNull(req5)
        assertEquals(ReportType.REVISION_PRIORITIES, req5!!.reportType)
        assertEquals(ReportFormat.PDF, req5.format)

        // "Generate a complete JEE performance report."
        val req6 = ReportIntentParser.parse("Generate a complete JEE performance report.")
        assertNotNull(req6)
        assertEquals(ReportType.COMPLETE_PERFORMANCE, req6!!.reportType)
        assertEquals(ReportFormat.PDF, req6.format)

        // "Put all my error analysis into Excel."
        val req7 = ReportIntentParser.parse("Put all my error analysis into Excel.")
        assertNotNull(req7)
        assertEquals(ReportType.WEAKNESS_AUDIT, req7!!.reportType)
        assertEquals(ReportFormat.XLSX, req7.format)

        // "Create a printable test report."
        val req8 = ReportIntentParser.parse("Create a printable test report.")
        assertNotNull(req8)
        assertEquals(ReportType.TEST_ANALYSIS, req8!!.reportType)
        assertEquals(ReportFormat.PDF, req8.format)
    }

    @Test
    fun testDataCollector_buildsRichStructuredReport() {
        val doc = dataCollector.buildReport(ReportType.COMPLETE_PERFORMANCE, ReportFormat.PDF)
        assertEquals(ReportType.COMPLETE_PERFORMANCE, doc.reportType)
        assertEquals(ReportFormat.PDF, doc.format)
        assertTrue(doc.sections.isNotEmpty())
        assertTrue(doc.executiveSummary.isNotBlank())
        assertTrue(doc.actionPlan.isNotEmpty())

        val testDoc = dataCollector.buildReport(ReportType.TEST_ANALYSIS, ReportFormat.PDF, tests.first().id)
        assertEquals(ReportType.TEST_ANALYSIS, testDoc.reportType)
        assertTrue(testDoc.sections.any { it.title.contains("Test Score") || it.title.contains("Analysis") })
    }

    @Test
    fun testPdfReportGenerator_createsValidMultiPagePdf() {
        val doc = dataCollector.buildReport(ReportType.COMPLETE_PERFORMANCE, ReportFormat.PDF)
        val targetFile = File(context.cacheDir, "test_complete_report.pdf")
        val pageCount = pdfGenerator.generate(doc, targetFile)

        assertTrue(targetFile.exists())
        assertTrue(targetFile.length() > 0)
        assertTrue(pageCount >= 1)

        // Verify PDF Magic Bytes: "%PDF-"
        val header = ByteArray(5)
        FileInputStream(targetFile).use { it.read(header) }
        assertEquals("%PDF-", String(header))
    }

    @Test
    fun testXlsxReportGenerator_createsValidMultiSheetWorkbook() {
        val doc = dataCollector.buildReport(ReportType.COMPLETE_PERFORMANCE, ReportFormat.XLSX)
        val targetFile = File(context.cacheDir, "test_complete_workbook.xlsx")
        val sheetCount = xlsxGenerator.generate(doc, targetFile)

        assertTrue(targetFile.exists())
        assertTrue(targetFile.length() > 0)
        assertTrue(sheetCount >= 1)

        // Verify ZIP Magic Bytes: 0x50, 0x4B, 0x03, 0x04 ('PK\u0003\u0004')
        val header = ByteArray(4)
        FileInputStream(targetFile).use { it.read(header) }
        assertEquals(0x50.toByte(), header[0])
        assertEquals(0x4B.toByte(), header[1])
        assertEquals(0x03.toByte(), header[2])
        assertEquals(0x04.toByte(), header[3])
    }

    @Test
    fun testReportManager_flowGeneratesAndCompletes() = runBlocking {
        val progressList = reportManager.generateReportFlow(
            reportType = ReportType.MULTI_TEST_SUMMARY,
            format = ReportFormat.PDF,
            userProfile = userProfile,
            tests = tests,
            syllabusTopics = syllabusTopics,
            missions = emptyList(),
            focusSessions = focusSessions,
            workLogs = workLogs,
            scheduleSlots = scheduleSlots
        ).toList()

        assertTrue(progressList.isNotEmpty())
        val finalProgress = progressList.last()
        assertTrue(finalProgress.isFinished)
        assertNotNull(finalProgress.generatedFile)
        val file: GeneratedReportFile = finalProgress.generatedFile!!
        assertTrue(file.file.exists())
        assertTrue(file.file.length() > 0)
        assertEquals("pdf", file.format.extension)
        assertNotNull(file.uri)
    }
}
