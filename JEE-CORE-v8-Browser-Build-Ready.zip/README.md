# JEE CORE — Native Android AI Coach & Intelligence System

A modern native Android application combining deep JEE exam specialization, persistent student intelligence, adaptive coaching, and real-time AI reasoning.

## Architecture

- **Platform:** 100% Native Android (Kotlin & Jetpack Compose)
- **UI & Design:** Material 3 with edge-to-edge support and custom dark/light theme
- **Persistence:** Local Room database (`AppDatabase`) with TypeConverters and schema versioning
- **Preferences:** SharedPreferences with reactive `MutableStateFlow` (`UserPreferencesManager`)
- **JSON Serialization:** Moshi with `KotlinJsonAdapterFactory`
- **AI Integration:** Google Gemini API (Gemini 2.5 Flash / Gemini 1.5 Pro) with real-time streaming, context pipelining, and error retry mechanics
- **Testing:** Local JVM tests with Robolectric and Roborazzi screenshot verification

## Key Features

### 1. Unified JEE CORE AI & Per-Message Modes
One unified AI assistant with 8 specialized operational modes:
- **AUTO:** Intelligently infers user intent from query context.
- **ASK:** Direct, factual, and concise responses.
- **RESEARCH:** Deep subject synthesis based on validated models and stored JEE curriculum context (transparently avoids false web citations).
- **ANALYSE:** Pinpoints error patterns, conceptual gaps, and mock test weak spots.
- **SUGGEST:** Recommends high-yield next steps and practice problems.
- **PLAN:** Actionable study calendars respecting student's coaching schedule and available hours.
- **SOLVE:** Step-by-step rigorous mathematical and physical derivations with equations.
- **EXPLAIN:** Intuitive conceptual breakdowns at the student's current proficiency level.

### 2. Adaptive Student Intelligence & Memory
- Persistent memory captures target rank, weak chapters, revision backlog, and coaching constraints.
- Selective context pipeline injects only relevant background facts (profile, weak chapters, syllabus status) into prompts without bloating requests.
- Zero fake student data on fresh install — clean slate until the student logs real work.

### 3. Native File Attachments
- Supports images (`image/*`), PDFs (`application/pdf`), and text documents (`text/*`) via Android's Storage Access Framework (`ActivityResultContracts.GetContent`).
- Base64 encoding for multimodal transmission to Gemini.

### 4. Lifecycle-Safe Focus Timer
- Timestamp-based calculation preserving elapsed seconds across process recreation, backgrounding, and screen locks.
- Exactly-once session persistence to prevent duplicate records.

### 5. Deterministic Coach
- Answers **NOW**, **NEXT**, and **AFTER THAT** based on real logged syllabus data, pending revisions, and test schedules.
- Adaptive recovery mode provides realistic catch-up actions without shame.

### 6. File-Based Backup, Migration & Restore
- Full JSON export and import using Android Storage Access Framework (`CreateDocument` / `OpenDocument`).
- Versioned schema migration (`BackupData`) with foreign-key relationship integrity preservation.
- API keys and device secrets are strictly excluded from backups.

## Setup & API Key Configuration

1. Obtain a Google Gemini API Key from [Google AI Studio](https://aistudio.google.com/).
2. In the app, navigate to **Settings > Gemini API Configuration**.
3. Enter your API key. The key is stored locally on this device in private application storage and is never exported or transmitted to external servers.

## Build Instructions

To build the debug APK using the included Gradle wrapper:

```bash
# Build Debug APK
./gradlew assembleDebug

# Run Unit & Robolectric Tests
./gradlew testDebugUnitTest
```

The output APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

## Limitations
- Local database operations are offline-first; AI chat and generative coaching require active internet connectivity to contact the Gemini API.
- Live web search is not simulated; Research mode synthesizes verified curricular knowledge and student context.
